package com.ell.nihongomate

import android.os.Bundle
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import java.util.Locale

private data class Vocab(val jp: String, val reading: String, val meaning: String, val example: String)
private data class Kana(val char: String, val romaji: String, val group: String)
private data class Grammar(val pattern: String, val meaning: String, val example: String, val translation: String)
private data class Question(val prompt: String, val options: List<String>, val answer: Int, val explanation: String)

private val kana = listOf(
    Kana("あ","a","Hiragana"), Kana("い","i","Hiragana"), Kana("う","u","Hiragana"), Kana("え","e","Hiragana"), Kana("お","o","Hiragana"),
    Kana("か","ka","Hiragana"), Kana("き","ki","Hiragana"), Kana("く","ku","Hiragana"), Kana("け","ke","Hiragana"), Kana("こ","ko","Hiragana"),
    Kana("さ","sa","Hiragana"), Kana("し","shi","Hiragana"), Kana("す","su","Hiragana"), Kana("せ","se","Hiragana"), Kana("そ","so","Hiragana"),
    Kana("た","ta","Hiragana"), Kana("ち","chi","Hiragana"), Kana("つ","tsu","Hiragana"), Kana("て","te","Hiragana"), Kana("と","to","Hiragana"),
    Kana("な","na","Hiragana"), Kana("に","ni","Hiragana"), Kana("ぬ","nu","Hiragana"), Kana("ね","ne","Hiragana"), Kana("の","no","Hiragana"),
    Kana("は","ha","Hiragana"), Kana("ひ","hi","Hiragana"), Kana("ふ","fu","Hiragana"), Kana("へ","he","Hiragana"), Kana("ほ","ho","Hiragana"),
    Kana("ま","ma","Hiragana"), Kana("み","mi","Hiragana"), Kana("む","mu","Hiragana"), Kana("め","me","Hiragana"), Kana("も","mo","Hiragana"),
    Kana("や","ya","Hiragana"), Kana("ゆ","yu","Hiragana"), Kana("よ","yo","Hiragana"),
    Kana("ら","ra","Hiragana"), Kana("り","ri","Hiragana"), Kana("る","ru","Hiragana"), Kana("れ","re","Hiragana"), Kana("ろ","ro","Hiragana"),
    Kana("わ","wa","Hiragana"), Kana("を","o / wo","Hiragana"), Kana("ん","n","Hiragana"),
    Kana("ア","a","Katakana"), Kana("イ","i","Katakana"), Kana("ウ","u","Katakana"), Kana("エ","e","Katakana"), Kana("オ","o","Katakana"),
    Kana("カ","ka","Katakana"), Kana("キ","ki","Katakana"), Kana("ク","ku","Katakana"), Kana("ケ","ke","Katakana"), Kana("コ","ko","Katakana"),
    Kana("サ","sa","Katakana"), Kana("シ","shi","Katakana"), Kana("ス","su","Katakana"), Kana("セ","se","Katakana"), Kana("ソ","so","Katakana"),
    Kana("タ","ta","Katakana"), Kana("チ","chi","Katakana"), Kana("ツ","tsu","Katakana"), Kana("テ","te","Katakana"), Kana("ト","to","Katakana"),
    Kana("ナ","na","Katakana"), Kana("ニ","ni","Katakana"), Kana("ヌ","nu","Katakana"), Kana("ネ","ne","Katakana"), Kana("ノ","no","Katakana"),
    Kana("ハ","ha","Katakana"), Kana("ヒ","hi","Katakana"), Kana("フ","fu","Katakana"), Kana("ヘ","he","Katakana"), Kana("ホ","ho","Katakana"),
    Kana("マ","ma","Katakana"), Kana("ミ","mi","Katakana"), Kana("ム","mu","Katakana"), Kana("メ","me","Katakana"), Kana("モ","mo","Katakana"),
    Kana("ヤ","ya","Katakana"), Kana("ユ","yu","Katakana"), Kana("ヨ","yo","Katakana"),
    Kana("ラ","ra","Katakana"), Kana("リ","ri","Katakana"), Kana("ル","ru","Katakana"), Kana("レ","re","Katakana"), Kana("ロ","ro","Katakana"),
    Kana("ワ","wa","Katakana"), Kana("ヲ","o / wo","Katakana"), Kana("ン","n","Katakana")
)

private val vocab = listOf(
    Vocab("私","わたし","saya","私はインドネシア人です。"),
    Vocab("人","ひと","orang","あの人は先生です。"),
    Vocab("学生","がくせい","pelajar/mahasiswa","私は学生です。"),
    Vocab("先生","せんせい","guru","田中先生です。"),
    Vocab("会社員","かいしゃいん","pegawai perusahaan","父は会社員です。"),
    Vocab("日本","にほん","Jepang","日本へ行きます。"),
    Vocab("国","くに","negara","お国はどちらですか。"),
    Vocab("友達","ともだち","teman","友達と話します。"),
    Vocab("家族","かぞく","keluarga","家族は四人です。"),
    Vocab("家","いえ","rumah","家に帰ります。"),
    Vocab("学校","がっこう","sekolah","学校へ行きます。"),
    Vocab("会社","かいしゃ","perusahaan/kantor","会社は九時からです。"),
    Vocab("駅","えき","stasiun","駅で会います。"),
    Vocab("店","みせ","toko","あの店は安いです。"),
    Vocab("本","ほん","buku","本を読みます。"),
    Vocab("新聞","しんぶん","koran","新聞を読みます。"),
    Vocab("水","みず","air","水をください。"),
    Vocab("お茶","おちゃ","teh","お茶を飲みます。"),
    Vocab("ご飯","ごはん","nasi/makanan","ご飯を食べます。"),
    Vocab("パン","パン","roti","パンを買います。"),
    Vocab("食べます","たべます","makan","朝ご飯を食べます。"),
    Vocab("飲みます","のみます","minum","水を飲みます。"),
    Vocab("行きます","いきます","pergi","会社へ行きます。"),
    Vocab("来ます","きます","datang","友達が来ます。"),
    Vocab("帰ります","かえります","pulang","六時に帰ります。"),
    Vocab("見ます","みます","melihat/menonton","テレビを見ます。"),
    Vocab("聞きます","ききます","mendengar/bertanya","音楽を聞きます。"),
    Vocab("読みます","よみます","membaca","本を読みます。"),
    Vocab("書きます","かきます","menulis","名前を書きます。"),
    Vocab("買います","かいます","membeli","パンを買います。"),
    Vocab("働きます","はたらきます","bekerja","工場で働きます。"),
    Vocab("休みます","やすみます","beristirahat/libur","日曜日は休みます。"),
    Vocab("勉強します","べんきょうします","belajar","日本語を勉強します。"),
    Vocab("今日","きょう","hari ini","今日は暑いです。"),
    Vocab("明日","あした","besok","明日、働きます。"),
    Vocab("昨日","きのう","kemarin","昨日、勉強しました。"),
    Vocab("毎日","まいにち","setiap hari","毎日、日本語を勉強します。"),
    Vocab("朝","あさ","pagi","朝、七時に起きます。"),
    Vocab("夜","よる","malam","夜、日本語を勉強します。"),
    Vocab("時間","じかん","waktu/jam","時間があります。"),
    Vocab("大きい","おおきい","besar","大きい家です。"),
    Vocab("小さい","ちいさい","kecil","小さい犬です。"),
    Vocab("新しい","あたらしい","baru","新しい車です。"),
    Vocab("古い","ふるい","lama/tua","古い本です。"),
    Vocab("高い","たかい","mahal/tinggi","この時計は高いです。"),
    Vocab("安い","やすい","murah","この店は安いです。"),
    Vocab("暑い","あつい","panas (cuaca)","今日は暑いです。"),
    Vocab("おいしい","おいしい","enak","この料理はおいしいです。"),
    Vocab("便利","べんり","praktis","このアプリは便利です。"),
    Vocab("大丈夫","だいじょうぶ","tidak apa-apa","大丈夫です。")
)

private val kanji = listOf(
    Vocab("日","ひ・にち","hari, matahari","日本（にほん）"),
    Vocab("月","つき・げつ","bulan","月曜日（げつようび）"),
    Vocab("火","ひ・か","api","火曜日（かようび）"),
    Vocab("水","みず・すい","air","水曜日（すいようび）"),
    Vocab("木","き・もく","pohon/kayu","木曜日（もくようび）"),
    Vocab("金","かね・きん","uang/emas","金曜日（きんようび）"),
    Vocab("土","つち・ど","tanah","土曜日（どようび）"),
    Vocab("人","ひと・じん","orang","日本人（にほんじん）"),
    Vocab("口","くち・こう","mulut","入口（いりぐち）"),
    Vocab("目","め・もく","mata","目（め）"),
    Vocab("山","やま・さん","gunung","富士山（ふじさん）"),
    Vocab("川","かわ・せん","sungai","川（かわ）"),
    Vocab("田","た・でん","sawah","田中（たなか）"),
    Vocab("日","にち・じつ","hari","日曜日（にちようび）"),
    Vocab("本","ほん","buku/asal","日本（にほん）"),
    Vocab("大","おお・だい","besar","大学（だいがく）"),
    Vocab("小","ちい・しょう","kecil","小学校（しょうがっこう）"),
    Vocab("中","なか・ちゅう","dalam/tengah","中国（ちゅうごく）"),
    Vocab("上","うえ・じょう","atas","上（うえ）"),
    Vocab("下","した・か","bawah","下（した）"),
    Vocab("左","ひだり","kiri","左（ひだり）"),
    Vocab("右","みぎ","kanan","右（みぎ）"),
    Vocab("山","やま","gunung","山へ行きます。"),
    Vocab("学","がく","belajar","学生（がくせい）"),
    Vocab("生","せい・い","hidup/lahir","先生（せんせい）"),
    Vocab("先","さき・せん","sebelumnya/di depan","先生（せんせい）"),
    Vocab("年","とし・ねん","tahun","一年（いちねん）"),
    Vocab("時","とき・じ","waktu/jam","三時（さんじ）"),
    Vocab("半","はん","setengah","三時半（さんじはん）"),
    Vocab("行","い・こう","pergi","銀行（ぎんこう）")
)

private val grammar = listOf(
    Grammar("A は B です","A adalah B","私は学生です。","Saya pelajar."),
    Grammar("A は B じゃありません","A bukan B","私は先生じゃありません。","Saya bukan guru."),
    Grammar("A は B ですか","Apakah A adalah B?","田中さんは日本人ですか。","Apakah Tanaka orang Jepang?"),
    Grammar("N も","juga","私もインドネシア人です。","Saya juga orang Indonesia."),
    Grammar("N1 の N2","kepemilikan/penjelas","これは私の本です。","Ini buku saya."),
    Grammar("これ / それ / あれ","ini / itu dekat lawan bicara / itu di sana","これは何ですか。","Ini apa?"),
    Grammar("ここ / そこ / あそこ","di sini / di situ / di sana","トイレはあそこです。","Toilet ada di sana."),
    Grammar("N を Vます","objek tindakan","水を飲みます。","Saya minum air."),
    Grammar("N へ 行きます","pergi ke arah/tempat","会社へ行きます。","Saya pergi ke kantor."),
    Grammar("Tempat で Vます","melakukan kegiatan di tempat","工場で働きます。","Saya bekerja di pabrik."),
    Grammar("Waktu に Vます","melakukan pada waktu tertentu","七時に起きます。","Saya bangun pukul tujuh."),
    Grammar("A から B まで","dari A sampai B","九時から五時まで働きます。","Saya bekerja dari jam sembilan sampai lima."),
    Grammar("～ませんか","ajakan sopan","いっしょに行きませんか。","Mau pergi bersama?"),
    Grammar("～ましょう","mari kita","始めましょう。","Mari kita mulai."),
    Grammar("い-adj です","kata sifat i","この本はおもしろいです。","Buku ini menarik."),
    Grammar("な-adj です","kata sifat na","この町は静かです。","Kota ini tenang."),
    Grammar("～が好きです","suka sesuatu","日本語が好きです。","Saya suka bahasa Jepang."),
    Grammar("～があります / います","ada benda / makhluk hidup","机の上に本があります。","Ada buku di atas meja."),
    Grammar("～てください","tolong lakukan","名前を書いてください。","Tolong tulis nama."),
    Grammar("～てもいいですか","bolehkah?","ここに座ってもいいですか。","Bolehkah saya duduk di sini?")
)

private val jftQuestions = listOf(
    Question("店員：「袋は要りますか。」 Apa maksudnya?", listOf("Apakah perlu kantong?", "Mau bayar tunai?", "Berapa jumlahnya?"), 0, "袋（ふくろ） berarti kantong; 要りますか berarti perlu?"),
    Question("「少々お待ちください。」 artinya…", listOf("Silakan masuk.", "Mohon tunggu sebentar.", "Silakan pulang."), 1, "少々お待ちください adalah ungkapan sopan untuk meminta orang menunggu."),
    Question("「もう一度お願いします。」 artinya…", listOf("Tolong sekali lagi.", "Saya tidak mau.", "Saya sudah selesai."), 0, "もう一度 = sekali lagi; お願いします = mohon/tolong."),
    Question("「トイレはどこですか。」 menanyakan…", listOf("Harga toilet", "Lokasi toilet", "Nama toilet"), 1, "どこ menanyakan lokasi: di mana."),
    Question("「今日は休みです。」 artinya…", listOf("Hari ini libur.", "Hari ini bekerja.", "Besok libur."), 0, "今日 = hari ini; 休み = libur/istirahat."),
    Question("「何時に始まりますか。」 menanyakan…", listOf("Kapan/tanggal berapa?", "Mulai pukul berapa?", "Mulai di mana?"), 1, "何時（なんじ） = pukul berapa."),
    Question("「熱があります。」 artinya…", listOf("Saya demam/panas badan.", "Saya lapar.", "Saya terlambat."), 0, "熱（ねつ）があります berarti memiliki demam/panas badan."),
    Question("「ここに名前を書いてください。」 apa yang diminta?", listOf("Tulis nama di sini.", "Baca nama ini.", "Sebutkan alamat."), 0, "ここに = di sini; 名前を書いて = tulis nama."),
    Question("「電車が遅れています。」 artinya…", listOf("Kereta datang lebih awal.", "Kereta sedang terlambat.", "Kereta sudah penuh."), 1, "遅れる berarti terlambat; 遅れています menunjukkan keadaan sedang terlambat."),
    Question("「水を一つください。」 meminta…", listOf("Satu air/minuman air.", "Satu tiket.", "Satu tas."), 0, "一つ（ひとつ） = satu buah/satu item."),
    Question("「頭が痛いです。」 keluhan apa?", listOf("Sakit kepala.", "Sakit perut.", "Sakit gigi."), 0, "頭（あたま） = kepala; 痛い = sakit."),
    Question("「右に曲がってください。」 artinya…", listOf("Tolong belok kiri.", "Tolong belok kanan.", "Tolong jalan lurus."), 1, "右（みぎ） = kanan; 曲がる = berbelok."),
    Question("「この仕事は何時までですか。」 menanyakan…", listOf("Pekerjaan apa?", "Sampai jam berapa pekerjaan ini?", "Di mana tempat kerja?"), 1, "何時まで = sampai pukul berapa."),
    Question("「使い方を教えてください。」 artinya…", listOf("Tolong ajari cara menggunakan.", "Tolong jangan gunakan.", "Saya sudah tahu caranya."), 0, "使い方（つかいかた） = cara menggunakan."),
    Question("「大丈夫ですか。」 artinya…", listOf("Apakah tidak apa-apa?", "Berapa harganya?", "Apakah ini milik Anda?"), 0, "大丈夫ですか adalah pertanyaan untuk memastikan keadaan seseorang/benda.")
)

class MainActivity : ComponentActivity() {
    private var tts: TextToSpeech? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this) { status -> if (status == TextToSpeech.SUCCESS) tts?.language = Locale.JAPANESE }
        setContent { NihongoMateApp(onSpeak = { text -> tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "nihongo") }) }
    }
    override fun onDestroy() {
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun NihongoMateApp(onSpeak: (String) -> Unit) {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("nihongo_mate", 0) }
    var dark by remember { mutableStateOf(prefs.getBoolean("dark", true)) }
    var page by remember { mutableStateOf("Beranda") }
    var completed by remember { mutableIntStateOf(prefs.getInt("completed", 0)) }
    val colors = if (dark) darkColorScheme(primary = androidx.compose.ui.graphics.Color(0xFF75A7FF), secondary = androidx.compose.ui.graphics.Color(0xFF8DD8FF)) else lightColorScheme(primary = androidx.compose.ui.graphics.Color(0xFF245FC7))
    MaterialTheme(colorScheme = colors) {
        Scaffold(
            topBar = {
                CenterAlignedTopAppBar(
                    title = { Text("NihongoMate", fontWeight = FontWeight.Bold) },
                    actions = { TextButton(onClick = { dark = !dark; prefs.edit().putBoolean("dark", dark).apply() }) { Text(if (dark) "☀" else "☾") } }
                )
            },
            bottomBar = {
                NavigationBar {
                    listOf("Beranda", "Kana", "Kosakata", "Kanji", "Kaiwa", "JFT").forEach { item ->
                        NavigationBarItem(selected = page == item, onClick = { page = item },
                            icon = { Text(when(item) { "Beranda" -> "⌂"; "Kana" -> "あ"; "Kosakata" -> "語"; "Kanji" -> "漢"; "Kaiwa" -> "会"; else -> "✓" }) },
                            label = { Text(item) }, alwaysShowLabel = true)
                    }
                }
            }
        ) { padding ->
            Box(Modifier.fillMaxSize().padding(padding)) {
                when (page) {
                    "Beranda" -> HomeScreen(completed = completed, onOpen = { page = it })
                    "Kana" -> KanaScreen(onSpeak)
                    "Kosakata" -> StudyListScreen("Kosakata dasar", "50 kartu kosakata • tekan kartu untuk membuka detail", vocab, onSpeak)
                    "Kanji" -> StudyListScreen("Kanji dasar", "30 kartu kanji pengantar • bacaan bergantung pada kata", kanji, onSpeak)
                    "Kaiwa" -> KaiwaScreen(onSpeak)
                    "Tata Bahasa" -> GrammarScreen()
                    "Listening" -> ListeningScreen(onSpeak)
                    "JFT" -> JftScreen(onComplete = { completed += 1; prefs.edit().putInt("completed", completed).apply() })
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun HomeScreen(completed: Int, onOpen: (String) -> Unit) {
    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Card(shape = RoundedCornerShape(24.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Belajar Jepang, selangkah demi selangkah.", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                    Text("Fondasi → JLPT N5 → N4 → N3 → N2 → N1", style = MaterialTheme.typography.bodyMedium)
                    LinearProgressIndicator(progress = { (completed.coerceAtMost(15) / 15f) }, modifier = Modifier.fillMaxWidth())
                    Text("Latihan JFT selesai: $completed")
                }
            }
        }
        item { Text("Mulai belajar", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold) }
        item { HomeTile("あ  ア", "Hiragana & Katakana", "92 karakter dasar • pelafalan audio", "Kana", onOpen) }
        item { HomeTile("語", "Kosakata", "50 kartu • bacaan, arti, dan contoh kalimat", "Kosakata", onOpen) }
        item { HomeTile("漢", "Kanji dasar", "30 kartu pengantar dengan contoh kata", "Kanji", onOpen) }
        item { HomeTile("文", "Tata bahasa", "20 pola dasar dengan contoh dan terjemahan", "Tata Bahasa", onOpen) }
        item { HomeTile("会", "Kaiwa sehari-hari", "Salam, perkenalan, toko, dan tempat kerja", "Kaiwa", onOpen) }
        item { HomeTile("耳", "Listening berbasis TTS", "Dengarkan kalimat Jepang lalu cek arti", "Listening", onOpen) }
        item { HomeTile("✓", "Simulasi latihan JFT", "15 soal orisinal dengan pembahasan", "JFT", onOpen) }
        item {
            Text("Catatan: materi ini adalah paket belajar awal buatan sendiri, bukan seluruh silabus JLPT/JFT dan bukan soal resmi. Konten bisa ditambah bertahap.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun HomeTile(icon: String, title: String, desc: String, target: String, onOpen: (String) -> Unit) {
    Card(modifier = Modifier.fillMaxWidth().clickable { onOpen(target) }, shape = RoundedCornerShape(18.dp)) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            Text(icon, style = MaterialTheme.typography.headlineMedium, color = MaterialTheme.colorScheme.primary)
            Column(Modifier.weight(1f)) {
                Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Text(desc, style = MaterialTheme.typography.bodySmall)
            }
            Text("›", style = MaterialTheme.typography.headlineMedium)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun KanaScreen(onSpeak: (String) -> Unit) {
    var group by remember { mutableStateOf("Hiragana") }
    var index by remember { mutableIntStateOf(0) }
    var reveal by remember { mutableStateOf(false) }
    val set = kana.filter { it.group == group }
    val current = set[index % set.size]
    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Fondasi • Kana", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        SingleChoiceSegmentedButtonRow(modifier = Modifier.fillMaxWidth()) {
            listOf("Hiragana", "Katakana").forEachIndexed { i, label ->
                SegmentedButton(selected = group == label, onClick = { group = label; index = 0; reveal = false }, shape = SegmentedButtonDefaults.itemShape(i, 2)) { Text(label) }
            }
        }
        Text("Kartu ${index + 1} dari ${set.size}")
        LinearProgressIndicator(progress = { (index + 1).toFloat() / set.size }, modifier = Modifier.fillMaxWidth())
        Card(Modifier.fillMaxWidth().weight(1f), shape = RoundedCornerShape(24.dp)) {
            Column(Modifier.fillMaxSize().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                Text(current.char, style = MaterialTheme.typography.displayLarge, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                if (reveal) Text(current.romaji, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold) else Text("Coba ingat bunyinya sebelum membuka jawaban.")
                Spacer(Modifier.height(18.dp))
                Button(onClick = { onSpeak(current.char) }) { Text("🔊 Dengarkan") }
                OutlinedButton(onClick = { reveal = !reveal }) { Text(if (reveal) "Sembunyikan" else "Lihat romaji") }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { index = (index - 1 + set.size) % set.size; reveal = false }) { Text("Sebelumnya") }
                    Button(onClick = { index = (index + 1) % set.size; reveal = false }) { Text("Berikutnya") }
                }
            }
        }
    }
}

@Composable
private fun StudyListScreen(title: String, subtitle: String, cards: List<Vocab>, onSpeak: (String) -> Unit) {
    var search by remember { mutableStateOf("") }
    var selected by remember { mutableIntStateOf(-1) }
    val filtered = cards.filter { it.jp.contains(search, true) || it.reading.contains(search, true) || it.meaning.contains(search, true) }
    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        Text(title, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 12.dp))
        Text(subtitle, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(vertical = 6.dp))
        OutlinedTextField(value = search, onValueChange = { search = it }, label = { Text("Cari kanji/kata/arti") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
        LazyColumn(contentPadding = PaddingValues(vertical = 10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(filtered) { card ->
                val expanded = selected == cards.indexOf(card)
                Card(modifier = Modifier.fillMaxWidth().clickable { selected = if (expanded) -1 else cards.indexOf(card) }, shape = RoundedCornerShape(16.dp)) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(card.jp, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text(card.reading, fontWeight = FontWeight.SemiBold)
                                Text(card.meaning, style = MaterialTheme.typography.bodyMedium)
                            }
                            Text(if (expanded) "−" else "+")
                        }
                        if (expanded) {
                            Divider()
                            Text("Contoh: ${card.example}")
                            TextButton(onClick = { onSpeak(card.jp) }) { Text("🔊 Dengarkan kata") }
                        }
                    }
                }
            }
            if (filtered.isEmpty()) item { Text("Tidak ada hasil. Coba kata lain.") }
        }
    }
}

@Composable
private fun GrammarScreen() {
    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { Text("Tata bahasa dasar", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold) }
        item { Text("20 pola pengantar • contoh dan terjemahan", style = MaterialTheme.typography.bodySmall) }
        items(grammar) { g ->
            Card(shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                    Text(g.pattern, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                    Text(g.meaning)
                    Text(g.example, style = MaterialTheme.typography.titleMedium)
                    Text(g.translation, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
    }
}

@Composable
private fun KaiwaScreen(onSpeak: (String) -> Unit) {
    val dialogs = listOf(
        Triple("Perkenalan", "A: はじめまして。アリです。\\nB: はじめまして。よろしくお願いします。", "A: Salam kenal, saya Ali.\\nB: Salam kenal. Senang berkenalan dengan Anda."),
        Triple("Di toko", "A: これはいくらですか。\\nB: 千円です。\\nA: じゃ、これをください。", "A: Ini berapa harganya?\\nB: Seribu yen.\\nA: Kalau begitu, saya beli ini."),
        Triple("Di tempat kerja", "A: もう一度お願いします。\\nB: はい、わかりました。", "A: Tolong sekali lagi.\\nB: Baik, saya mengerti."),
        Triple("Menanyakan lokasi", "A: トイレはどこですか。\\nB: あそこです。", "A: Toilet di mana?\\nB: Di sana.")
    )
    var idx by remember { mutableIntStateOf(0) }
    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Kaiwa sehari-hari", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Text("Situasi ${idx + 1} dari ${dialogs.size}")
        Card(Modifier.fillMaxWidth().weight(1f), shape = RoundedCornerShape(22.dp)) {
            Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                Text(dialogs[idx].first, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Text(dialogs[idx].second, style = MaterialTheme.typography.titleMedium)
                Divider()
                Text(dialogs[idx].third)
                Spacer(Modifier.height(8.dp))
                Button(onClick = { onSpeak(dialogs[idx].second.replace("\\n", "。")) }) { Text("🔊 Dengarkan dialog") }
            }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            OutlinedButton(onClick = { idx = (idx - 1 + dialogs.size) % dialogs.size }) { Text("Sebelumnya") }
            Button(onClick = { idx = (idx + 1) % dialogs.size }) { Text("Dialog berikutnya") }
        }
    }
}

@Composable
private fun ListeningScreen(onSpeak: (String) -> Unit) {
    val qs = listOf(
        Triple("毎朝、七時に起きます。", "Saya bangun pukul tujuh setiap pagi.", listOf("Saya bangun pukul tujuh setiap pagi.", "Saya tidur pukul tujuh setiap malam.", "Saya belajar setiap hari.")),
        Triple("日曜日は働きません。", "Hari Minggu saya tidak bekerja.", listOf("Hari Minggu saya bekerja.", "Hari Minggu saya tidak bekerja.", "Saya bekerja setiap hari.")),
        Triple("駅で友達に会います。", "Saya bertemu teman di stasiun.", listOf("Saya bertemu teman di stasiun.", "Saya pergi ke sekolah.", "Saya membeli tiket di toko."))
    )
    var idx by remember { mutableIntStateOf(0) }
    var selected by remember { mutableIntStateOf(-1) }
    var checked by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Listening • latihan TTS", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Text("Ini latihan mendengar dari text-to-speech, bukan rekaman ujian resmi.")
        Card(Modifier.fillMaxWidth().weight(1f)) {
            Column(Modifier.fillMaxSize().padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("Soal ${idx + 1} dari ${qs.size}")
                Button(onClick = { onSpeak(qs[idx].first) }) { Text("▶ Putar kalimat Jepang") }
                Text("Pilih arti kalimat yang didengar:")
                qs[idx].third.forEachIndexed { i, option ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        RadioButton(selected = selected == i, onClick = { selected = i; checked = false })
                        Text(option)
                    }
                }
                Button(onClick = { checked = true }, enabled = selected >= 0) { Text("Periksa") }
                if (checked) Text(if (qs[idx].third[selected] == qs[idx].second) "Benar! ${qs[idx].second}" else "Belum tepat. Jawaban: ${qs[idx].second}")
            }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            OutlinedButton(onClick = { idx = (idx - 1 + qs.size) % qs.size; selected = -1; checked = false }) { Text("Sebelumnya") }
            Button(onClick = { idx = (idx + 1) % qs.size; selected = -1; checked = false }) { Text("Berikutnya") }
        }
    }
}

@Composable
private fun JftScreen(onComplete: () -> Unit) {
    var idx by remember { mutableIntStateOf(0) }
    var selected by remember { mutableIntStateOf(-1) }
    var checked by remember { mutableStateOf(false) }
    var correct by remember { mutableIntStateOf(0) }
    var finished by remember { mutableStateOf(false) }
    val q = jftQuestions[idx]
    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Latihan JFT-Basic A2", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Text("Soal orisinal untuk latihan • ${idx + 1}/${jftQuestions.size}")
        LinearProgressIndicator(progress = { (idx + 1).toFloat() / jftQuestions.size }, modifier = Modifier.fillMaxWidth())
        if (finished) {
            Card(Modifier.fillMaxWidth().weight(1f), shape = RoundedCornerShape(22.dp)) {
                Column(Modifier.fillMaxSize().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                    Text("Latihan selesai!", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                    Text("$correct / ${jftQuestions.size} benar", style = MaterialTheme.typography.titleLarge)
                    Text("Nilai: ${correct * 100 / jftQuestions.size}/100")
                    Spacer(Modifier.height(12.dp))
                    Button(onClick = { idx = 0; selected = -1; checked = false; correct = 0; finished = false }) { Text("Ulangi latihan") }
                }
            }
        } else {
            Card(Modifier.fillMaxWidth().weight(1f), shape = RoundedCornerShape(22.dp)) {
                Column(Modifier.fillMaxSize().padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(q.prompt, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                    q.options.forEachIndexed { i, option ->
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            RadioButton(selected = selected == i, onClick = { if (!checked) selected = i })
                            Text(option)
                        }
                    }
                    Button(onClick = {
                        checked = true
                        if (selected == q.answer) correct += 1
                    }, enabled = selected >= 0 && !checked) { Text("Periksa jawaban") }
                    if (checked) {
                        Text(if (selected == q.answer) "Benar!" else "Belum tepat.", fontWeight = FontWeight.Bold, color = if (selected == q.answer) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error)
                        Text(q.explanation)
                        Button(onClick = {
                            if (idx == jftQuestions.lastIndex) { finished = true; onComplete() }
                            else { idx += 1; selected = -1; checked = false }
                        }) { Text(if (idx == jftQuestions.lastIndex) "Lihat hasil" else "Soal berikutnya") }
                    }
                }
            }
        }
    }
}
