# NihongoMate — starter v3

Aplikasi Android belajar bahasa Jepang dengan Jetpack Compose.

## Isi versi ini
- Fondasi hiragana dan katakana dasar (92 karakter, tanpa dakuten/handakuten dan kombinasi).
- 50 kartu kosakata dasar dengan bacaan, arti, contoh, pencarian, dan TTS.
- 30 kartu kanji pengantar dengan bacaan/arti/contoh.
- 20 pola tata bahasa pengantar.
- Dialog kaiwa untuk perkenalan, toko, tempat kerja, dan menanyakan lokasi.
- Latihan listening memakai Android Text-to-Speech (bukan rekaman ujian).
- 15 soal latihan orisinal bergaya situasi sehari-hari untuk latihan JFT-Basic, dengan penjelasan dan hasil.
- Pilihan tema terang/gelap dan hitungan latihan JFT tersimpan lokal.

## Catatan
Ini adalah paket belajar awal yang dapat dikembangkan lebih lanjut, bukan silabus lengkap JLPT N5–N1 dan bukan soal resmi JFT-Basic. Tidak ada klaim bahwa konten ini mencakup seluruh ujian.

## Build
Buka proyek `NihongoMate_old` di Android Studio atau gunakan workflow GitHub Actions yang menunjuk ke folder proyek hasil ekstraksi.
