# NihongoMate v0.5.0 — source project

NihongoMate is an Android Japanese-learning starter app built with Kotlin and Jetpack Compose.

## Changes in v0.5.0
- Kana quiz is a 10-question session with answer checking, next-question flow, score, correct/incorrect totals, final result, and retry.
- JLPT N5, N4, N3, N2, and N1 screens now route to separate starter vocabulary, kanji, and grammar collections instead of showing the same N5 list at every level.
- Search and item detail views remain available for vocabulary and kanji.
- JFT-Basic practice questions are original practice material, not official or leaked exam questions.
- Japanese speech uses Android TextToSpeech and availability/voice quality depends on the device.

## Important content note
This is a growing starter collection, not a complete JLPT N5–N1 curriculum. Counts shown in the app reflect the actual entries bundled in this source. More verified vocabulary, kanji, grammar, kaiwa, reading, and JFT-style practice content should be added in future releases. JLPT and JFT-Basic are different tests; practice content should be organized accordingly.

## Build
Open the `NihongoMate` folder in Android Studio, or build using Gradle with Java 17:

```bash
gradle assembleDebug
```

The debug APK is generated at `app/build/outputs/apk/debug/app-debug.apk`.
