# NihongoMate v1.0.0 — source project

Android Japanese-learning app built with Kotlin and Jetpack Compose.

## Changes in v1.0.0
- Expanded kana practice with dakuten/handakuten, common yoon combinations, small tsu, and the katakana long-vowel mark. Quiz sessions randomize the character order and support both kana → romaji and romaji → kana.
- Added 50 vocabulary entries, 40 kanji entries, and 40 grammar entries across N5–N1 (10 vocabulary, 8 kanji, and 8 grammar entries per level).
- Expanded kaiwa from 12 to 24 situations, including workplace communication, safety, schedules, directions, and asking for clarification.
- Expanded the original JFT-Basic-style practice bank with 16 contextual questions. Each session shuffles question and answer-option order while preserving answer correctness.
- Vocabulary/kanji study screens retain their material and quiz modes from earlier versions.

## Content note
This is an expanding practice collection, not a complete official JLPT N5–N1 curriculum and not an official JFT-Basic question bank. JLPT and JFT-Basic are different tests. Review readings and context as you study.

## Build
Use Java 17 and Gradle. Open the `NihongoMate` folder in Android Studio or run `gradle assembleDebug` from that folder. The debug APK is generated at `app/build/outputs/apk/debug/app-debug.apk`.
