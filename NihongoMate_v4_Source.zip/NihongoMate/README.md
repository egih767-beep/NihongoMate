# NihongoMate v4 (source project)

Aplikasi Android Kotlin + Jetpack Compose untuk belajar bahasa Jepang.

## Fitur yang tersedia
- Kartu belajar hiragana dan katakana dasar (46 karakter masing-masing) dengan audio TTS perangkat.
- Mode kuis kana interaktif: pilihan jawaban, pemeriksaan jawaban, skor, dan reset.
- Kartu kosakata dan kanji dengan pencarian, bacaan, arti, contoh, dan TTS.
- Materi pengantar tata bahasa dan kaiwa.
- Latihan listening berbasis TTS (bukan rekaman audio penutur asli).
- Latihan JFT-Basic dengan soal orisinal, pembahasan, dan nilai.
- Halaman jalur JLPT N5, N4, N3, N2, N1 yang semuanya dapat dibuka.
- Preferensi tema terang/gelap dan hitungan latihan JFT tersimpan lokal.

## Batasan saat ini
Ini adalah versi aplikasi belajar awal, bukan kurikulum lengkap untuk seluruh JLPT N5-N1 dan bukan kumpulan soal resmi JLPT/JFT. Halaman level menyediakan peta fokus dan akses ke materi yang sudah tersedia; jumlah materi per level perlu dikembangkan lagi.

## Build
Gunakan JDK 17 dan Gradle 8.9, lalu jalankan:
`gradle assembleDebug`

APK debug berada di `app/build/outputs/apk/debug/app-debug.apk`.
