# NihongoMate — Android starter project

A native Android starter app for Japanese study. Includes a dashboard and starter modules for JLPT N5–N1 and JFT-Basic, light/dark theme switching, sample kanji/vocabulary quizzes, text-to-speech audio, and microphone speech recognition.

## Build
1. Install Android Studio (current stable) and Android SDK.
2. Open this folder in Android Studio.
3. Allow Gradle sync to finish.
4. Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Android Studio will show the generated APK location.

This environment generated the source project, not a verified APK binary. The project has not been compiled or device-tested here.

## Current scope
This is a functional prototype scaffold with sample content, not a complete JLPT N5–N1 or JFT question bank. Expand and verify the content before relying on it for exam preparation. JFT-Basic and JLPT are separate exam modes.

## Technical choices
- Kotlin + Jetpack Compose
- Material 3 UI
- Android TextToSpeech for Japanese audio
- Android SpeechRecognizer for microphone practice
- Local sample content; no login/backend yet
- INTERNET and RECORD_AUDIO permissions included

## Next milestones
1. Add reviewed content packs for kanji/vocabulary by level.
2. Add real listening clips and comprehension items.
3. Build kaiwa role-play and speaking feedback.
4. Add JFT-style timed practice and scoring.
5. Persist progress with Room/DataStore.
6. Optional cloud sync/account system.
