package com.ell.nihongomate

import android.os.Bundle
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import java.util.Locale

private data class Vocab(val jp: String, val reading: String, val meaning: String, val example: String)
private data class Kana(val char: String, val romaji: String, val group: String)
private data class Grammar(val pattern: String, val meaning: String, val example: String, val translation: String)
private data class Question(val prompt: String, val options: List<String>, val answer: Int, val explanation: String)

private val kana = listOf(
    Kana("あ","a","Hiragana"), Kana("い","i","Hiragana"), Kana("う","u","Hiragana"), Kana("え","e","Hiragana"), Kana("お","o","Hiragana"),
    Kana("か","ka","Hiragana"), Kana("き","ki","Hiragana"), Kana("く","ku","Hiragana"), Kana("け","ke","Hiragana"), Kana("こ","ko","Hiragana"),
    Kana("さ","sa","Hiragana"), Kana("し","shi","Hiragana"), Kana("す","su","Hiragana"), Kana("せ","se","Hiragana"), Kana("そ","so","Hiragana"),
    Kana("た","ta","Hiragana"), Kana("ち","chi","Hiragana"), Kana("つ","tsu","Hiragana"), Kana("て","te","Hiragana"), Kana("と","to","Hiragana"),
    Kana("な","na","Hiragana"), Kana("に","ni","Hiragana"), Kana("ぬ","nu","Hiragana"), Kana("ね","ne","Hiragana"), Kana("の","no","Hiragana"),
    Kana("は","ha","Hiragana"), Kana("ひ","hi","Hiragana"), Kana("ふ","fu","Hiragana"), Kana("へ","he","Hiragana"), Kana("ほ","ho","Hiragana"),
    Kana("ま","ma","Hiragana"), Kana("み","mi","Hiragana"), Kana("む","mu","Hiragana"), Kana("め","me","Hiragana"), Kana("も","mo","Hiragana"),
    Kana("や","ya","Hiragana"), Kana("ゆ","yu","Hiragana"), Kana("よ","yo","Hiragana"),
    Kana("ら","ra","Hiragana"), Kana("り","ri","Hiragana"), Kana("る","ru","Hiragana"), Kana("れ","re","Hiragana"), Kana("ろ","ro","Hiragana"),
    Kana("わ","wa","Hiragana"), Kana("を","o / wo","Hiragana"), Kana("ん","n","Hiragana"),
    Kana("ア","a","Katakana"), Kana("イ","i","Katakana"), Kana("ウ","u","Katakana"), Kana("エ","e","Katakana"), Kana("オ","o","Katakana"),
    Kana("カ","ka","Katakana"), Kana("キ","ki","Katakana"), Kana("ク","ku","Katakana"), Kana("ケ","ke","Katakana"), Kana("コ","ko","Katakana"),
    Kana("サ","sa","Katakana"), Kana("シ","shi","Katakana"), Kana("ス","su","Katakana"), Kana("セ","se","Katakana"), Kana("ソ","so","Katakana"),
    Kana("タ","ta","Katakana"), Kana("チ","chi","Katakana"), Kana("ツ","tsu","Katakana"), Kana("テ","te","Katakana"), Kana("ト","to","Katakana"),
    Kana("ナ","na","Katakana"), Kana("ニ","ni","Katakana"), Kana("ヌ","nu","Katakana"), Kana("ネ","ne","Katakana"), Kana("ノ","no","Katakana"),
    Kana("ハ","ha","Katakana"), Kana("ヒ","hi","Katakana"), Kana("フ","fu","Katakana"), Kana("ヘ","he","Katakana"), Kana("ホ","ho","Katakana"),
    Kana("マ","ma","Katakana"), Kana("ミ","mi","Katakana"), Kana("ム","mu","Katakana"), Kana("メ","me","Katakana"), Kana("モ","mo","Katakana"),
    Kana("ヤ","ya","Katakana"), Kana("ユ","yu","Katakana"), Kana("ヨ","yo","Katakana"),
    Kana("ラ","ra","Katakana"), Kana("リ","ri","Katakana"), Kana("ル","ru","Katakana"), Kana("レ","re","Katakana"), Kana("ロ","ro","Katakana"),
    Kana("ワ","wa","Katakana"), Kana("ヲ","o / wo","Katakana"), Kana("ン","n","Katakana")
)

private val vocab = listOf(
    Vocab("私","わたし","saya","私はインドネシア人です。"),
    Vocab("人","ひと","orang","あの人は先生です。"),
    Vocab("学生","がくせい","pelajar/mahasiswa","私は学生です。"),
    Vocab("先生","せんせい","guru","田中先生です。"),
    Vocab("会社員","かいしゃいん","pegawai perusahaan","父は会社員です。"),
    Vocab("日本","にほん","Jepang","日本へ行きます。"),
    Vocab("国","くに","negara","お国はどちらですか。"),
    Vocab("友達","ともだち","teman","友達と話します。"),
    Vocab("家族","かぞく","keluarga","家族は四人です。"),
    Vocab("家","いえ","rumah","家に帰ります。"),
    Vocab("学校","がっこう","sekolah","学校へ行きます。"),
    Vocab("会社","かいしゃ","perusahaan/kantor","会社は九時からです。"),
    Vocab("駅","えき","stasiun","駅で会います。"),
    Vocab("店","みせ","toko","あの店は安いです。"),
    Vocab("本","ほん","buku","本を読みます。"),
    Vocab("新聞","しんぶん","koran","新聞を読みます。"),
    Vocab("水","みず","air","水をください。"),
    Vocab("お茶","おちゃ","teh","お茶を飲みます。"),
    Vocab("ご飯","ごはん","nasi/makanan","ご飯を食べます。"),
    Vocab("パン","パン","roti","パンを買います。"),
    Vocab("食べます","たべます","makan","朝ご飯を食べます。"),
    Vocab("飲みます","のみます","minum","水を飲みます。"),
    Vocab("行きます","いきます","pergi","会社へ行きます。"),
    Vocab("来ます","きます","datang","友達が来ます。"),
    Vocab("帰ります","かえります","pulang","六時に帰ります。"),
    Vocab("見ます","みます","melihat/menonton","テレビを見ます。"),
    Vocab("聞きます","ききます","mendengar/bertanya","音楽を聞きます。"),
    Vocab("読みます","よみます","membaca","本を読みます。"),
    Vocab("書きます","かきます","menulis","名前を書きます。"),
    Vocab("買います","かいます","membeli","パンを買います。"),
    Vocab("働きます","はたらきます","bekerja","工場で働きます。"),
    Vocab("休みます","やすみます","beristirahat/libur","日曜日は休みます。"),
    Vocab("勉強します","べんきょうします","belajar","日本語を勉強します。"),
    Vocab("今日","きょう","hari ini","今日は暑いです。"),
    Vocab("明日","あした","besok","明日、働きます。"),
    Vocab("昨日","きのう","kemarin","昨日、勉強しました。"),
    Vocab("毎日","まいにち","setiap hari","毎日、日本語を勉強します。"),
    Vocab("朝","あさ","pagi","朝、七時に起きます。"),
    Vocab("夜","よる","malam","夜、日本語を勉強します。"),
    Vocab("時間","じかん","waktu/jam","時間があります。"),
    Vocab("大きい","おおきい","besar","大きい家です。"),
    Vocab("小さい","ちいさい","kecil","小さい犬です。"),
    Vocab("新しい","あたらしい","baru","新しい車です。"),
    Vocab("古い","ふるい","lama/tua","古い本です。"),
    Vocab("高い","たかい","mahal/tinggi","この時計は高いです。"),
    Vocab("安い","やすい","murah","この店は安いです。"),
    Vocab("暑い","あつい","panas (cuaca)","今日は暑いです。"),
    Vocab("おいしい","おいしい","enak","この料理はおいしいです。"),
    Vocab("便利","べんり","praktis","このアプリは便利です。"),
    Vocab("大丈夫","だいじょうぶ","tidak apa-apa","大丈夫です。")
)


private val kanji = listOf(
    Vocab("日","ひ・にち","hari, matahari","日本（にほん）"),
    Vocab("月","つき・げつ","bulan","月曜日（げつようび）"),
    Vocab("火","ひ・か","api","火曜日（かようび）"),
    Vocab("水","みず・すい","air","水曜日（すいようび）"),
    Vocab("木","き・もく","pohon/kayu","木曜日（もくようび）"),
    Vocab("金","かね・きん","uang/emas","金曜日（きんようび）"),
    Vocab("土","つち・ど","tanah","土曜日（どようび）"),
    Vocab("人","ひと・じん","orang","日本人（にほんじん）"),
    Vocab("口","くち・こう","mulut","入口（いりぐち）"),
    Vocab("目","め・もく","mata","目（め）"),
    Vocab("山","やま・さん","gunung","富士山（ふじさん）"),
    Vocab("川","かわ・せん","sungai","川（かわ）"),
    Vocab("田","た・でん","sawah","田中（たなか）"),
    Vocab("日","にち・じつ","hari","日曜日（にちようび）"),
    Vocab("本","ほん","buku/asal","日本（にほん）"),
    Vocab("大","おお・だい","besar","大学（だいがく）"),
    Vocab("小","ちい・しょう","kecil","小学校（しょうがっこう）"),
    Vocab("中","なか・ちゅう","dalam/tengah","中国（ちゅうごく）"),
    Vocab("上","うえ・じょう","atas","上（うえ）"),
    Vocab("下","した・か","bawah","下（した）"),
    Vocab("左","ひだり","kiri","左（ひだり）"),
    Vocab("右","みぎ","kanan","右（みぎ）"),
    Vocab("山","やま","gunung","山へ行きます。"),
    Vocab("学","がく","belajar","学生（がくせい）"),
    Vocab("生","せい・い","hidup/lahir","先生（せんせい）"),
    Vocab("先","さき・せん","sebelumnya/di depan","先生（せんせい）"),
    Vocab("年","とし・ねん","tahun","一年（いちねん）"),
    Vocab("時","とき・じ","waktu/jam","三時（さんじ）"),
    Vocab("半","はん","setengah","三時半（さんじはん）"),
    Vocab("行","い・こう","pergi","銀行（ぎんこう）")
)

private val grammar = listOf(
    Grammar("A は B です","A adalah B","私は学生です。","Saya pelajar."),
    Grammar("A は B じゃありません","A bukan B","私は先生じゃありません。","Saya bukan guru."),
    Grammar("A は B ですか","Apakah A adalah B?","田中さんは日本人ですか。","Apakah Tanaka orang Jepang?"),
    Grammar("N も","juga","私もインドネシア人です。","Saya juga orang Indonesia."),
    Grammar("N1 の N2","kepemilikan/penjelas","これは私の本です。","Ini buku saya."),
    Grammar("これ / それ / あれ","ini / itu dekat lawan bicara / itu di sana","これは何ですか。","Ini apa?"),
    Grammar("ここ / そこ / あそこ","di sini / di situ / di sana","トイレはあそこです。","Toilet ada di sana."),
    Grammar("N を Vます","objek tindakan","水を飲みます。","Saya minum air."),
    Grammar("N へ 行きます","pergi ke arah/tempat","会社へ行きます。","Saya pergi ke kantor."),
    Grammar("Tempat で Vます","melakukan kegiatan di tempat","工場で働きます。","Saya bekerja di pabrik."),
    Grammar("Waktu に Vます","melakukan pada waktu tertentu","七時に起きます。","Saya bangun pukul tujuh."),
    Grammar("A から B まで","dari A sampai B","九時から五時まで働きます。","Saya bekerja dari jam sembilan sampai lima."),
    Grammar("～ませんか","ajakan sopan","いっしょに行きませんか。","Mau pergi bersama?"),
    Grammar("～ましょう","mari kita","始めましょう。","Mari kita mulai."),
    Grammar("い-adj です","kata sifat i","この本はおもしろいです。","Buku ini menarik."),
    Grammar("な-adj です","kata sifat na","この町は静かです。","Kota ini tenang."),
    Grammar("～が好きです","suka sesuatu","日本語が好きです。","Saya suka bahasa Jepang."),
    Grammar("～があります / います","ada benda / makhluk hidup","机の上に本があります。","Ada buku di atas meja."),
    Grammar("～てください","tolong lakukan","名前を書いてください。","Tolong tulis nama."),
    Grammar("～てもいいですか","bolehkah?","ここに座ってもいいですか。","Bolehkah saya duduk di sini?")
)

private val jftQuestions = listOf(
    Question("店員：「袋は要りますか。」 Apa maksudnya?", listOf("Apakah perlu kantong?", "Mau bayar tunai?", "Berapa jumlahnya?"), 0, "袋（ふくろ） berarti kantong; 要りますか berarti perlu?"),
    Question("「少々お待ちください。」 artinya…", listOf("Silakan masuk.", "Mohon tunggu sebentar.", "Silakan pulang."), 1, "少々お待ちください adalah ungkapan sopan untuk meminta orang menunggu."),
    Question("「もう一度お願いします。」 artinya…", listOf("Tolong sekali lagi.", "Saya tidak mau.", "Saya sudah selesai."), 0, "もう一度 = sekali lagi; お願いします = mohon/tolong."),
    Question("「トイレはどこですか。」 menanyakan…", listOf("Harga toilet", "Lokasi toilet", "Nama toilet"), 1, "どこ menanyakan lokasi: di mana."),
    Question("「今日は休みです。」 artinya…", listOf("Hari ini libur.", "Hari ini bekerja.", "Besok libur."), 0, "今日 = hari ini; 休み = libur/istirahat."),
    Question("「何時に始まりますか。」 menanyakan…", listOf("Kapan/tanggal berapa?", "Mulai pukul berapa?", "Mulai di mana?"), 1, "何時（なんじ） = pukul berapa."),
    Question("「熱があります。」 artinya…", listOf("Saya demam/panas badan.", "Saya lapar.", "Saya terlambat."), 0, "熱（ねつ）があります berarti memiliki demam/panas badan."),
    Question("「ここに名前を書いてください。」 apa yang diminta?", listOf("Tulis nama di sini.", "Baca nama ini.", "Sebutkan alamat."), 0, "ここに = di sini; 名前を書いて = tulis nama."),
    Question("「電車が遅れています。」 artinya…", listOf("Kereta datang lebih awal.", "Kereta sedang terlambat.", "Kereta sudah penuh."), 1, "遅れる berarti terlambat; 遅れています menunjukkan keadaan sedang terlambat."),
    Question("「水を一つください。」 meminta…", listOf("Satu air/minuman air.", "Satu tiket.", "Satu tas."), 0, "一つ（ひとつ） = satu buah/satu item."),
    Question("「頭が痛いです。」 keluhan apa?", listOf("Sakit kepala.", "Sakit perut.", "Sakit gigi."), 0, "頭（あたま） = kepala; 痛い = sakit."),
    Question("「右に曲がってください。」 artinya…", listOf("Tolong belok kiri.", "Tolong belok kanan.", "Tolong jalan lurus."), 1, "右（みぎ） = kanan; 曲がる = berbelok."),
    Question("「この仕事は何時までですか。」 menanyakan…", listOf("Pekerjaan apa?", "Sampai jam berapa pekerjaan ini?", "Di mana tempat kerja?"), 1, "何時まで = sampai pukul berapa."),
    Question("「使い方を教えてください。」 artinya…", listOf("Tolong ajari cara menggunakan.", "Tolong jangan gunakan.", "Saya sudah tahu caranya."), 0, "使い方（つかいかた） = cara menggunakan."),
    Question("「大丈夫ですか。」 artinya…", listOf("Apakah tidak apa-apa?", "Berapa harganya?", "Apakah ini milik Anda?"), 0, "大丈夫ですか adalah pertanyaan untuk memastikan keadaan seseorang/benda."),
    Question("「先に帰ってもいいですか。」 artinya…", listOf("Bolehkah saya pulang lebih dulu?", "Bolehkah saya datang besok?", "Saya sudah pulang."), 0, "先に = lebih dulu; 帰ってもいいですか = bolehkah pulang?"),
    Question("「ゆっくり話してください。」 artinya…", listOf("Tolong bicara pelan-pelan.", "Tolong tulis dengan cepat.", "Tolong dengarkan."), 0, "ゆっくり = perlahan; 話してください = tolong bicara."),
    Question("「この機械の使い方が分かりません。」 maksudnya…", listOf("Saya tidak mengerti cara memakai mesin ini.", "Mesin ini sudah rusak.", "Saya membuat mesin ini."), 0, "使い方 = cara menggunakan; 分かりません = tidak mengerti."),
    Question("「明日は残業があります。」 artinya…", listOf("Besok ada lembur.", "Besok libur.", "Hari ini lembur."), 0, "明日 = besok; 残業（ざんぎょう） = lembur."),
    Question("「ここで写真を撮らないでください。」 artinya…", listOf("Tolong jangan mengambil foto di sini.", "Tolong ambil foto di sini.", "Foto ini milik saya."), 0, "～ないでください = tolong jangan melakukan."),
    Question("「体の具合が悪いので、休みます。」 artinya…", listOf("Karena badan tidak enak, saya akan istirahat.", "Karena sehat, saya bekerja.", "Saya ingin libur besok."), 0, "具合が悪い = kondisi badan tidak baik; ので = karena."),
    Question("「書類を確認してから、サインしてください。」 apa urutannya?", listOf("Periksa dokumen, lalu tanda tangan.", "Tanda tangan lalu buang dokumen.", "Kirim dokumen tanpa membaca."), 0, "～てから = setelah melakukan sesuatu."),
    Question("「集合時間は八時半です。」 artinya…", listOf("Waktu berkumpul pukul 08.30.", "Waktu pulang pukul 08.00.", "Rapat berlangsung selama delapan jam."), 0, "集合時間 = waktu berkumpul; 八時半 = pukul setengah sembilan."),
    Question("「この商品は売り切れです。」 artinya…", listOf("Barang ini habis terjual.", "Barang ini gratis.", "Barang ini baru datang."), 0, "売り切れ（うりきれ） = habis terjual."),
    Question("「困ったことがあったら、相談してください。」 maksudnya…", listOf("Kalau ada masalah, silakan berkonsultasi.", "Jangan bertanya kepada siapa pun.", "Masalahnya sudah selesai."), 0, "困ったこと = hal yang menyulitkan; 相談する = berkonsultasi."),
    Question("「電車が事故で止まっています。」 artinya…", listOf("Kereta berhenti karena kecelakaan.", "Kereta tiba lebih awal.", "Kecelakaan terjadi di dalam bus."), 0, "事故 = kecelakaan; 止まっています = sedang berhenti."),
    Question("「明日までに提出してください。」 artinya…", listOf("Tolong serahkan paling lambat besok.", "Tolong serahkan bulan depan.", "Jangan serahkan dokumen."), 0, "～までに = paling lambat sebelum/sampai batas waktu."),
    Question("「忘れ物がないか確認しましょう。」 artinya…", listOf("Mari periksa apakah ada barang tertinggal.", "Mari membeli barang baru.", "Mari menunggu kereta."), 0, "忘れ物 = barang tertinggal; 確認しましょう = mari periksa."),
    Question("「説明がよく聞こえませんでした。」 artinya…", listOf("Penjelasannya tidak terdengar dengan jelas.", "Saya sudah memahami semuanya.", "Penjelasannya sangat mudah."), 0, "聞こえませんでした = tidak terdengar.")
)

// Materi tambahan dipisahkan per level agar N4-N1 tidak menampilkan daftar N5 yang sama.
private val levelVocab: Map<String, List<Vocab>> = mapOf(
    "N5" to vocab,
    "N4" to listOf(
        Vocab("経験","けいけん","pengalaman","日本で働いた経験があります。"), Vocab("必要","ひつよう","perlu/diperlukan","パスポートが必要です。"),
        Vocab("準備","じゅんび","persiapan","旅行の準備をします。"), Vocab("説明","せつめい","penjelasan","使い方を説明します。"),
        Vocab("連絡","れんらく","menghubungi/kontak","あとで連絡します。"), Vocab("予定","よてい","rencana/jadwal","明日の予定があります。"),
        Vocab("約束","やくそく","janji","友達と約束しました。"), Vocab("遅れる","おくれる","terlambat","電車に遅れました。"),
        Vocab("間に合う","まにあう","tepat waktu/keburu","仕事に間に合いました。"), Vocab("続ける","つづける","melanjutkan","日本語の勉強を続けます。"),
        Vocab("決める","きめる","memutuskan","日にちを決めます。"), Vocab("運転","うんてん","mengemudi","父は車を運転します。"),
        Vocab("安心","あんしん","lega/tenang","無事で安心しました。"), Vocab("心配","しんぱい","khawatir","家族が心配です。"),
        Vocab("故障","こしょう","kerusakan","機械が故障しました。"), Vocab("直す","なおす","memperbaiki","機械を直します。"),
        Vocab("片付ける","かたづける","merapikan","部屋を片付けます。"), Vocab("特に","とくに","terutama/khususnya","特に問題はありません。"),
        Vocab("例えば","たとえば","misalnya","例えば、これは安いです。"), Vocab("最近","さいきん","akhir-akhir ini","最近忙しいです。")
    ),
    "N3" to listOf(
        Vocab("影響","えいきょう","pengaruh","天気は仕事に影響します。"), Vocab("原因","げんいん","penyebab","事故の原因を調べます。"),
        Vocab("結果","けっか","hasil/akibat","試験の結果が出ました。"), Vocab("状況","じょうきょう","situasi/kondisi","状況を説明してください。"),
        Vocab("目的","もくてき","tujuan","日本へ行く目的は仕事です。"), Vocab("方法","ほうほう","cara/metode","別の方法を考えます。"),
        Vocab("機会","きかい","kesempatan","いい機会だと思います。"), Vocab("関係","かんけい","hubungan","仕事と関係があります。"),
        Vocab("確認","かくにん","memastikan/konfirmasi","内容を確認してください。"), Vocab("判断","はんだん","penilaian/keputusan","自分で判断します。"),
        Vocab("比べる","くらべる","membandingkan","二つの方法を比べます。"), Vocab("増える","ふえる","bertambah","外国人の数が増えています。"),
        Vocab("減る","へる","berkurang","時間が減りました。"), Vocab("伝える","つたえる","menyampaikan","結果を先生に伝えます。"),
        Vocab("受け取る","うけとる","menerima","荷物を受け取りました。"), Vocab("申し込む","もうしこむ","mendaftar","試験に申し込みます。"),
        Vocab("利用","りよう","penggunaan/memanfaatkan","このサービスを利用します。"), Vocab("参加","さんか","partisipasi","会議に参加します。"),
        Vocab("意見","いけん","pendapat","意見を聞かせてください。"), Vocab("社会","しゃかい","masyarakat","社会について考えます。")
    ),
    "N2" to listOf(
        Vocab("維持","いじ","mempertahankan","健康を維持することが大切です。"), Vocab("導入","どうにゅう","penerapan/pengenalan","新しい制度を導入します。"),
        Vocab("傾向","けいこう","kecenderungan","最近その傾向があります。"), Vocab("課題","かだい","tantangan/tugas","課題を解決する必要があります。"),
        Vocab("対策","たいさく","langkah penanganan","事故の対策を考えます。"), Vocab("状況","じょうきょう","situasi","現在の状況を把握します。"),
        Vocab("実施","じっし","pelaksanaan","来月から実施します。"), Vocab("影響力","えいきょうりょく","pengaruh/kekuatan memengaruhi","彼は大きな影響力があります。"),
        Vocab("効率","こうりつ","efisiensi","効率を上げましょう。"), Vocab("責任","せきにん","tanggung jawab","自分の責任を果たします。"),
        Vocab("評価","ひょうか","evaluasi/penilaian","結果を評価します。"), Vocab("傾向","けいこう","tren/kecenderungan","消費の傾向が変わりました。"),
        Vocab("主張","しゅちょう","klaim/pendapat kuat","自分の主張を説明します。"), Vocab("根拠","こんきょ","dasar/bukti","根拠を示してください。"),
        Vocab("把握","はあく","memahami/menguasai situasi","全体を把握します。"), Vocab("適切","てきせつ","tepat/sesuai","適切な方法を選びます。"),
        Vocab("深刻","しんこく","serius/gawat","深刻な問題です。"), Vocab("改善","かいぜん","perbaikan","作業の流れを改善します。"),
        Vocab("実際","じっさい","kenyataannya/praktik","実際に試してみます。"), Vocab("一方","いっぽう","di sisi lain","一方、費用もかかります。")
    ),
    "N1" to listOf(
        Vocab("促進","そくしん","promosi/percepatan","地域交流を促進します。"), Vocab("懸念","けねん","kekhawatiran","安全面への懸念があります。"),
        Vocab("顕著","けんちょ","menonjol/nyata","顕著な変化が見られます。"), Vocab("妥当","だとう","wajar/pantas","妥当な判断だと思います。"),
        Vocab("余地","よち","ruang/peluang","改善の余地があります。"), Vocab("趣旨","しゅし","maksud/inti","説明の趣旨を理解します。"),
        Vocab("遂げる","とげる","mencapai/menuntaskan","大きな発展を遂げました。"), Vocab("伴う","ともなう","menyertai","変化にはリスクが伴います。"),
        Vocab("促す","うながす","mendorong","注意を促します。"), Vocab("損なう","そこなう","merusak/mengurangi","信頼を損ないます。"),
        Vocab("踏まえる","ふまえる","berdasarkan/mempertimbangkan","事実を踏まえて判断します。"), Vocab("一概に","いちがいに","secara umum tanpa pengecualian","一概には言えません。"),
        Vocab("おおむね","おおむね","secara garis besar","計画はおおむね順調です。"), Vocab("著しい","いちじるしい","sangat nyata/mencolok","著しい進歩がありました。"),
        Vocab("不可欠","ふかけつ","sangat penting/tidak dapat dihilangkan","協力が不可欠です。"), Vocab("根本","こんぽん","dasar/akar","根本的な原因を探します。"),
        Vocab("見込み","みこみ","prospek/perkiraan","回復の見込みがあります。"), Vocab("余儀なくされる","よぎなくされる","terpaksa harus","計画の変更を余儀なくされました。"),
        Vocab("矛盾","むじゅん","kontradiksi","説明に矛盾があります。"), Vocab("配慮","はいりょ","pertimbangan/perhatian","相手への配慮が必要です。")
    )
)

private val levelKanji: Map<String, List<Vocab>> = mapOf(
    "N5" to kanji,
    "N4" to listOf(
        Vocab("会","かい・あう","bertemu/pertemuan","会社（かいしゃ）"), Vocab("同","どう・おなじ","sama","同じ（おなじ）"), Vocab("事","こと・じ","hal/perkara","仕事（しごと）"),
        Vocab("自","じ・みずから","diri sendiri","自分（じぶん）"), Vocab("社","しゃ","perusahaan/masyarakat","会社（かいしゃ）"), Vocab("発","はつ","berangkat/keluar","出発（しゅっぱつ）"),
        Vocab("者","しゃ・もの","orang","医者（いしゃ）"), Vocab("地","ち","tanah/tempat","地下鉄（ちかてつ）"), Vocab("業","ぎょう","pekerjaan/bisnis","授業（じゅぎょう）"),
        Vocab("方","かた・ほう","cara/orang (sopan)","読み方（よみかた）"), Vocab("新","しん・あたらしい","baru","新聞（しんぶん）"), Vocab("場","ば・じょう","tempat","場所（ばしょ）")
    ),
    "N3" to listOf(
        Vocab("政","せい","politik/pemerintahan","政治（せいじ）"), Vocab("経","けい","melewati/ekonomi","経験（けいけん）"), Vocab("済","さい","selesai/ekonomi","経済（けいざい）"),
        Vocab("法","ほう","hukum/cara","方法（ほうほう）"), Vocab("制","せい","sistem/kontrol","制度（せいど）"), Vocab("機","き","mesin/kesempatan","機会（きかい）"),
        Vocab("関","かん","hubungan","関係（かんけい）"), Vocab("係","けい・かかり","petugas/hubungan","係員（かかりいん）"), Vocab("調","ちょう・しらべる","menyelidiki","調査（ちょうさ）"),
        Vocab("査","さ","pemeriksaan","調査（ちょうさ）"), Vocab("報","ほう","laporan","情報（じょうほう）"), Vocab("情","じょう","perasaan/informasi","情報（じょうほう）")
    ),
    "N2" to listOf(
        Vocab("論","ろん","teori/argumen","議論（ぎろん）"), Vocab("証","しょう","bukti","証明（しょうめい）"), Vocab("評","ひょう","penilaian","評価（ひょうか）"),
        Vocab("価","か","nilai/harga","価値（かち）"), Vocab("提","てい","mengajukan","提案（ていあん）"), Vocab("案","あん","usulan/rencana","提案（ていあん）"),
        Vocab("構","こう","struktur","構造（こうぞう）"), Vocab("造","ぞう","membuat/struktur","製造（せいぞう）"), Vocab("際","さい","kesempatan/saat","実際（じっさい）"),
        Vocab("限","げん・かぎる","batas","制限（せいげん）"), Vocab("規","き","aturan/standar","規則（きそく）"), Vocab("則","そく","aturan","規則（きそく）")
    ),
    "N1" to listOf(
        Vocab("顧","こ","memperhatikan","顧客（こきゃく）"), Vocab("慮","りょ","mempertimbangkan","配慮（はいりょ）"), Vocab("懸","けん","menggantung/kekhawatiran","懸念（けねん）"),
        Vocab("念","ねん","pikiran/perhatian","懸念（けねん）"), Vocab("促","そく","mendorong","促進（そくしん）"), Vocab("進","しん・すすむ","maju","促進（そくしん）"),
        Vocab("著","ちょ・いちじるしい","menonjol/menulis","著しい（いちじるしい）"), Vocab("顕","けん","tampak jelas","顕著（けんちょ）"), Vocab("妥","だ","pantas","妥当（だとう）"),
        Vocab("矛","む","tombak","矛盾（むじゅん）"), Vocab("盾","じゅん","perisai","矛盾（むじゅん）"), Vocab("踏","とう・ふむ","menginjak/berdasarkan","踏まえる（ふまえる）")
    )
)

private val levelGrammar: Map<String, List<Grammar>> = mapOf(
    "N5" to grammar,
    "N4" to listOf(
        Grammar("～たことがあります","pernah melakukan","日本へ行ったことがあります。","Saya pernah pergi ke Jepang."),
        Grammar("～たり～たりします","melakukan hal seperti A dan B","日曜日は本を読んだり、映画を見たりします。","Hari Minggu saya membaca buku, menonton film, dan sebagainya."),
        Grammar("～ながら","sambil","音楽を聞きながら勉強します。","Saya belajar sambil mendengarkan musik."),
        Grammar("～てから","setelah melakukan","仕事が終わってから帰ります。","Saya pulang setelah pekerjaan selesai."),
        Grammar("～なければなりません","harus","薬を飲まなければなりません。","Saya harus minum obat."),
        Grammar("～なくてもいいです","tidak harus","明日は来なくてもいいです。","Besok tidak perlu datang."),
        Grammar("～と思います","saya pikir","明日は雨だと思います。","Saya pikir besok hujan."),
        Grammar("～ので","karena (alasan) ","熱があるので、休みます。","Karena demam, saya istirahat."),
        Grammar("～かもしれません","mungkin","午後、雨が降るかもしれません。","Mungkin hujan sore nanti."),
        Grammar("～やすい / ～にくい","mudah/sulit dilakukan","このペンは書きやすいです。","Pulpen ini mudah digunakan untuk menulis.")
    ),
    "N3" to listOf(
        Grammar("～ようにする","berusaha membiasakan","毎日漢字を読むようにしています。","Saya berusaha membaca kanji setiap hari."),
        Grammar("～ことになる","diputuskan bahwa","来月転勤することになりました。","Diputuskan saya pindah tugas bulan depan."),
        Grammar("～ばかり","baru saja","今、着いたばかりです。","Saya baru saja tiba."),
        Grammar("～おかげで","berkat","先生のおかげで合格しました。","Berkat guru, saya lulus."),
        Grammar("～せいで","gara-gara (akibat negatif)","雨のせいで試合が中止になりました。","Pertandingan dibatalkan gara-gara hujan."),
        Grammar("～に対して","terhadap","お客様に対して丁寧に話します。","Berbicara sopan kepada pelanggan."),
        Grammar("～によると","menurut sumber","天気予報によると、明日は晴れです。","Menurut ramalan cuaca, besok cerah."),
        Grammar("～たびに","setiap kali","この歌を聞くたびに故郷を思い出します。","Setiap mendengar lagu ini, saya teringat kampung halaman."),
        Grammar("～わけではない","bukan berarti","嫌いなわけではありません。","Bukan berarti saya tidak suka."),
        Grammar("～ようになる","menjadi bisa/mulai","日本語が少し話せるようになりました。","Saya jadi bisa sedikit berbicara bahasa Jepang.")
    ),
    "N2" to listOf(
        Grammar("～わけにはいかない","tidak bisa begitu saja (karena kewajiban)","明日は大事な試験なので休むわけにはいきません。","Karena besok ujian penting, saya tidak bisa absen."),
        Grammar("～に違いない","pasti","彼はもう帰ったに違いありません。","Dia pasti sudah pulang."),
        Grammar("～一方で","di sisi lain","便利な一方で、危険もあります。","Di satu sisi praktis, tetapi ada bahaya juga."),
        Grammar("～に応じて","sesuai dengan","能力に応じて仕事を任せます。","Pekerjaan diberikan sesuai kemampuan."),
        Grammar("～に関して","mengenai","契約に関して質問があります。","Saya punya pertanyaan mengenai kontrak."),
        Grammar("～をめぐって","seputar/mengenai (perdebatan)","計画をめぐって意見が分かれました。","Pendapat terbelah seputar rencana itu."),
        Grammar("～にすぎない","tidak lebih dari","これは一例にすぎません。","Ini tidak lebih dari satu contoh."),
        Grammar("～ものの","meskipun","説明を読んだものの、よく分かりません。","Meski sudah membaca penjelasan, saya belum paham."),
        Grammar("～に伴って","seiring dengan","人口の増加に伴って問題も増えました。","Seiring bertambahnya penduduk, masalah juga bertambah."),
        Grammar("～次第","segera setelah","詳細が分かり次第、連絡します。","Saya akan menghubungi segera setelah detail diketahui.")
    ),
    "N1" to listOf(
        Grammar("～を余儀なくされる","terpaksa harus","悪天候で計画の変更を余儀なくされました。","Cuaca buruk membuat kami terpaksa mengubah rencana."),
        Grammar("～に即して","sesuai/berdasarkan","現状に即して判断します。","Kami menilai berdasarkan kondisi aktual."),
        Grammar("～を踏まえて","dengan mempertimbangkan","調査結果を踏まえて方針を決めます。","Menentukan kebijakan dengan mempertimbangkan hasil survei."),
        Grammar("～にかかわらず","tanpa memandang","経験の有無にかかわらず応募できます。","Bisa melamar terlepas dari ada tidaknya pengalaman."),
        Grammar("～とはいえ","meskipun dikatakan","春とはいえ、まだ寒いです。","Meski sudah disebut musim semi, masih dingin."),
        Grammar("～に越したことはない","tidak ada yang lebih baik daripada","早めに準備するに越したことはありません。","Tidak ada yang lebih baik daripada bersiap lebih awal."),
        Grammar("～を皮切りに","dimulai dari","東京を皮切りに全国で開催されます。","Dimulai dari Tokyo, acara diadakan di seluruh negeri."),
        Grammar("～ならでは","khas/unik untuk","これは日本ならではの習慣です。","Ini kebiasaan yang khas Jepang."),
        Grammar("～をものともせず","tanpa gentar terhadap","彼は批判をものともせず挑戦しました。","Dia terus menantang tanpa gentar terhadap kritik."),
        Grammar("～極まりない","sangat/amat (formal)","失礼極まりない態度です。","Sikap yang sangat tidak sopan.")
    )
)


// Paket tambahan v0.6: data tambahan ditaruh terpisah agar tiap level tidak memakai daftar N5 yang sama.
private val extraLevelVocab: Map<String, List<Vocab>> = mapOf(
    "N5" to listOf(
        Vocab("駅員","えきいん","petugas stasiun","駅員に聞きます。"), Vocab("電車","でんしゃ","kereta listrik","電車で会社へ行きます。"),
        Vocab("会社員","かいしゃいん","pegawai perusahaan","兄は会社員です。"), Vocab("病院","びょういん","rumah sakit","病院へ行きます。"),
        Vocab("銀行","ぎんこう","bank","銀行でお金を下ろします。"), Vocab("郵便局","ゆうびんきょく","kantor pos","郵便局はどこですか。"),
        Vocab("右","みぎ","kanan","右へ曲がってください。"), Vocab("左","ひだり","kiri","左にあります。"),
        Vocab("前","まえ","depan/sebelum","駅の前で会います。"), Vocab("後ろ","うしろ","belakang","家の後ろに公園があります。"),
        Vocab("近い","ちかい","dekat","駅は近いです。"), Vocab("遠い","とおい","jauh","学校は遠いです。"),
        Vocab("忙しい","いそがしい","sibuk","今日は忙しいです。"), Vocab("楽しい","たのしい","menyenangkan","日本語の勉強は楽しいです。"),
        Vocab("難しい","むずかしい","sulit","漢字は難しいです。"), Vocab("易しい","やさしい","mudah","この問題は易しいです。"),
        Vocab("天気","てんき","cuaca","今日の天気はいいです。"), Vocab("雨","あめ","hujan","雨が降っています。"),
        Vocab("雪","ゆき","salju","雪が降りました。"), Vocab("風","かぜ","angin","風が強いです。"),
        Vocab("写真","しゃしん","foto","写真を撮ります。"), Vocab("旅行","りょこう","perjalanan/wisata","日本へ旅行したいです。"),
        Vocab("料理","りょうり","masakan/memasak","日本料理が好きです。"), Vocab("映画","えいが","film","週末に映画を見ます。"),
        Vocab("音楽","おんがく","musik","音楽を聞きます。"), Vocab("部屋","へや","kamar","部屋を掃除します。"),
        Vocab("窓","まど","jendela","窓を開けます。"), Vocab("机","つくえ","meja","机の上に本があります。"),
        Vocab("椅子","いす","kursi","椅子に座ります。"), Vocab("毎週","まいしゅう","setiap minggu","毎週日本語を勉強します。")
    ),
    "N4" to listOf(
        Vocab("経験","けいけん","pengalaman","日本で働いた経験があります。"), Vocab("準備","じゅんび","persiapan","試験の準備をします。"),
        Vocab("説明","せつめい","penjelasan","もう一度説明してください。"), Vocab("連絡","れんらく","menghubungi/kabar","あとで連絡します。"),
        Vocab("予定","よてい","rencana/jadwal","明日の予定を確認します。"), Vocab("必要","ひつよう","perlu/diperlukan","パスポートが必要です。"),
        Vocab("安全","あんぜん","aman/keselamatan","安全に気をつけてください。"), Vocab("危険","きけん","bahaya","ここは危険です。"),
        Vocab("注意","ちゅうい","perhatian/berhati-hati","足元に注意してください。"), Vocab("理由","りゆう","alasan","理由を教えてください。"),
        Vocab("途中","とちゅう","di tengah perjalanan/proses","帰る途中で買い物をしました。"), Vocab("場合","ばあい","kasus/keadaan","分からない場合は聞いてください。"),
        Vocab("間に合う","まにあう","tepat waktu","電車に間に合いました。"), Vocab("遅れる","おくれる","terlambat","バスが遅れています。"),
        Vocab("届ける","とどける","mengantarkan/menyerahkan","書類を届けます。"), Vocab("片付ける","かたづける","merapikan","部屋を片付けます。"),
        Vocab("壊れる","こわれる","rusak (intransitif)","機械が壊れました。"), Vocab("直す","なおす","memperbaiki","自転車を直します。"),
        Vocab("申し込む","もうしこむ","mendaftar/mengajukan","試験に申し込みます。"), Vocab("間違い","まちがい","kesalahan","間違いを直します。")
    ),
    "N3" to listOf(
        Vocab("影響","えいきょう","pengaruh","天気は仕事に影響します。"), Vocab("結果","けっか","hasil","試験の結果を確認します。"),
        Vocab("原因","げんいん","penyebab","事故の原因を調べます。"), Vocab("解決","かいけつ","penyelesaian","問題を解決します。"),
        Vocab("比較","ひかく","perbandingan","二つの方法を比較します。"), Vocab("判断","はんだん","penilaian/keputusan","自分で判断してください。"),
        Vocab("提案","ていあん","usulan","新しい方法を提案します。"), Vocab("参加","さんか","partisipasi","会議に参加します。"),
        Vocab("変更","へんこう","perubahan","予定を変更しました。"), Vocab("確認","かくにん","memastikan/konfirmasi","内容を確認してください。"),
        Vocab("増加","ぞうか","peningkatan","利用者が増加しています。"), Vocab("減少","げんしょう","penurunan","事故が減少しました。"),
        Vocab("対応","たいおう","penanganan/respons","問題に対応します。"), Vocab("協力","きょうりょく","kerja sama","みんなで協力します。"),
        Vocab("関係","かんけい","hubungan","仕事と関係があります。"), Vocab("調査","ちょうさ","penyelidikan/survei","原因を調査します。"),
        Vocab("情報","じょうほう","informasi","正しい情報が必要です。"), Vocab("制度","せいど","sistem","新しい制度が始まりました。"),
        Vocab("機会","きかい","kesempatan","いい機会だと思います。"), Vocab("努力","どりょく","usaha","毎日努力しています。")
    ),
    "N2" to listOf(
        Vocab("傾向","けいこう","kecenderungan","最近この傾向が強くなっています。"), Vocab("状況","じょうきょう","situasi","状況を説明してください。"),
        Vocab("課題","かだい","tantangan/tugas","課題を整理します。"), Vocab("対策","たいさく","langkah penanganan","対策を考えます。"),
        Vocab("効率","こうりつ","efisiensi","効率を上げる必要があります。"), Vocab("責任","せきにん","tanggung jawab","責任を持って仕事をします。"),
        Vocab("評価","ひょうか","evaluasi/penilaian","結果を評価します。"), Vocab("根拠","こんきょ","dasar/bukti","根拠を示してください。"),
        Vocab("適切","てきせつ","tepat/sesuai","適切な方法を選びます。"), Vocab("深刻","しんこく","serius/gawat","深刻な問題です。"),
        Vocab("改善","かいぜん","perbaikan","作業手順を改善します。"), Vocab("実際","じっさい","kenyataannya/praktik","実際に試してみます。"),
        Vocab("一方","いっぽう","di sisi lain","一方で費用もかかります。"), Vocab("維持","いじ","mempertahankan","品質を維持します。"),
        Vocab("導入","どうにゅう","penerapan/pengenalan","新しい設備を導入します。"), Vocab("削減","さくげん","pengurangan","無駄な費用を削減します。"),
        Vocab("傾向","けいこう","kecenderungan","消費の傾向が変わりました。"), Vocab("実績","じっせき","rekam hasil/prestasi","これまでの実績を説明します。"),
        Vocab("条件","じょうけん","syarat/kondisi","条件を確認してください。"), Vocab("対象","たいしょう","sasaran/objek","対象となる人に連絡します。")
    ),
    "N1" to listOf(
        Vocab("促進","そくしん","percepatan/pemajuan","地域交流を促進します。"), Vocab("懸念","けねん","kekhawatiran","安全面への懸念があります。"),
        Vocab("顕著","けんちょ","menonjol/nyata","顕著な変化が見られます。"), Vocab("妥当","だとう","wajar/pantas","妥当な判断だと思います。"),
        Vocab("余地","よち","ruang/peluang","改善の余地があります。"), Vocab("趣旨","しゅし","maksud/inti","説明の趣旨を理解します。"),
        Vocab("遂げる","とげる","mencapai/menuntaskan","大きな発展を遂げました。"), Vocab("伴う","ともなう","menyertai","変化にはリスクが伴います。"),
        Vocab("促す","うながす","mendorong","注意を促します。"), Vocab("損なう","そこなう","merusak/mengurangi","信頼を損ないます。"),
        Vocab("踏まえる","ふまえる","berdasarkan/mempertimbangkan","事実を踏まえて判断します。"), Vocab("一概に","いちがいに","secara mutlak/tanpa pengecualian","一概には言えません。"),
        Vocab("おおむね","おおむね","secara garis besar","計画はおおむね順調です。"), Vocab("著しい","いちじるしい","sangat nyata/mencolok","著しい進歩がありました。"),
        Vocab("不可欠","ふかけつ","sangat penting/mutlak diperlukan","協力が不可欠です。"), Vocab("根本","こんぽん","dasar/akar","根本的な原因を探します。"),
        Vocab("見込み","みこみ","prospek/perkiraan","回復の見込みがあります。"), Vocab("余儀なくされる","よぎなくされる","terpaksa harus","計画の変更を余儀なくされました。"),
        Vocab("矛盾","むじゅん","kontradiksi","説明に矛盾があります。"), Vocab("配慮","はいりょ","pertimbangan/perhatian","相手への配慮が必要です。")
    )
)

private val extraLevelKanji: Map<String, List<Vocab>> = mapOf(
    "N5" to listOf(
        Vocab("円","えん","yen/lingkaran","千円（せんえん）"), Vocab("万","まん","sepuluh ribu","一万円（いちまんえん）"),
        Vocab("白","しろ・はく","putih","白い（しろい）"), Vocab("黒","くろ・こく","hitam","黒い（くろい）"),
        Vocab("赤","あか・せき","merah","赤い（あかい）"), Vocab("青","あお・せい","biru","青い（あおい）"),
        Vocab("天","てん","langit","天気（てんき）"), Vocab("気","き","energi/perasaan","元気（げんき）"),
        Vocab("雨","あめ・う","hujan","雨の日（あめのひ）"), Vocab("電","でん","listrik","電車（でんしゃ）"),
        Vocab("車","くるま・しゃ","mobil/kendaraan","電車（でんしゃ）"), Vocab("語","ご","bahasa/kata","日本語（にほんご）"),
        Vocab("名","な・めい","nama","名前（なまえ）"), Vocab("午","ご","siang","午後（ごご）"),
        Vocab("今","いま・こん","sekarang","今週（こんしゅう）")
    ),
    "N4" to listOf(
        Vocab("世","せ・よ","dunia/generasi","世界（せかい）"), Vocab("界","かい","dunia/batas","世界（せかい）"),
        Vocab("品","ひん・しな","barang/kualitas","商品（しょうひん）"), Vocab("物","もの・ぶつ","benda","荷物（にもつ）"),
        Vocab("特","とく","khusus","特別（とくべつ）"), Vocab("別","べつ","berbeda/terpisah","別々（べつべつ）"),
        Vocab("使","つかう・し","menggunakan","使用（しよう）"), Vocab("送","おくる・そう","mengirim","送金（そうきん）"),
        Vocab("貸","かす・たい","meminjamkan","貸し出し（かしだし）"), Vocab("借","かりる・しゃく","meminjam","借金（しゃっきん）"),
        Vocab("着","きる・ちゃく","memakai/tiba","到着（とうちゃく）"), Vocab("乗","のる・じょう","naik kendaraan","乗車（じょうしゃ）")
    ),
    "N3" to listOf(
        Vocab("政","せい","politik/pemerintahan","政治（せいじ）"), Vocab("経","けい","melewati/ekonomi","経験（けいけん）"),
        Vocab("済","さい","selesai/ekonomi","経済（けいざい）"), Vocab("法","ほう","hukum/cara","方法（ほうほう）"),
        Vocab("制","せい","sistem/kontrol","制度（せいど）"), Vocab("機","き","mesin/kesempatan","機会（きかい）"),
        Vocab("関","かん","hubungan","関係（かんけい）"), Vocab("係","けい・かかり","petugas/hubungan","係員（かかりいん）"),
        Vocab("調","ちょう・しらべる","menyelidiki","調査（ちょうさ）"), Vocab("査","さ","pemeriksaan","調査（ちょうさ）"),
        Vocab("報","ほう","laporan","情報（じょうほう）"), Vocab("情","じょう","perasaan/informasi","情報（じょうほう）")
    ),
    "N2" to listOf(
        Vocab("論","ろん","teori/argumen","議論（ぎろん）"), Vocab("証","しょう","bukti","証明（しょうめい）"),
        Vocab("評","ひょう","penilaian","評価（ひょうか）"), Vocab("価","か","nilai/harga","価値（かち）"),
        Vocab("提","てい","mengajukan","提案（ていあん）"), Vocab("案","あん","usulan/rencana","提案（ていあん）"),
        Vocab("構","こう","struktur","構造（こうぞう）"), Vocab("造","ぞう","membuat/struktur","製造（せいぞう）"),
        Vocab("際","さい","kesempatan/saat","実際（じっさい）"), Vocab("限","げん・かぎる","batas","制限（せいげん）"),
        Vocab("規","き","aturan/standar","規則（きそく）"), Vocab("則","そく","aturan","規則（きそく）")
    ),
    "N1" to listOf(
        Vocab("顧","こ","memperhatikan","顧客（こきゃく）"), Vocab("慮","りょ","mempertimbangkan","配慮（はいりょ）"),
        Vocab("懸","けん","kekhawatiran","懸念（けねん）"), Vocab("念","ねん","pikiran/perhatian","懸念（けねん）"),
        Vocab("促","そく","mendorong","促進（そくしん）"), Vocab("進","しん・すすむ","maju","促進（そくしん）"),
        Vocab("著","ちょ・いちじるしい","menonjol/menulis","著しい（いちじるしい）"), Vocab("顕","けん","tampak jelas","顕著（けんちょ）"),
        Vocab("妥","だ","pantas","妥当（だとう）"), Vocab("矛","む","tombak","矛盾（むじゅん）"),
        Vocab("盾","じゅん","perisai","矛盾（むじゅん）"), Vocab("踏","とう・ふむ","menginjak/berdasarkan","踏まえる（ふまえる）")
    )
)

private val extraLevelGrammar: Map<String, List<Grammar>> = mapOf(
    "N5" to listOf(
        Grammar("N は N じゃありません","bukan","これは本じゃありません。","Ini bukan buku."),
        Grammar("N は どこですか","menanyakan lokasi","銀行はどこですか。","Bank ada di mana?"),
        Grammar("N は いくらですか","menanyakan harga","この本はいくらですか。","Buku ini berapa harganya?"),
        Grammar("V ませんか","ajakan sopan","いっしょに昼ご飯を食べませんか。","Mau makan siang bersama?"),
        Grammar("V ました","bentuk lampau sopan","昨日、勉強しました。","Kemarin saya belajar."),
        Grammar("V ませんでした","lampau negatif sopan","昨日、働きませんでした。","Kemarin saya tidak bekerja."),
        Grammar("N が あります","ada benda","机の上に本があります。","Ada buku di atas meja."),
        Grammar("N が います","ada makhluk hidup","部屋に猫がいます。","Ada kucing di kamar.")
    ),
    "N4" to listOf(
        Grammar("～てみます","mencoba melakukan","この料理を食べてみます。","Saya akan mencoba makan masakan ini."),
        Grammar("～ておきます","melakukan sebagai persiapan","会議の前に資料を読んでおきます。","Saya membaca materi terlebih dahulu sebelum rapat."),
        Grammar("～そうです（様態）","kelihatannya","このケーキはおいしそうです。","Kue ini kelihatannya enak."),
        Grammar("～すぎます","terlalu","食べすぎました。","Saya makan terlalu banyak."),
        Grammar("～ほうがいいです","sebaiknya","早く寝たほうがいいです。","Sebaiknya tidur lebih awal."),
        Grammar("～なくなります","menjadi tidak lagi","日本語が少し分かるようになりました。","Saya jadi sedikit mengerti bahasa Jepang."),
        Grammar("～でしょう","mungkin/dugaan","明日は晴れるでしょう。","Besok mungkin cerah."),
        Grammar("～のに","padahal/meskipun","勉強したのに、忘れました。","Padahal sudah belajar, saya lupa.")
    ),
    "N3" to listOf(
        Grammar("～ことにする","memutuskan sendiri","毎日歩くことにしました。","Saya memutuskan berjalan kaki setiap hari."),
        Grammar("～ことになっている","sudah menjadi aturan/jadwal","ここでは靴を脱ぐことになっています。","Di sini sudah menjadi aturan untuk melepas sepatu."),
        Grammar("～ようとする","berusaha/akan melakukan","出かけようとした時、電話が鳴りました。","Saat hendak pergi, telepon berbunyi."),
        Grammar("～ば～ほど","semakin… semakin…","練習すればするほど上手になります。","Semakin berlatih, semakin mahir."),
        Grammar("～最中に","di tengah-tengah","食事の最中に電話がありました。","Ada telepon di tengah makan."),
        Grammar("～に比べて","dibandingkan dengan","去年に比べて忙しいです。","Lebih sibuk dibandingkan tahun lalu."),
        Grammar("～として","sebagai","通訳として働いています。","Saya bekerja sebagai penerjemah."),
        Grammar("～わりに","meskipun/untuk ukuran","この店は安いわりにおいしいです。","Untuk ukuran toko murah, rasanya enak.")
    ),
    "N2" to listOf(
        Grammar("～に基づいて","berdasarkan","データに基づいて判断します。","Menilai berdasarkan data."),
        Grammar("～を通じて","melalui/sepanjang","研修を通じて多くを学びました。","Saya belajar banyak melalui pelatihan."),
        Grammar("～にかけては","dalam hal","彼は料理にかけては誰にも負けません。","Dalam hal memasak, dia tidak kalah dari siapa pun."),
        Grammar("～に限らず","tidak terbatas pada","若者に限らず人気があります。","Populer bukan hanya di kalangan anak muda."),
        Grammar("～を問わず","tanpa memandang","年齢を問わず参加できます。","Bisa berpartisipasi tanpa memandang usia."),
        Grammar("～に反して","bertentangan dengan","予想に反して結果はよかったです。","Bertentangan dengan perkiraan, hasilnya bagus."),
        Grammar("～に沿って","sesuai dengan/mengikuti","計画に沿って進めます。","Melanjutkan sesuai rencana."),
        Grammar("～だけあって","memang pantas karena","経験があるだけあって上手です。","Memang mahir karena berpengalaman.")
    ),
    "N1" to listOf(
        Grammar("～を禁じ得ない","tidak dapat menahan (perasaan)","その話を聞いて驚きを禁じ得ません。","Mendengar cerita itu, saya tidak dapat menahan rasa terkejut."),
        Grammar("～にたえる","layak untuk","この作品は読むにたえる内容です。","Karya ini layak dibaca."),
        Grammar("～と相まって","berpadu dengan","努力と運が相まって成功しました。","Usaha berpadu dengan keberuntungan sehingga berhasil."),
        Grammar("～をおいてほかにない","tidak ada selain","この仕事は彼をおいてほかにいません。","Tidak ada orang lain selain dia untuk pekerjaan ini."),
        Grammar("～ならまだしも","kalau … masih bisa dimaklumi","一度ならまだしも、何度も遅刻するのは困ります。","Kalau sekali masih bisa dimaklumi, tetapi terlambat berkali-kali merepotkan."),
        Grammar("～に即して","sesuai/berdasarkan","現状に即して判断します。","Menilai berdasarkan kondisi aktual."),
        Grammar("～を皮切りに","dimulai dari","東京を皮切りに全国で開催されます。","Dimulai dari Tokyo, acara diadakan di seluruh negeri."),
        Grammar("～といえども","sekalipun","専門家といえども間違うことがあります。","Sekalipun ahli, kadang bisa salah.")
    )
)

// Paket fondasi v0.7: kosakata tematik tambahan untuk jalur belajar dari nol sampai N4.
private val foundationVocab: Map<String, List<Vocab>> = mapOf(
    "N5" to listOf(
        Vocab("起きます","おきます","bangun","毎朝六時に起きます。"),
        Vocab("寝ます","ねます","tidur","十一時に寝ます。"),
        Vocab("入ります","はいります","masuk","部屋に入ります。"),
        Vocab("出ます","でます","keluar","家を出ます。"),
        Vocab("開けます","あけます","membuka","窓を開けます。"),
        Vocab("閉めます","しめます","menutup","ドアを閉めます。"),
        Vocab("つけます","つけます","menyalakan","電気をつけます。"),
        Vocab("消します","けします","mematikan/menghapus","電気を消します。"),
        Vocab("待ちます","まちます","menunggu","駅で友達を待ちます。"),
        Vocab("会います","あいます","bertemu","友達に会います。"),
        Vocab("話します","はなします","berbicara","先生と話します。"),
        Vocab("使います","つかいます","menggunakan","はしを使います。"),
        Vocab("作ります","つくります","membuat","晩ご飯を作ります。"),
        Vocab("取ります","とります","mengambil","写真を取ります。"),
        Vocab("持ちます","もちます","membawa/memegang","かばんを持ちます。"),
        Vocab("置きます","おきます","meletakkan","本を机の上に置きます。"),
        Vocab("立ちます","たちます","berdiri","ここに立ってください。"),
        Vocab("座ります","すわります","duduk","いすに座ります。"),
        Vocab("歩きます","あるきます","berjalan","駅まで歩きます。"),
        Vocab("走ります","はしります","berlari","公園で走ります。"),
        Vocab("泳ぎます","およぎます","berenang","プールで泳ぎます。"),
        Vocab("遊びます","あそびます","bermain","公園で遊びます。"),
        Vocab("借ります","かります","meminjam","図書館で本を借ります。"),
        Vocab("貸します","かします","meminjamkan","友達に本を貸します。"),
        Vocab("教えます","おしえます","mengajar/memberi tahu","日本語を教えます。"),
        Vocab("習います","ならいます","belajar dari orang","先生に日本語を習います。"),
        Vocab("分かります","わかります","mengerti","日本語が少し分かります。"),
        Vocab("あります","あります","ada (benda)","机の上に本があります。"),
        Vocab("います","います","ada (makhluk hidup)","部屋に猫がいます。"),
        Vocab("買い物","かいもの","belanja","日曜日に買い物をします。"),
        Vocab("お金","おかね","uang","お金がありません。"),
        Vocab("財布","さいふ","dompet","財布を忘れました。"),
        Vocab("時計","とけい","jam","時計を見ます。"),
        Vocab("電話","でんわ","telepon","母に電話します。"),
        Vocab("携帯電話","けいたいでんわ","telepon genggam","携帯電話を使います。"),
        Vocab("入口","いりぐち","pintu masuk","入口はこちらです。"),
        Vocab("出口","でぐち","pintu keluar","出口はあそこです。"),
        Vocab("階段","かいだん","tangga","階段を上ります。"),
        Vocab("エレベーター","エレベーター","lift","エレベーターで三階へ行きます。"),
        Vocab("公園","こうえん","taman","公園で休みます。"),
        Vocab("図書館","としょかん","perpustakaan","図書館で本を読みます。"),
        Vocab("教室","きょうしつ","ruang kelas","教室に学生がいます。"),
        Vocab("質問","しつもん","pertanyaan","質問があります。"),
        Vocab("答え","こたえ","jawaban","答えを書きます。"),
        Vocab("問題","もんだい","soal/masalah","問題は難しいです。"),
        Vocab("宿題","しゅくだい","PR","宿題をします。"),
        Vocab("試験","しけん","ujian","明日は試験です。"),
        Vocab("名前","なまえ","nama","名前を書いてください。"),
        Vocab("住所","じゅうしょ","alamat","住所を教えてください。"),
        Vocab("電話番号","でんわばんごう","nomor telepon","電話番号を聞きます。"),
        Vocab("誕生日","たんじょうび","ulang tahun","今日は母の誕生日です。"),
        Vocab("天気予報","てんきよほう","prakiraan cuaca","天気予報を見ます。"),
        Vocab("晴れ","はれ","cerah","今日は晴れです。"),
        Vocab("曇り","くもり","berawan","明日は曇りです。"),
        Vocab("暑い","あつい","panas (cuaca)","今日はとても暑いです。"),
        Vocab("寒い","さむい","dingin (cuaca)","今日は寒いです。"),
        Vocab("暖かい","あたたかい","hangat","暖かい日です。"),
        Vocab("涼しい","すずしい","sejuk","夜は涼しいです。"),
        Vocab("おもしろい","おもしろい","menarik/lucu","この本はおもしろいです。"),
        Vocab("つまらない","つまらない","membosankan","この映画はつまらないです。"),
        Vocab("かわいい","かわいい","lucu/menggemaskan","この犬はかわいいです。"),
        Vocab("きれい","きれい","indah/bersih","部屋はきれいです。"),
        Vocab("静か","しずか","tenang/sepi","この町は静かです。"),
        Vocab("にぎやか","にぎやか","ramai","駅の前はにぎやかです。"),
        Vocab("有名","ゆうめい","terkenal","この町は有名です。"),
        Vocab("好き","すき","suka","日本語が好きです。"),
        Vocab("嫌い","きらい","tidak suka","魚が嫌いです。"),
        Vocab("上手","じょうず","pandai/mahir","歌が上手です。"),
        Vocab("下手","へた","kurang mahir","料理が下手です。"),
        Vocab("元気","げんき","sehat/bersemangat","お元気ですか。"),
        Vocab("親切","しんせつ","baik hati","親切な人です。"),
        Vocab("簡単","かんたん","mudah/sederhana","これは簡単です。"),
        Vocab("大変","たいへん","berat/sulit","仕事は大変です。"),
        Vocab("一緒に","いっしょに","bersama-sama","一緒に帰りましょう。"),
        Vocab("少し","すこし","sedikit","日本語が少し分かります。"),
        Vocab("たくさん","たくさん","banyak","水をたくさん飲みます。"),
        Vocab("いつも","いつも","selalu","いつも七時に起きます。"),
        Vocab("時々","ときどき","kadang-kadang","時々映画を見ます。"),
        Vocab("よく","よく","sering/dengan baik","よく勉強します。"),
        Vocab("あまり","あまり","tidak terlalu (dengan negatif)","肉をあまり食べません。"),
        Vocab("全然","ぜんぜん","sama sekali (dengan negatif)","漢字が全然分かりません。"),
        Vocab("もう","もう","sudah","もう昼ご飯を食べました。"),
        Vocab("まだ","まだ","belum/masih","まだ宿題をしていません。"),
        Vocab("そして","そして","lalu/dan","朝ご飯を食べます。そして学校へ行きます。"),
        Vocab("でも","でも","tetapi","高いです。でも、買います。")
    ),
    "N4" to listOf(
        Vocab("間に合います","まにあいます","tepat waktu/sempat","電車に間に合いました。"),
        Vocab("遅れます","おくれます","terlambat","仕事に遅れました。"),
        Vocab("急ぎます","いそぎます","bergegas","急いでください。"),
        Vocab("続けます","つづけます","melanjutkan","日本語の勉強を続けます。"),
        Vocab("決めます","きめます","memutuskan","日曜日に行くことを決めました。"),
        Vocab("調べます","しらべます","memeriksa/mencari tahu","意味を辞書で調べます。"),
        Vocab("比べます","くらべます","membandingkan","二つの仕事を比べます。"),
        Vocab("選びます","えらびます","memilih","好きな仕事を選びます。"),
        Vocab("申し込みます","もうしこみます","mendaftar/mengajukan","試験に申し込みます。"),
        Vocab("連絡します","れんらくします","menghubungi","あとで連絡します。"),
        Vocab("相談します","そうだんします","berkonsultasi","先生に相談します。"),
        Vocab("確認します","かくにんします","memastikan/memeriksa","時間を確認します。"),
        Vocab("説明します","せつめいします","menjelaskan","使い方を説明します。"),
        Vocab("案内します","あんないします","memandu","町を案内します。"),
        Vocab("紹介します","しょうかいします","memperkenalkan","友達を紹介します。"),
        Vocab("参加します","さんかします","berpartisipasi","会議に参加します。"),
        Vocab("失敗します","しっぱいします","gagal/membuat kesalahan","試験に失敗しました。"),
        Vocab("成功します","せいこうします","berhasil","計画が成功しました。"),
        Vocab("合格します","ごうかくします","lulus ujian","試験に合格しました。"),
        Vocab("落ちます","おちます","jatuh/tidak lulus","試験に落ちました。"),
        Vocab("壊れます","こわれます","rusak (intransitif)","時計が壊れました。"),
        Vocab("直します","なおします","memperbaiki","自転車を直します。"),
        Vocab("片付けます","かたづけます","merapikan","部屋を片付けます。"),
        Vocab("捨てます","すてます","membuang","ごみを捨てます。"),
        Vocab("運びます","はこびます","mengangkut","荷物を運びます。"),
        Vocab("届けます","とどけます","mengantarkan","荷物を届けます。"),
        Vocab("受け取ります","うけとります","menerima","荷物を受け取りました。"),
        Vocab("払います","はらいます","membayar","カードで払います。"),
        Vocab("返します","かえします","mengembalikan","本を図書館に返します。"),
        Vocab("間違えます","まちがえます","salah/keliru","名前を間違えました。"),
        Vocab("見つけます","みつけます","menemukan","仕事を見つけました。"),
        Vocab("見つかります","みつかります","ditemukan","鍵が見つかりました。"),
        Vocab("気をつけます","きをつけます","berhati-hati","車に気をつけてください。"),
        Vocab("慣れます","なれます","terbiasa","日本の生活に慣れました。"),
        Vocab("疲れます","つかれます","lelah","仕事で疲れました。"),
        Vocab("心配","しんぱい","khawatir","母が心配です。"),
        Vocab("安心","あんしん","lega/tenang","無事で安心しました。"),
        Vocab("必要","ひつよう","perlu/dibutuhkan","パスポートが必要です。"),
        Vocab("十分","じゅうぶん","cukup","時間は十分あります。"),
        Vocab("特別","とくべつ","khusus","今日は特別な日です。"),
        Vocab("普通","ふつう","biasa/normal","普通の大きさです。"),
        Vocab("安全","あんぜん","aman","安全に気をつけます。"),
        Vocab("危険","きけん","berbahaya","ここは危険です。"),
        Vocab("便利","べんり","praktis","駅に近くて便利です。"),
        Vocab("不便","ふべん","tidak praktis","バスが少なくて不便です。"),
        Vocab("場合","ばあい","kasus/keadaan","雨の場合、行きません。"),
        Vocab("理由","りゆう","alasan","理由を教えてください。"),
        Vocab("意見","いけん","pendapat","意見を言ってください。"),
        Vocab("予定","よてい","rencana/jadwal","明日は予定があります。"),
        Vocab("約束","やくそく","janji","友達と約束しました。"),
        Vocab("連休","れんきゅう","libur berurutan","連休に旅行します。"),
        Vocab("生活","せいかつ","kehidupan sehari-hari","日本で生活しています。"),
        Vocab("文化","ぶんか","budaya","日本の文化を学びます。"),
        Vocab("社会","しゃかい","masyarakat","社会について勉強します。"),
        Vocab("人口","じんこう","populasi","この町は人口が多いです。"),
        Vocab("景色","けしき","pemandangan","山の景色がきれいです。"),
        Vocab("気持ち","きもち","perasaan","気持ちを伝えます。"),
        Vocab("場合によって","ばあいによって","tergantung situasi","場合によって違います。"),
        Vocab("たいてい","たいてい","biasanya","たいてい家で食べます。"),
        Vocab("必ず","かならず","pasti/selalu","必ず時間を守ります。"),
        Vocab("例えば","たとえば","misalnya","例えば、日本語を勉強します。"),
        Vocab("特に","とくに","terutama","特に漢字が難しいです。"),
        Vocab("実は","じつは","sebenarnya","実は、まだ分かりません。"),
        Vocab("まず","まず","pertama-tama","まず名前を書いてください。"),
        Vocab("最後に","さいごに","terakhir","最後に確認します。"),
        Vocab("それで","それで","karena itu/lalu","雨でした。それで、行きませんでした。"),
        Vocab("それに","それに","selain itu","安いです。それに、便利です。"),
        Vocab("ところが","ところが","namun ternyata","簡単だと思いました。ところが難しかったです。")
    )
)

private val foundationKanji: Map<String, List<Vocab>> = mapOf(
    "N5" to listOf(
        Vocab("父","ちち・ふ","ayah","父は会社員です。"),
        Vocab("母","はは・ぼ","ibu","母は料理が上手です。"),
        Vocab("兄","あに・きょう","kakak laki-laki","兄は学生です。"),
        Vocab("姉","あね・し","kakak perempuan","姉は先生です。"),
        Vocab("弟","おとうと・てい","adik laki-laki","弟は十歳です。"),
        Vocab("妹","いもうと・まい","adik perempuan","妹と話します。"),
        Vocab("男","おとこ","laki-laki","男の人です。"),
        Vocab("女","おんな","perempuan","女の人です。"),
        Vocab("子","こ・し","anak","子どもがいます。"),
        Vocab("犬","いぬ","anjing","犬がいます。"),
        Vocab("猫","ねこ","kucing","猫が好きです。"),
        Vocab("魚","さかな","ikan","魚を食べます。"),
        Vocab("肉","にく","daging","肉を買います。"),
        Vocab("花","はな","bunga","花がきれいです。"),
        Vocab("山","やま","gunung","山に登ります。"),
        Vocab("川","かわ","sungai","川の近くです。"),
        Vocab("田","た","sawah","田んぼがあります。"),
        Vocab("空","そら","langit","空が青いです。"),
        Vocab("海","うみ","laut","海へ行きます。"),
        Vocab("道","みち","jalan","この道を行きます。"),
        Vocab("町","まち","kota kecil","町に住んでいます。"),
        Vocab("村","むら","desa","村は静かです。"),
        Vocab("東","ひがし","timur","東口はこちらです。"),
        Vocab("西","にし","barat","西へ行きます。"),
        Vocab("南","みなみ","selatan","南の町です。"),
        Vocab("北","きた","utara","北口で会います。"),
        Vocab("春","はる","musim semi","春は暖かいです。"),
        Vocab("夏","なつ","musim panas","夏は暑いです。"),
        Vocab("秋","あき","musim gugur","秋が好きです。"),
        Vocab("冬","ふゆ","musim dingin","冬は寒いです。"),
        Vocab("午前","ごぜん","pagi/sebelum tengah hari","午前九時です。"),
        Vocab("午後","ごご","siang/sore","午後三時です。"),
        Vocab("半","はん","setengah","七時半です。"),
        Vocab("週","しゅう","minggu","一週間休みます。"),
        Vocab("年","とし・ねん","tahun","一年日本語を勉強します。"),
        Vocab("月","つき・げつ","bulan","月がきれいです。"),
        Vocab("日","ひ・にち","hari/matahari","日曜日は休みです。"),
        Vocab("火","ひ・か","api","火曜日に働きます。"),
        Vocab("水","みず・すい","air","水を飲みます。"),
        Vocab("木","き・もく","pohon/kayu","木があります。"),
        Vocab("金","かね・きん","uang/emas","お金が必要です。"),
        Vocab("土","つち・ど","tanah","土曜日に行きます。"),
        Vocab("本","ほん","buku/asal","本を読みます。"),
        Vocab("休","やすむ・きゅう","istirahat","今日は休みです。"),
        Vocab("見","みる・けん","melihat","映画を見ます。"),
        Vocab("行","いく・こう","pergi","学校へ行きます。"),
        Vocab("来","くる・らい","datang","友達が来ます。"),
        Vocab("食","たべる・しょく","makan","食事をします。"),
        Vocab("飲","のむ・いん","minum","水を飲みます。"),
        Vocab("読","よむ・どく","membaca","本を読みます。"),
        Vocab("書","かく・しょ","menulis","名前を書きます。")
    ),
    "N4" to listOf(
        Vocab("旅","たび・りょ","perjalanan","旅行が好きです。"),
        Vocab("館","かん","gedung/bangunan","図書館へ行きます。"),
        Vocab("院","いん","institusi","病院へ行きます。"),
        Vocab("薬","くすり・やく","obat","薬を飲みます。"),
        Vocab("病","びょう","sakit","病気になりました。"),
        Vocab("医","い・いしゃ","medis/dokter","医者に聞きます。"),
        Vocab("者","もの・しゃ","orang/pihak","医者です。"),
        Vocab("屋","や・おく","toko/rumah","本屋で買います。"),
        Vocab("室","しつ","ruangan","会議室にいます。"),
        Vocab("服","ふく","pakaian","服を買います。"),
        Vocab("着","きる・ちゃく","memakai/tiba","服を着ます。"),
        Vocab("洗","あらう・せん","mencuci","手を洗います。"),
        Vocab("飯","めし・はん","nasi/makan","ご飯を食べます。"),
        Vocab("菜","な・さい","sayur","野菜を買います。"),
        Vocab("茶","ちゃ","teh","お茶を飲みます。"),
        Vocab("肉","にく","daging","肉料理が好きです。"),
        Vocab("鳥","とり","burung/ayam","鳥が飛んでいます。"),
        Vocab("牛","うし","sapi","牛乳を飲みます。"),
        Vocab("魚","さかな","ikan","魚を焼きます。"),
        Vocab("料","りょう","bahan/biaya","料理を作ります。"),
        Vocab("理","り","alasan/logika","料理が好きです。"),
        Vocab("習","ならう・しゅう","belajar","習慣を変えます。"),
        Vocab("勉","べん","usaha/belajar","勉強します。"),
        Vocab("強","つよい・きょう","kuat","強い風です。"),
        Vocab("漢","かん","Tiongkok/kanji","漢字を読みます。"),
        Vocab("字","じ","huruf","字を書きます。"),
        Vocab("試","ためす・し","mencoba/ujian","試験を受けます。"),
        Vocab("験","けん","pengalaman/ujian","試験があります。"),
        Vocab("質","しつ","mutu/pertanyaan","質問があります。"),
        Vocab("問","とう・もん","bertanya/soal","問題を解きます。"),
        Vocab("題","だい","topik/soal","宿題をします。"),
        Vocab("答","こたえる・とう","menjawab","質問に答えます。"),
        Vocab("考","かんがえる","berpikir","よく考えます。"),
        Vocab("知","しる","mengetahui","その人を知っています。"),
        Vocab("思","おもう","berpikir/merasa","そう思います。"),
        Vocab("始","はじめる","memulai","仕事を始めます。"),
        Vocab("終","おわる","selesai","授業が終わります。"),
        Vocab("働","はたらく","bekerja","工場で働きます。"),
        Vocab("事","こと・じ","hal/urusan","大事なことです。"),
        Vocab("仕","し","melayani/pekerjaan","仕事をします。"),
        Vocab("使","つかう","menggunakan","道具を使います。"),
        Vocab("作","つくる","membuat","料理を作ります。"),
        Vocab("持","もつ","membawa/memiliki","荷物を持ちます。"),
        Vocab("待","まつ","menunggu","少し待ってください。"),
        Vocab("住","すむ","tinggal","東京に住んでいます。"),
        Vocab("所","ところ・しょ","tempat","住所を書きます。"),
        Vocab("近","ちかい","dekat","駅が近いです。"),
        Vocab("遠","とおい","jauh","学校は遠いです。"),
        Vocab("明","あかるい・めい","terang/berikutnya","明日会いましょう。"),
        Vocab("暗","くらい","gelap","外は暗いです。"),
        Vocab("重","おもい","berat","荷物が重いです。")
    )
)

private val foundationGrammar: Map<String, List<Grammar>> = mapOf(
    "N5" to listOf(
        Grammar("N は N です","menyatakan identitas/benda","私はインドネシア人です。","Saya orang Indonesia."),
        Grammar("N の N","kepemilikan atau keterangan","これは私の本です。","Ini buku saya."),
        Grammar("これ・それ・あれ","ini/itu (benda)","それは何ですか。","Itu apa?"),
        Grammar("この・その・あの + N","ini/itu + kata benda","この本は新しいです。","Buku ini baru."),
        Grammar("ここ・そこ・あそこ","di sini/di situ/di sana","トイレはあそこです。","Toilet ada di sana."),
        Grammar("N も","juga","私も学生です。","Saya juga pelajar."),
        Grammar("N と N","dan (menghubungkan nomina)","パンと牛乳を買います。","Saya membeli roti dan susu."),
        Grammar("N を Vます","objek tindakan","毎日本を読みます。","Saya membaca buku setiap hari."),
        Grammar("N で Vます","tempat melakukan tindakan","図書館で勉強します。","Saya belajar di perpustakaan."),
        Grammar("N へ 行きます","pergi ke arah/tempat","日本へ行きます。","Saya pergi ke Jepang."),
        Grammar("N と Vます","melakukan bersama seseorang","友達と帰ります。","Saya pulang bersama teman."),
        Grammar("いつ・何時","menanyakan waktu","毎朝何時に起きますか。","Setiap pagi bangun jam berapa?"),
        Grammar("～から～まで","dari… sampai…","九時から五時まで働きます。","Saya bekerja dari jam 9 sampai jam 5."),
        Grammar("Vませんか","mengajak dengan sopan","一緒に勉強しませんか。","Mau belajar bersama?"),
        Grammar("Vましょう","mengajak/mengusulkan","休みましょう。","Mari beristirahat.")
    ),
    "N4" to listOf(
        Grammar("Vたことがあります","pernah melakukan","日本へ行ったことがあります。","Saya pernah pergi ke Jepang."),
        Grammar("Vたり、Vたりします","melakukan hal seperti…","日曜日は本を読んだり、映画を見たりします。","Hari Minggu saya membaca buku, menonton film, dan sebagainya."),
        Grammar("Vながら","melakukan sambil","音楽を聞きながら勉強します。","Saya belajar sambil mendengarkan musik."),
        Grammar("Vる前に","sebelum melakukan","寝る前に歯を磨きます。","Saya menggosok gigi sebelum tidur."),
        Grammar("Vた後で","setelah melakukan","仕事が終わった後で帰ります。","Saya pulang setelah pekerjaan selesai."),
        Grammar("Vるつもりです","berniat akan","来年日本へ行くつもりです。","Saya berniat pergi ke Jepang tahun depan."),
        Grammar("Vようと思います","berpikir/berencana untuk","毎日漢字を勉強しようと思います。","Saya berencana belajar kanji setiap hari."),
        Grammar("Vなければなりません","harus","明日早く起きなければなりません。","Besok saya harus bangun pagi."),
        Grammar("Vなくてもいいです","tidak perlu","今日は来なくてもいいです。","Hari ini tidak perlu datang."),
        Grammar("Vてはいけません","tidak boleh","ここで写真を撮ってはいけません。","Tidak boleh mengambil foto di sini."),
        Grammar("Vてもいいです","boleh","ここに座ってもいいですか。","Bolehkah saya duduk di sini?"),
        Grammar("～と思います","berpendapat/berpikir bahwa","日本語はおもしろいと思います。","Saya pikir bahasa Jepang menarik."),
        Grammar("～と言っていました","mengatakan bahwa","田中さんは休むと言っていました。","Tanaka mengatakan bahwa dia akan libur."),
        Grammar("～ので","karena (alasan lebih halus)","雨なので、出かけません。","Karena hujan, saya tidak pergi keluar."),
        Grammar("～のに","padahal/meskipun","薬を飲んだのに、まだ痛いです。","Padahal sudah minum obat, masih sakit."),
        Grammar("～ようになります","menjadi bisa/terbiasa","漢字が読めるようになりました。","Saya jadi bisa membaca kanji."),
        Grammar("～てしまいます","terlanjur/selesai tanpa sengaja","財布を忘れてしまいました。","Saya terlanjur lupa membawa dompet."),
        Grammar("～てあります","keadaan hasil tindakan yang disengaja","机に資料が置いてあります。","Dokumen sudah diletakkan di meja."),
        Grammar("～かもしれません","mungkin","明日は雨かもしれません。","Besok mungkin hujan."),
        Grammar("～でしょうか","pertanyaan sopan/dugaan","駅はどこでしょうか。","Kira-kira stasiun ada di mana?")
    )
)


// Paket v0.8: perluasan konten untuk SEMUA level JLPT. Materi ini adalah bahan belajar
// pengantar buatan aplikasi, bukan daftar resmi lengkap atau klaim cakupan seluruh JLPT.
private val v8Vocab: Map<String, List<Vocab>> = mapOf(
    "N5" to listOf(
        Vocab("朝ご飯","あさごはん","sarapan","朝ご飯を食べます。"), Vocab("昼ご飯","ひるごはん","makan siang","昼ご飯は十二時です。"),
        Vocab("晩ご飯","ばんごはん","makan malam","家で晩ご飯を食べます。"), Vocab("牛肉","ぎゅうにく","daging sapi","牛肉を買います。"),
        Vocab("豚肉","ぶたにく","daging babi","豚肉は食べません。"), Vocab("鳥","とり","burung/ayam","鳥がいます。"),
        Vocab("野菜","やさい","sayuran","野菜を食べます。"), Vocab("果物","くだもの","buah-buahan","果物が好きです。"),
        Vocab("切手","きって","perangko","切手を三枚ください。"), Vocab("地図","ちず","peta","地図を見ます。"),
        Vocab("交差点","こうさてん","persimpangan","交差点を右に曲がります。"), Vocab("信号","しんごう","lampu lalu lintas","信号が赤です。"),
        Vocab("財布","さいふ","dompet","財布を忘れました。"), Vocab("眼鏡","めがね","kacamata","眼鏡をかけます。"),
        Vocab("洗濯","せんたく","mencuci pakaian","日曜日に洗濯します。"), Vocab("掃除","そうじ","bersih-bersih","部屋を掃除します。"),
        Vocab("起きる","おきる","bangun","六時に起きます。"), Vocab("浴びる","あびる","mandi (menyiram tubuh)","朝シャワーを浴びます。"),
        Vocab("急ぐ","いそぐ","bergegas","駅まで急ぎます。"), Vocab("忘れる","わすれる","lupa","名前を忘れました。")
    ),
    "N4" to listOf(
        Vocab("故障","こしょう","kerusakan/bermasalah","機械が故障しました。"), Vocab("修理","しゅうり","perbaikan","自転車を修理します。"),
        Vocab("工場","こうじょう","pabrik","工場で働いています。"), Vocab("作業","さぎょう","pekerjaan/proses kerja","作業を始めます。"),
        Vocab("道具","どうぐ","alat/perkakas","道具を使います。"), Vocab("部品","ぶひん","komponen","部品を確認してください。"),
        Vocab("製品","せいひん","produk","製品を検査します。"), Vocab("検査","けんさ","pemeriksaan/inspeksi","出荷前に検査します。"),
        Vocab("残業","ざんぎょう","lembur","今日は二時間残業します。"), Vocab("休憩","きゅうけい","istirahat","十二時に休憩します。"),
        Vocab("給料","きゅうりょう","gaji","給料を確認します。"), Vocab("交通費","こうつうひ","biaya transportasi","交通費が支給されます。"),
        Vocab("申請","しんせい","pengajuan/permohonan","休暇を申請します。"), Vocab("書類","しょるい","dokumen","書類を提出します。"),
        Vocab("提出","ていしゅつ","penyerahan/pengumpulan","明日までに提出してください。"), Vocab("面接","めんせつ","wawancara","来週、面接があります。"),
        Vocab("採用","さいよう","penerimaan kerja","会社に採用されました。"), Vocab("応募","おうぼ","melamar","仕事に応募します。"),
        Vocab("遅刻","ちこく","terlambat","遅刻しないでください。"), Vocab("欠勤","けっきん","tidak masuk kerja","病気で欠勤しました。")
    ),
    "N3" to listOf(
        Vocab("生産","せいさん","produksi","工場の生産が増えました。"), Vocab("品質","ひんしつ","kualitas","品質を守ります。"),
        Vocab("効率的","こうりつてき","efisien","効率的な方法を探します。"), Vocab("手順","てじゅん","urutan/prosedur","手順を確認してください。"),
        Vocab("在庫","ざいこ","stok/persediaan","在庫を調べます。"), Vocab("納期","のうき","tenggat pengiriman","納期を守る必要があります。"),
        Vocab("出荷","しゅっか","pengiriman barang","製品を出荷します。"), Vocab("輸送","ゆそう","transportasi/pengangkutan","商品を輸送します。"),
        Vocab("管理","かんり","pengelolaan/manajemen","在庫を管理します。"), Vocab("記録","きろく","catatan/rekaman","作業内容を記録します。"),
        Vocab("報告","ほうこく","laporan/melaporkan","問題を上司に報告します。"), Vocab("指示","しじ","instruksi","指示に従ってください。"),
        Vocab("防止","ぼうし","pencegahan","事故を防止します。"), Vocab("事故","じこ","kecelakaan","事故の原因を調べます。"),
        Vocab("再確認","さいかくにん","memeriksa kembali","数字を再確認します。"), Vocab("不足","ふそく","kekurangan","人手が不足しています。"),
        Vocab("余裕","よゆう","kelonggaran/waktu luang","時間に余裕があります。"), Vocab("負担","ふたん","beban/tanggungan","負担を減らします。"),
        Vocab("担当","たんとう","penanggung jawab","この仕事を担当します。"), Vocab("改善案","かいぜんあん","usulan perbaikan","改善案を出しました。")
    ),
    "N2" to listOf(
        Vocab("生産性","せいさんせい","produktivitas","生産性を高めます。"), Vocab("稼働","かどう","operasi/berjalannya mesin","設備が正常に稼働しています。"),
        Vocab("稼働率","かどうりつ","tingkat operasional","稼働率を分析します。"), Vocab("納品","のうひん","penyerahan barang","商品を期限までに納品します。"),
        Vocab("調達","ちょうたつ","pengadaan","必要な部品を調達します。"), Vocab("供給","きょうきゅう","pasokan","部品の供給が止まりました。"),
        Vocab("需要","じゅよう","permintaan","需要が増えています。"), Vocab("在庫管理","ざいこかんり","manajemen persediaan","在庫管理を担当しています。"),
        Vocab("不具合","ふぐあい","cacat/gangguan","製品に不具合が見つかりました。"), Vocab("再発","さいはつ","terulang kembali","同じ問題の再発を防ぎます。"),
        Vocab("是正","ぜせい","koreksi/perbaikan","原因を調べて是正します。"), Vocab("基準","きじゅん","standar","品質基準を守ります。"),
        Vocab("遵守","じゅんしゅ","kepatuhan","安全規則の遵守が必要です。"), Vocab("徹底","てってい","pelaksanaan menyeluruh","安全確認を徹底します。"),
        Vocab("把握","はあく","memahami/menguasai situasi","現状を把握します。"), Vocab("見直し","みなおし","peninjauan ulang","作業方法を見直します。"),
        Vocab("負荷","ふか","beban kerja/beban sistem","作業負荷を調整します。"), Vocab("稼ぐ","かせぐ","menghasilkan uang","生活費を稼ぎます。"),
        Vocab("割り当て","わりあて","pembagian/alokasi","作業を割り当てます。"), Vocab("見積もり","みつもり","perkiraan/estimasi","費用を見積もります。")
    ),
    "N1" to listOf(
        Vocab("抜本的","ばっぽんてき","mendasar/menyeluruh","抜本的な改革が必要です。"), Vocab("円滑","えんかつ","lancar","作業を円滑に進めます。"),
        Vocab("精密","せいみつ","presisi/teliti","精密な検査を行います。"), Vocab("著しく","いちじるしく","secara signifikan","生産量が著しく増えました。"),
        Vocab("遂行","すいこう","pelaksanaan/menuntaskan","任務を遂行します。"), Vocab("滞る","とどこおる","terhambat","作業が滞っています。"),
        Vocab("見落とす","みおとす","melewatkan/tidak menyadari","小さな欠陥を見落としました。"), Vocab("講じる","こうじる","mengambil langkah","必要な対策を講じます。"),
        Vocab("整合性","せいごうせい","konsistensi/kesesuaian","データの整合性を確認します。"), Vocab("妨げる","さまたげる","menghambat","騒音が作業を妨げます。"),
        Vocab("円満","えんまん","harmonis","円満な関係を保ちます。"), Vocab("顧みる","かえりみる","meninjau/merenungkan","過去の失敗を顧みます。"),
        Vocab("踏襲","とうしゅう","mengikuti/meneruskan cara lama","従来の手順を踏襲します。"), Vocab("是非","ぜひ","baik buruk/kelayakan","計画の是非を検討します。"),
        Vocab("懸案","けんあん","masalah yang belum terselesaikan","長年の懸案を解決します。"), Vocab("一律","いちりつ","seragam/tanpa perbedaan","一律に判断するべきではありません。"),
        Vocab("臨機応変","りんきおうへん","menyesuaikan keadaan","臨機応変に対応します。"), Vocab("余儀なく","よぎなく","terpaksa","計画変更を余儀なくされました。"),
        Vocab("著す","あらわす","menulis/mengungkapkan","研究成果を著しました。"), Vocab("遂げる","とげる","mencapai/menuntaskan","大きな進歩を遂げました。")
    )
)

private val v8Kanji: Map<String, List<Vocab>> = mapOf(
    "N5" to listOf(
        Vocab("春","はる・しゅん","musim semi","春休み（はるやすみ）"), Vocab("夏","なつ・か","musim panas","夏休み（なつやすみ）"),
        Vocab("秋","あき・しゅう","musim gugur","秋（あき）です。"), Vocab("冬","ふゆ・とう","musim dingin","冬は寒いです。"),
        Vocab("魚","さかな・ぎょ","ikan","魚を食べます。"), Vocab("肉","にく","daging","肉を買います。"),
        Vocab("鳥","とり・ちょう","burung","鳥が飛んでいます。"), Vocab("毎","まい","setiap","毎日（まいにち）"),
        Vocab("週","しゅう","minggu","今週（こんしゅう）"), Vocab("駅","えき","stasiun","駅前（えきまえ）")
    ),
    "N4" to listOf(
        Vocab("業","ぎょう","pekerjaan/industri","工業（こうぎょう）"), Vocab("員","いん","anggota/staf","会社員（かいしゃいん）"),
        Vocab("工","こう・く","kerajinan/teknik","工場（こうじょう）"), Vocab("場","ば・じょう","tempat","工場（こうじょう）"),
        Vocab("仕","し","melayani/pekerjaan","仕事（しごと）"), Vocab("事","こと・じ","hal/urusan","大事（だいじ）"),
        Vocab("度","ど・たび","kali/derajat","一度（いちど）"), Vocab("発","はつ","berangkat/memulai","出発（しゅっぱつ）"),
        Vocab("注","ちゅう","memusatkan perhatian","注意（ちゅうい）"), Vocab("意","い","niat/perhatian","意味（いみ）")
    ),
    "N3" to listOf(
        Vocab("産","さん","produksi/kelahiran","生産（せいさん）"), Vocab("質","しつ","kualitas/sifat","品質（ひんしつ）"),
        Vocab("管","かん","pipa/mengelola","管理（かんり）"), Vocab("理","り","logika/alasan","理由（りゆう）"),
        Vocab("記","き","mencatat","記録（きろく）"), Vocab("録","ろく","rekaman/catatan","記録（きろく）"),
        Vocab("報","ほう","laporan","報告（ほうこく）"), Vocab("告","こく","memberitahu","報告（ほうこく）"),
        Vocab("防","ぼう","mencegah","防止（ぼうし）"), Vocab("険","けん","bahaya/curam","危険（きけん）")
    ),
    "N2" to listOf(
        Vocab("率","りつ","rasio/tingkat","効率（こうりつ）"), Vocab("稼","かせぐ","menghasilkan uang","稼働（かどう）"),
        Vocab("需","じゅ","permintaan","需要（じゅよう）"), Vocab("給","きゅう","memberi/pasokan","供給（きょうきゅう）"),
        Vocab("基","き","dasar","基準（きじゅん）"), Vocab("準","じゅん","standar","基準（きじゅん）"),
        Vocab("遵","じゅん","mematuhi","遵守（じゅんしゅ）"), Vocab("守","まもる・しゅ","menjaga/mematuhi","守る（まもる）"),
        Vocab("負","まける・ふ","kalah/menanggung","負担（ふたん）"), Vocab("荷","に・か","muatan","荷物（にもつ）")
    ),
    "N1" to listOf(
        Vocab("抜","ぬく・ばつ","mencabut/mengeluarkan","抜本的（ばっぽんてき）"), Vocab("円","えん","bulat/lancar dalam kata tertentu","円滑（えんかつ）"),
        Vocab("滑","すべる・かつ","licin/lancar","円滑（えんかつ）"), Vocab("遂","とげる・すい","menuntaskan","遂行（すいこう）"),
        Vocab("滞","とどこおる・たい","terhambat","滞る（とどこおる）"), Vocab("妨","さまたげる・ぼう","menghalangi","妨害（ぼうがい）"),
        Vocab("整","ととのえる・せい","menata","整合性（せいごうせい）"), Vocab("合","あう・ごう","cocok/gabung","整合（せいごう）"),
        Vocab("臨","のぞむ・りん","menghadapi","臨機応変（りんきおうへん）"), Vocab("機","き","mesin/kesempatan","機会（きかい）")
    )
)

private val v8Grammar: Map<String, List<Grammar>> = mapOf(
    "N5" to listOf(
        Grammar("N が好きです","menyukai sesuatu","日本語が好きです。","Saya suka bahasa Jepang."),
        Grammar("N が上手です／下手です","mahir/tidak mahir","彼は料理が上手です。","Dia pandai memasak."),
        Grammar("Vてください","meminta seseorang melakukan sesuatu","ゆっくり話してください。","Tolong bicara pelan-pelan."),
        Grammar("Vています (kegiatan sedang berlangsung)","sedang melakukan","今、ご飯を食べています。","Sekarang sedang makan."),
        Grammar("N はどこですか","menanyakan lokasi","駅はどこですか。","Stasiun ada di mana?")
    ),
    "N4" to listOf(
        Grammar("Vることができます","bisa/mampu melakukan","漢字を読むことができます。","Saya bisa membaca kanji."),
        Grammar("Vてみます","mencoba melakukan","この料理を食べてみます。","Saya akan mencoba makan masakan ini."),
        Grammar("Vておきます","melakukan sebagai persiapan","明日の準備をしておきます。","Saya akan menyiapkan keperluan besok terlebih dahulu."),
        Grammar("Vそうです (kelihatannya)","tampaknya/kelihatannya","この荷物は重そうです。","Barang bawaan ini kelihatannya berat."),
        Grammar("Vるようにしてください","usahakan supaya","時間を守るようにしてください。","Tolong usahakan untuk tepat waktu.")
    ),
    "N3" to listOf(
        Grammar("～ことになっている","sudah menjadi aturan/ketentuan","ここでは帽子をかぶることになっています。","Di sini sudah menjadi aturan untuk memakai topi."),
        Grammar("～わけではない","bukan berarti","日本語が嫌いなわけではありません。","Bukan berarti saya tidak suka bahasa Jepang."),
        Grammar("～おかげで","berkat","先生のおかげで合格しました。","Berkat guru, saya lulus."),
        Grammar("～せいで","gara-gara (hasil buruk)","雨のせいで遅れました。","Saya terlambat gara-gara hujan."),
        Grammar("～に対して","terhadap/berhadapan dengan","お客様に対して丁寧に話します。","Berbicara dengan sopan kepada pelanggan.")
    ),
    "N2" to listOf(
        Grammar("～に基づいて","berdasarkan","データに基づいて判断します。","Menilai berdasarkan data."),
        Grammar("～を問わず","tanpa memandang","経験を問わず応募できます。","Bisa melamar tanpa memandang pengalaman."),
        Grammar("～に限らず","tidak terbatas pada","若者に限らず人気があります。","Populer bukan hanya di kalangan anak muda."),
        Grammar("～に伴い","seiring dengan","生産量の増加に伴い、人員を増やします。","Seiring peningkatan produksi, jumlah staf ditambah."),
        Grammar("～かねない","berisiko/mungkin berakibat buruk","確認不足は事故につながりかねません。","Kurangnya pemeriksaan bisa berujung pada kecelakaan.")
    ),
    "N1" to listOf(
        Grammar("～を禁じ得ない","tidak dapat menahan (perasaan)","その知らせに驚きを禁じ得ません。","Saya tidak dapat menahan rasa terkejut atas kabar itu."),
        Grammar("～にたえない","sangat… / tidak tertahankan (formal)","感謝にたえません。","Saya sangat berterima kasih."),
        Grammar("～をおいてほかにない","tidak ada selain","この仕事は彼をおいてほかにいません。","Tidak ada orang selain dia yang cocok untuk pekerjaan ini."),
        Grammar("～と相まって","ditambah/dipadukan dengan","努力と経験が相まって成果が出ました。","Usaha yang dipadukan dengan pengalaman menghasilkan capaian."),
        Grammar("～極まる／極まりない","sangat/amat","失礼極まりない発言です。","Pernyataan yang sangat tidak sopan.")
    )
)


// Paket v0.9: perluasan materi lintas semua level (entri tambahan, bukan daftar resmi lengkap).
private val v9Vocab: Map<String, List<Vocab>> = mapOf(
    "N5" to listOf(
        Vocab("朝ご飯","あさごはん","sarapan","毎朝、朝ご飯を食べます。"), Vocab("昼ご飯","ひるごはん","makan siang","十二時に昼ご飯を食べます。"),
        Vocab("晩ご飯","ばんごはん","makan malam","家族と晩ご飯を食べます。"), Vocab("牛乳","ぎゅうにゅう","susu","毎朝、牛乳を飲みます。"),
        Vocab("野菜","やさい","sayuran","野菜をたくさん食べます。"), Vocab("果物","くだもの","buah-buahan","果物が好きです。"),
        Vocab("切手","きって","perangko","切手を三枚買いました。"), Vocab("住所","じゅうしょ","alamat","住所を書いてください。"),
        Vocab("誕生日","たんじょうび","ulang tahun","今日は母の誕生日です。"), Vocab("毎朝","まいあさ","setiap pagi","毎朝六時に起きます。"),
        Vocab("毎晩","まいばん","setiap malam","毎晩、日本語を勉強します。"), Vocab("去年","きょねん","tahun lalu","去年、日本語を始めました。"),
        Vocab("今年","ことし","tahun ini","今年、日本へ行きたいです。"), Vocab("来年","らいねん","tahun depan","来年、試験を受けます。"),
        Vocab("丈夫","じょうぶ","kuat/tahan lama","このかばんは丈夫です。"), Vocab("便利","べんり","praktis","この駅は便利です。"),
        Vocab("不便","ふべん","tidak praktis","ここは少し不便です。"), Vocab("静か","しずか","tenang/sepi","この町は静かです。"),
        Vocab("有名","ゆうめい","terkenal","この店は有名です。"), Vocab("親切","しんせつ","baik hati","あの人は親切です。")
    ),
    "N4" to listOf(
        Vocab("届け出","とどけで","laporan resmi/pemberitahuan","住所の変更を届け出ます。"), Vocab("申し訳ない","もうしわけない","mohon maaf (ungkapan formal)","遅れて申し訳ありません。"),
        Vocab("確かめる","たしかめる","memastikan/memeriksa","名前を確かめてください。"), Vocab("見つかる","みつかる","ditemukan","鍵が見つかりました。"),
        Vocab("見つける","みつける","menemukan","駅でいい店を見つけました。"), Vocab("乗り換える","のりかえる","berganti kendaraan","新宿で電車を乗り換えます。"),
        Vocab("取り替える","とりかえる","mengganti","電池を取り替えました。"), Vocab("間違える","まちがえる","melakukan kesalahan","電話番号を間違えました。"),
        Vocab("思い出す","おもいだす","teringat","子どものころを思い出します。"), Vocab("申し込む","もうしこむ","mendaftar","オンラインで申し込みました。"),
        Vocab("片道","かたみち","sekali jalan","片道の切符を買います。"), Vocab("往復","おうふく","pulang-pergi","往復切符はいくらですか。"),
        Vocab("受付","うけつけ","resepsionis/pendaftaran","受付で名前を書きます。"), Vocab("締め切り","しめきり","batas waktu","締め切りは金曜日です。"),
        Vocab("遅刻","ちこく","terlambat","仕事に遅刻しないでください。"), Vocab("早退","そうたい","pulang lebih awal","体調が悪くて早退しました。"),
        Vocab("欠席","けっせき","tidak hadir","病気で授業を欠席しました。"), Vocab("出席","しゅっせき","hadir","会議に出席します。"),
        Vocab("間に合わせる","まにあわせる","membuat agar tepat waktu","締め切りに間に合わせます。"), Vocab("片付く","かたづく","menjadi rapi/selesai dibereskan","部屋が片付きました。")
    ),
    "N3" to listOf(
        Vocab("傾向","けいこう","kecenderungan","最近、利用者が増える傾向があります。"), Vocab("方針","ほうしん","kebijakan/arah","会社の方針を確認します。"),
        Vocab("実施","じっし","pelaksanaan","来月、訓練を実施します。"), Vocab("達成","たっせい","pencapaian","目標を達成しました。"),
        Vocab("維持","いじ","mempertahankan","品質を維持します。"), Vocab("防ぐ","ふせぐ","mencegah","事故を防ぐことが大切です。"),
        Vocab("避ける","さける","menghindari","危険な場所を避けます。"), Vocab("認める","みとめる","mengakui/mengizinkan","努力が認められました。"),
        Vocab("求める","もとめる","meminta/menuntut/mencari","会社は経験者を求めています。"), Vocab("支える","ささえる","menopang/mendukung","家族が私を支えてくれます。"),
        Vocab("備える","そなえる","mempersiapkan","災害に備えます。"), Vocab("取り組む","とりくむ","menangani dengan sungguh-sungguh","問題に真剣に取り組みます。"),
        Vocab("引き続き","ひきつづき","selanjutnya/terus-menerus","引き続きよろしくお願いします。"), Vocab("改めて","あらためて","sekali lagi/nanti secara resmi","改めて連絡します。"),
        Vocab("あらかじめ","あらかじめ","sebelumnya/terlebih dahulu","あらかじめ予約してください。"), Vocab("少なくとも","すくなくとも","setidaknya","少なくとも三日かかります。"),
        Vocab("必ずしも","かならずしも","tidak selalu","高い物が必ずしもいいとは限りません。"), Vocab("いわゆる","いわゆる","yang disebut","これはいわゆる専門用語です。"),
        Vocab("具体的","ぐたいてき","konkret/spesifik","具体的な例を挙げてください。"), Vocab("全体","ぜんたい","keseluruhan","全体の流れを説明します。")
    ),
    "N2" to listOf(
        Vocab("円滑","えんかつ","lancar","作業を円滑に進めます。"), Vocab("妥協","だきょう","kompromi","双方が妥協しました。"),
        Vocab("把握","はあく","memahami/menguasai","現状を正確に把握します。"), Vocab("促進","そくしん","mendorong/mempercepat","交流を促進する活動です。"),
        Vocab("抑制","よくせい","pengendalian/penekanan","費用を抑制します。"), Vocab("確保","かくほ","memastikan ketersediaan","安全な作業場所を確保します。"),
        Vocab("遂行","すいこう","pelaksanaan/penyelesaian tugas","責任を持って任務を遂行します。"), Vocab("懸念","けねん","kekhawatiran","事故の可能性が懸念されています。"),
        Vocab("見解","けんかい","pandangan/pendapat","専門家の見解を聞きます。"), Vocab("根拠","こんきょ","dasar/bukti","判断の根拠を示してください。"),
        Vocab("相当","そうとう","cukup/sesuai/setara","修理には相当な時間がかかります。"), Vocab("著しい","いちじるしい","mencolok/signifikan","品質に著しい差があります。"),
        Vocab("一層","いっそう","lebih jauh/semakin","一層努力する必要があります。"), Vocab("一時的","いちじてき","sementara","これは一時的な問題です。"),
        Vocab("長期的","ちょうきてき","jangka panjang","長期的な計画を立てます。"), Vocab("柔軟","じゅうなん","fleksibel","柔軟に対応してください。"),
        Vocab("慎重","しんちょう","hati-hati/cermat","慎重に判断します。"), Vocab("明確","めいかく","jelas","目的を明確にします。"),
        Vocab("従来","じゅうらい","selama ini/tradisional","従来の方法を見直します。"), Vocab("著者","ちょしゃ","penulis","著者の意見をまとめます。")
    ),
    "N1" to listOf(
        Vocab("踏襲","とうしゅう","meneruskan/mengikuti cara sebelumnya","従来の方針を踏襲します。"), Vocab("顕在化","けんざいか","menjadi nyata/terlihat","問題が顕在化しました。"),
        Vocab("潜在的","せんざいてき","potensial/tersembunyi","潜在的な危険を調べます。"), Vocab("抜本的","ばっぽんてき","mendasar dan menyeluruh","抜本的な改革が必要です。"),
        Vocab("緩和","かんわ","pelonggaran/peringanan","規制を緩和します。"), Vocab("是正","ぜせい","koreksi/perbaikan","不公平を是正します。"),
        Vocab("促す","うながす","mendorong","早めの対応を促します。"), Vocab("阻む","はばむ","menghalangi","成長を阻む原因を探します。"),
        Vocab("損なう","そこなう","merusak/mengurangi","信頼を損なう行為です。"), Vocab("余儀なくする","よぎなくする","memaksa (sesuatu) terjadi","悪天候が計画変更を余儀なくしました。"),
        Vocab("一貫","いっかん","konsisten","一貫した説明が必要です。"), Vocab("整合性","せいごうせい","konsistensi/kesesuaian","資料の整合性を確認します。"),
        Vocab("懸案","けんあん","persoalan yang belum selesai","懸案事項を話し合います。"), Vocab("遂げる","とげる","mencapai/menuntaskan","大きな発展を遂げました。"),
        Vocab("鑑みる","かんがみる","mempertimbangkan berdasarkan","過去の事例に鑑みて判断します。"), Vocab("顧みる","かえりみる","meninjau kembali","自分の行動を顧みます。"),
        Vocab("おおむね","おおむね","secara umum","計画はおおむね順調です。"), Vocab("かろうじて","かろうじて","nyaris/hampir tidak","かろうじて間に合いました。"),
        Vocab("ことごとく","ことごとく","semuanya tanpa terkecuali","予想はことごとく外れました。"), Vocab("もっぱら","もっぱら","terutama/semata-mata","休日はもっぱら読書をしています。")
    )
)

private val v9Kanji: Map<String, List<Vocab>> = mapOf(
    "N5" to listOf(
        Vocab("父","ちち・ふ","ayah","父は会社員です。"), Vocab("母","はは・ぼ","ibu","母に電話します。"), Vocab("兄","あに・きょう","kakak laki-laki","兄は大学生です。"),
        Vocab("姉","あね・し","kakak perempuan","姉は東京に住んでいます。"), Vocab("弟","おとうと・てい","adik laki-laki","弟は十歳です。"), Vocab("妹","いもうと・まい","adik perempuan","妹と買い物に行きます。"),
        Vocab("春","はる・しゅん","musim semi","春に花が咲きます。"), Vocab("夏","なつ・か","musim panas","夏は暑いです。"), Vocab("秋","あき・しゅう","musim gugur","秋は涼しいです。"), Vocab("冬","ふゆ・とう","musim dingin","冬は寒いです。")
    ),
    "N4" to listOf(
        Vocab("由","ゆう・よし","alasan/asal","理由（りゆう）"), Vocab("旅","たび・りょ","perjalanan","旅行（りょこう）"), Vocab("館","かん","gedung/fasilitas","図書館（としょかん）"), Vocab("昔","むかし","dahulu","昔話（むかしばなし）"),
        Vocab("寒","さむ・かん","dingin","寒い（さむい）"), Vocab("暑","あつ・しょ","panas","暑い（あつい）"), Vocab("薬","くすり・やく","obat","薬局（やっきょく）"), Vocab("病","びょう","sakit/penyakit","病院（びょういん）"),
        Vocab("院","いん","institusi","病院（びょういん）"), Vocab("堂","どう","aula/gedung","食堂（しょくどう）")
    ),
    "N3" to listOf(
        Vocab("際","さい","kesempatan/saat","実際（じっさい）"), Vocab("況","きょう","keadaan","状況（じょうきょう）"), Vocab("況","きょう","situasi (bagian kata),","状況（じょうきょう）"), Vocab("率","りつ","tingkat/rasio","確率（かくりつ）"),
        Vocab("因","いん","penyebab","原因（げんいん）"), Vocab("果","か・はたす","hasil/buah","結果（けっか）"), Vocab("比","ひ・くらべる","membandingkan","比較（ひかく）"), Vocab("較","こう","membandingkan","比較（ひかく）"),
        Vocab("提","てい","mengajukan","提案（ていあん）"), Vocab("案","あん","rencana/usulan","提案（ていあん）")
    ),
    "N2" to listOf(
        Vocab("抑","よく・おさえる","menekan/mengendalikan","抑制（よくせい）"), Vocab("制","せい","mengatur/mengendalikan","規制（きせい）"), Vocab("確","かく・たしか","pasti/memastikan","確保（かくほ）"), Vocab("保","ほ・たもつ","menjaga","確保（かくほ）"),
        Vocab("柔","じゅう・やわらか","lembut/fleksibel","柔軟（じゅうなん）"), Vocab("軟","なん・やわらか","lunak","柔軟（じゅうなん）"), Vocab("慎","しん・つつしむ","berhati-hati","慎重（しんちょう）"), Vocab("重","じゅう・おもい","berat/penting","慎重（しんちょう）"),
        Vocab("明","めい・あかるい","terang/jelas","明確（めいかく）"), Vocab("確","かく","pasti","明確（めいかく）")
    ),
    "N1" to listOf(
        Vocab("顕","けん","tampak/nyata","顕在化（けんざいか）"), Vocab("在","ざい・ある","ada","顕在（けんざい）"), Vocab("潜","せん・ひそむ","tersembunyi","潜在（せんざい）"), Vocab("緩","かん・ゆるい","longgar/melonggarkan","緩和（かんわ）"),
        Vocab("和","わ・やわらぐ","harmoni/meredakan","緩和（かんわ）"), Vocab("阻","そ・はばむ","menghalangi","阻止（そし）"), Vocab("鑑","かん","cermin/menimbang","鑑みる（かんがみる）"), Vocab("貫","かん・つらぬく","menembus/konsisten","一貫（いっかん）"),
        Vocab("整","せい・ととのえる","menata","整合性（せいごうせい）"), Vocab("合","ごう・あう","cocok/gabung","整合（せいごう）")
    )
)

private val v9Grammar: Map<String, List<Grammar>> = mapOf(
    "N5" to listOf(
        Grammar("N がほしいです","ingin memiliki sesuatu","新しい辞書がほしいです。","Saya ingin kamus baru."),
        Grammar("Vます形＋たいです","ingin melakukan","日本へ行きたいです。","Saya ingin pergi ke Jepang."),
        Grammar("N と N","dan (menghubungkan kata benda)","友達と先生が来ます。","Teman dan guru datang."),
        Grammar("N から N まで","dari ... sampai ...","九時から五時まで働きます。","Saya bekerja dari jam sembilan sampai lima."),
        Grammar("Vて、Vて","menghubungkan urutan kegiatan","朝起きて、ご飯を食べます。","Pagi bangun lalu makan."),
        Grammar("N があります／います","ada (benda/makhluk hidup)","部屋に机があります。","Ada meja di kamar.")
    ),
    "N4" to listOf(
        Grammar("Vたことがあります","pernah melakukan","日本料理を作ったことがあります。","Saya pernah memasak masakan Jepang."),
        Grammar("Vたり、Vたりします","melakukan hal seperti ... dan ...","休みの日は本を読んだり、音楽を聞いたりします。","Saat libur saya membaca buku, mendengarkan musik, dan sebagainya."),
        Grammar("Vる前に","sebelum melakukan","寝る前に歯を磨きます。","Saya menyikat gigi sebelum tidur."),
        Grammar("Vた後で","setelah melakukan","仕事が終わった後で買い物します。","Setelah kerja selesai, saya berbelanja."),
        Grammar("～ので","karena (alasan lebih lembut)","熱があるので、休みます。","Karena demam, saya istirahat."),
        Grammar("～のに","padahal/meskipun","勉強したのに、忘れました。","Padahal sudah belajar, saya lupa.")
    ),
    "N3" to listOf(
        Grammar("～ようにする","berusaha membiasakan","毎日漢字を復習するようにしています。","Saya berusaha membiasakan mengulang kanji setiap hari."),
        Grammar("～ことにする","memutuskan sendiri","毎朝早く起きることにしました。","Saya memutuskan bangun pagi setiap hari."),
        Grammar("～ことになる","diputuskan/menjadi ketentuan","来月転勤することになりました。","Diputuskan bahwa saya pindah tugas bulan depan."),
        Grammar("～ばかり","baru saja","今、帰ってきたばかりです。","Saya baru saja pulang."),
        Grammar("～最中に","tepat saat sedang","食事の最中に電話が鳴りました。","Telepon berbunyi saat sedang makan."),
        Grammar("～たびに","setiap kali","この写真を見るたびに思い出します。","Setiap melihat foto ini, saya teringat.")
    ),
    "N2" to listOf(
        Grammar("～に違いない","pasti (kesimpulan kuat)","電気がついているので、誰かいるに違いありません。","Lampunya menyala, jadi pasti ada seseorang."),
        Grammar("～わけにはいかない","tidak bisa begitu saja (karena kewajiban)","明日は試験なので、休むわけにはいきません。","Besok ujian, jadi saya tidak bisa libur begitu saja."),
        Grammar("～に応じて","sesuai dengan","経験に応じて仕事を任せます。","Pekerjaan diberikan sesuai pengalaman."),
        Grammar("～一方で","di sisi lain","便利な一方で、費用もかかります。","Di satu sisi praktis, tetapi juga memerlukan biaya."),
        Grammar("～にすぎない","tidak lebih dari","これは一つの例にすぎません。","Ini tidak lebih dari satu contoh."),
        Grammar("～ものの","meskipun","説明を読んだものの、理解できませんでした。","Meski membaca penjelasan, saya tidak memahaminya.")
    ),
    "N1" to listOf(
        Grammar("～を余儀なくされる","terpaksa harus","大雨で計画の変更を余儀なくされました。","Hujan deras membuat kami terpaksa mengubah rencana."),
        Grammar("～に即して","sesuai dengan kondisi/kenyataan","現状に即して判断します。","Kami menilai sesuai keadaan saat ini."),
        Grammar("～を踏まえて","dengan mempertimbangkan","調査結果を踏まえて対策を決めます。","Menentukan langkah dengan mempertimbangkan hasil penyelidikan."),
        Grammar("～とはいえ","meskipun demikian","春とはいえ、まだ寒いです。","Meski sudah musim semi, masih dingin."),
        Grammar("～に越したことはない","tidak ada yang lebih baik daripada","早く準備するに越したことはありません。","Tidak ada yang lebih baik daripada bersiap lebih awal."),
        Grammar("～を皮切りに","dimulai dari","大阪を皮切りに全国で開催されます。","Dimulai dari Osaka, acara diselenggarakan di seluruh negeri.")
    )
)

private fun vocabForLevel(level: String): List<Vocab> = (levelVocab[level] ?: vocab) + extraLevelVocab[level].orEmpty() + foundationVocab[level].orEmpty() + v8Vocab[level].orEmpty() + v9Vocab[level].orEmpty()
private fun kanjiForLevel(level: String): List<Vocab> = (levelKanji[level] ?: kanji) + extraLevelKanji[level].orEmpty() + foundationKanji[level].orEmpty() + v8Kanji[level].orEmpty() + v9Kanji[level].orEmpty()
private fun grammarForLevel(level: String): List<Grammar> = (levelGrammar[level] ?: grammar) + extraLevelGrammar[level].orEmpty() + foundationGrammar[level].orEmpty() + v8Grammar[level].orEmpty() + v9Grammar[level].orEmpty()



class MainActivity : ComponentActivity() {
    private var tts: TextToSpeech? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this) { status -> if (status == TextToSpeech.SUCCESS) tts?.language = Locale.JAPANESE }
        setContent { NihongoMateApp(onSpeak = { text -> tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "nihongo") }) }
    }
    override fun onDestroy() {
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun NihongoMateApp(onSpeak: (String) -> Unit) {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("nihongo_mate", 0) }
    var dark by remember { mutableStateOf(prefs.getBoolean("dark", true)) }
    var page by remember { mutableStateOf("Beranda") }
    var completed by remember { mutableIntStateOf(prefs.getInt("completed", 0)) }
    var selectedLevel by remember { mutableStateOf("N5") }
    val colors = if (dark) darkColorScheme(primary = androidx.compose.ui.graphics.Color(0xFF75A7FF), secondary = androidx.compose.ui.graphics.Color(0xFF8DD8FF)) else lightColorScheme(primary = androidx.compose.ui.graphics.Color(0xFF245FC7))
    MaterialTheme(colorScheme = colors) {
        Scaffold(
            topBar = {
                CenterAlignedTopAppBar(
                    title = { Text("NihongoMate", fontWeight = FontWeight.Bold) },
                    actions = { TextButton(onClick = { dark = !dark; prefs.edit().putBoolean("dark", dark).apply() }) { Text(if (dark) "☀" else "☾") } }
                )
            },
            bottomBar = {
                NavigationBar {
                    listOf("Beranda", "Kana", "Kosakata", "Kanji", "Kaiwa", "JFT").forEach { item ->
                        NavigationBarItem(selected = page == item, onClick = { page = item },
                            icon = { Text(when(item) { "Beranda" -> "⌂"; "Kana" -> "あ"; "Kosakata" -> "語"; "Kanji" -> "漢"; "Kaiwa" -> "会"; else -> "✓" }) },
                            label = { Text(item) }, alwaysShowLabel = true)
                    }
                }
            }
        ) { padding ->
            Box(Modifier.fillMaxSize().padding(padding)) {
                when (page) {
                    "Beranda" -> HomeScreen(completed = completed, onOpen = { page = it })
                    "Kana" -> KanaScreen(onSpeak)
                    "Kosakata" -> StudyListScreen("Kosakata $selectedLevel", "${vocabForLevel(selectedLevel).size} entri level $selectedLevel • tekan kartu untuk detail", vocabForLevel(selectedLevel), onSpeak)
                    "Kanji" -> StudyListScreen("Kanji $selectedLevel", "${kanjiForLevel(selectedLevel).size} entri pengantar level $selectedLevel", kanjiForLevel(selectedLevel), onSpeak)
                    "Kaiwa" -> KaiwaScreen(onSpeak)
                    "Tata Bahasa" -> GrammarScreen(selectedLevel)
                    "Listening" -> ListeningScreen(onSpeak)
                    "JFT" -> JftScreen(onComplete = { completed += 1; prefs.edit().putInt("completed", completed).apply() })
                    "JLPT" -> JlptScreen(onOpenLevel = { selectedLevel = it; page = "Level" })
                    "Level" -> LevelScreen(level = selectedLevel, onBack = { page = "JLPT" }, onOpen = { page = it })
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun HomeScreen(completed: Int, onOpen: (String) -> Unit) {
    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Card(shape = RoundedCornerShape(24.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Belajar Jepang, selangkah demi selangkah.", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                    Text("Fondasi → JLPT N5 → N4 → N3 → N2 → N1", style = MaterialTheme.typography.bodyMedium)
                    LinearProgressIndicator(progress = { (completed.coerceAtMost(15) / 15f) }, modifier = Modifier.fillMaxWidth())
                    Text("Latihan JFT selesai: $completed")
                }
            }
        }
        item { Text("Mulai belajar", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold) }
        item { HomeTile("あ  ア", "Hiragana & Katakana", "46 hiragana + 46 katakana dasar, belajar dan kuis", "Kana", onOpen) }
        item { HomeTile("N5 → N1", "Jalur JLPT", "Buka level N5, N4, N3, N2, dan N1", "JLPT", onOpen) }
        item { HomeTile("語", "Kosakata", "Kosakata yang dikelompokkan menurut level belajar", "Kosakata", onOpen) }
        item { HomeTile("漢", "Kanji dasar", "Kanji dan contoh kata sesuai level", "Kanji", onOpen) }
        item { HomeTile("文", "Tata bahasa", "Pola tata bahasa terpisah untuk setiap level", "Tata Bahasa", onOpen) }
        item { HomeTile("会", "Kaiwa sehari-hari", "Salam, perkenalan, toko, dan tempat kerja", "Kaiwa", onOpen) }
        item { HomeTile("耳", "Listening berbasis TTS", "Dengarkan kalimat Jepang lalu cek arti", "Listening", onOpen) }
        item { HomeTile("✓", "Simulasi latihan JFT", "15 soal orisinal dengan pembahasan", "JFT", onOpen) }
        item {
            Text("Catatan: materi ini adalah paket belajar awal buatan sendiri, bukan seluruh silabus JLPT/JFT dan bukan soal resmi. Konten bisa ditambah bertahap.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun HomeTile(icon: String, title: String, desc: String, target: String, onOpen: (String) -> Unit) {
    Card(modifier = Modifier.fillMaxWidth().clickable { onOpen(target) }, shape = RoundedCornerShape(18.dp)) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            Text(icon, style = MaterialTheme.typography.headlineMedium, color = MaterialTheme.colorScheme.primary)
            Column(Modifier.weight(1f)) {
                Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Text(desc, style = MaterialTheme.typography.bodySmall)
            }
            Text("›", style = MaterialTheme.typography.headlineMedium)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun KanaScreen(onSpeak: (String) -> Unit) {
    var group by remember { mutableStateOf("Hiragana") }
    var mode by remember { mutableStateOf("Belajar") }
    var index by remember { mutableIntStateOf(0) }
    var reveal by remember { mutableStateOf(false) }
    var selected by remember { mutableIntStateOf(-1) }
    var checked by remember { mutableStateOf(false) }
    var score by remember { mutableIntStateOf(0) }
    var asked by remember { mutableIntStateOf(0) }
    var quizFinished by remember { mutableStateOf(false) }
    val quizLength = 10
    val set = kana.filter { it.group == group }
    val current = set[index % set.size]
    val options = remember(group, index, mode) {
        val pool = set.filter { it.char != current.char }.shuffled().take(3) + current
        pool.shuffled()
    }
    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Fondasi • Kana", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        SingleChoiceSegmentedButtonRow(modifier = Modifier.fillMaxWidth()) {
            listOf("Hiragana", "Katakana").forEachIndexed { i, label ->
                SegmentedButton(selected = group == label, onClick = { group = label; index = 0; reveal = false; selected = -1; checked = false; score = 0; asked = 0; quizFinished = false }, shape = SegmentedButtonDefaults.itemShape(i, 2)) { Text(label) }
            }
        }
        SingleChoiceSegmentedButtonRow(modifier = Modifier.fillMaxWidth()) {
            listOf("Belajar", "Latihan").forEachIndexed { i, label ->
                SegmentedButton(selected = mode == label, onClick = { mode = label; index = 0; reveal = false; selected = -1; checked = false; score = 0; asked = 0; quizFinished = false }, shape = SegmentedButtonDefaults.itemShape(i, 2)) { Text(label) }
            }
        }
        if (mode == "Belajar") {
            Text("Kartu ${index + 1} dari ${set.size} karakter")
            LinearProgressIndicator(progress = { (index + 1).toFloat() / set.size }, modifier = Modifier.fillMaxWidth())
            Card(Modifier.fillMaxWidth().weight(1f), shape = RoundedCornerShape(24.dp)) {
                Column(Modifier.fillMaxSize().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                    Text(current.char, style = MaterialTheme.typography.displayLarge, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                    if (reveal) Text(current.romaji, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold) else Text("Sebutkan bunyinya sebelum membuka jawaban.")
                    Spacer(Modifier.height(12.dp))
                    Button(onClick = { onSpeak(current.char) }) { Text("🔊 Dengarkan") }
                    OutlinedButton(onClick = { reveal = !reveal }) { Text(if (reveal) "Sembunyikan" else "Lihat romaji") }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = { index = (index - 1 + set.size) % set.size; reveal = false }) { Text("Sebelumnya") }
                        Button(onClick = { index = (index + 1) % set.size; reveal = false }) { Text("Berikutnya") }
                    }
                }
            }
        } else if (quizFinished) {
            Card(Modifier.fillMaxWidth().weight(1f), shape = RoundedCornerShape(24.dp)) {
                Column(Modifier.fillMaxSize().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                    Text("Latihan selesai!", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                    Text("$group", style = MaterialTheme.typography.titleLarge)
                    Text("Benar: $score dari $quizLength", style = MaterialTheme.typography.titleLarge)
                    Text("Salah: ${quizLength - score}")
                    Text("Nilai: ${score * 100 / quizLength}/100", style = MaterialTheme.typography.headlineSmall, color = MaterialTheme.colorScheme.primary)
                    Text(if (score * 100 / quizLength >= 80) "Bagus! Pertahankan dan lanjutkan." else "Ulangi latihan untuk memperkuat ingatan.")
                    Spacer(Modifier.height(12.dp))
                    Button(onClick = { index = 0; selected = -1; checked = false; score = 0; asked = 0; quizFinished = false }) { Text("Ulangi latihan") }
                }
            }
        } else {
            Text("Soal ${asked + 1} dari $quizLength • Benar: $score • Salah: ${asked - score}")
            LinearProgressIndicator(progress = { asked.toFloat() / quizLength }, modifier = Modifier.fillMaxWidth())
            Card(Modifier.fillMaxWidth().weight(1f), shape = RoundedCornerShape(24.dp)) {
                Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("Huruf apa ini?", style = MaterialTheme.typography.titleMedium)
                    Text(current.char, style = MaterialTheme.typography.displayLarge, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                    Button(onClick = { onSpeak(current.char) }) { Text("🔊 Dengarkan") }
                    options.forEach { option ->
                        OutlinedButton(onClick = { if (!checked) selected = options.indexOf(option) }, modifier = Modifier.fillMaxWidth(), enabled = !checked) {
                            Text(if (selected == options.indexOf(option)) "●  ${option.romaji}" else option.romaji)
                        }
                    }
                    if (checked) Text(if (options[selected].char == current.char) "Benar! ${current.char} = ${current.romaji}" else "Jawaban: ${current.char} = ${current.romaji}", color = if (options[selected].char == current.char) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error)
                    Button(onClick = {
                        if (!checked && selected >= 0) { checked = true; asked += 1; if (options[selected].char == current.char) score += 1 }
                        else if (checked) {
                            if (asked >= quizLength) quizFinished = true
                            else { index = (index + 1) % set.size; selected = -1; checked = false }
                        }
                    }, enabled = if (checked) true else selected >= 0) { Text(if (checked && asked >= quizLength) "Lihat hasil akhir" else if (checked) "Soal berikutnya" else "Periksa jawaban") }
                    TextButton(onClick = { score = 0; asked = 0; index = 0; selected = -1; checked = false; quizFinished = false }) { Text("Mulai ulang kuis") }
                }
            }
        }
    }
}


@Composable
private fun JlptScreen(onOpenLevel: (String) -> Unit) {
    val levels = listOf(
        Triple("N5", "Pemula", "Kana, kosakata sehari-hari, pola kalimat dasar"),
        Triple("N4", "Dasar lanjutan", "Percakapan rutin, bentuk lampau, bentuk て dan ない"),
        Triple("N3", "Menengah", "Teks praktis, penghubung kalimat, ungkapan umum"),
        Triple("N2", "Menengah atas", "Teks lebih kompleks, opini, konteks kerja"),
        Triple("N1", "Mahir", "Teks abstrak, nuansa makna, bahasa formal"))
    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { Text("Jalur JLPT", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold) }
        item { Text("Semua level bisa dibuka. Materi di aplikasi ini adalah paket belajar awal yang akan dikembangkan bertahap, bukan silabus lengkap atau soal resmi JLPT.", style = MaterialTheme.typography.bodyMedium) }
        items(levels) { level ->
            Card(Modifier.fillMaxWidth().clickable { onOpenLevel(level.first) }, shape = RoundedCornerShape(18.dp)) {
                Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                    Text(level.first, style = MaterialTheme.typography.headlineMedium, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                    Column(Modifier.weight(1f)) { Text(level.second, fontWeight = FontWeight.Bold); Text(level.third, style = MaterialTheme.typography.bodySmall) }
                    Text("Buka ›")
                }
            }
        }
    }
}

@Composable
private fun LevelScreen(level: String, onBack: () -> Unit, onOpen: (String) -> Unit) {
    val details = when (level) {
        "N5" -> listOf("Fokus: perkenalan, angka, waktu, tempat, aktivitas harian", "Contoh pola: N は N です", "Contoh pola: tempat へ 行きます", "Target belajar: pahami kalimat pendek dan ungkapan umum")
        "N4" -> listOf("Fokus: kegiatan sehari-hari dan pengalaman", "Contoh pola: ～てください", "Contoh pola: ～たことがあります", "Target belajar: memahami percakapan sehari-hari sederhana")
        "N3" -> listOf("Fokus: membaca teks praktis dan percakapan lebih panjang", "Contoh pola: ～と思います", "Contoh pola: ～ようになります", "Target belajar: menangkap gagasan utama dari teks dan percakapan")
        "N2" -> listOf("Fokus: teks dan situasi kerja yang lebih kompleks", "Contoh pola: ～わけではありません", "Contoh pola: ～に違いありません", "Target belajar: memahami argumen dan informasi terperinci")
        else -> listOf("Fokus: teks abstrak dan nuansa bahasa", "Contoh pola: ～を余儀なくされる", "Contoh pola: ～に即して", "Target belajar: memahami tulisan dan tuturan tingkat lanjut")
    }
    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { TextButton(onClick = onBack) { Text("‹ Kembali ke semua level") } }
        item { Text("JLPT $level", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold) }
        item { Text("Peta belajar dan latihan pengantar", style = MaterialTheme.typography.bodyMedium) }
        items(details) { detail -> Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) { Text(detail, Modifier.padding(16.dp)) } }
        item { Text("Mulai latihan", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold) }
        item { HomeTile("語", "Kosakata", "Buka kartu kosakata dan contoh kalimat", "Kosakata", onOpen) }
        item { HomeTile("漢", "Kanji", "Buka kartu kanji dasar", "Kanji", onOpen) }
        item { HomeTile("文", "Tata bahasa", "Pelajari pola dan contoh", "Tata Bahasa", onOpen) }
        item { HomeTile("✓", "Latihan JFT-Basic", "Latihan orisinal sebagai latihan tambahan", "JFT", onOpen) }
        item { Text("Catatan: daftar di atas adalah peta pengantar, bukan klaim bahwa seluruh kosakata/kanji/grammar level $level sudah tersedia.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun StudyListScreen(title: String, subtitle: String, cards: List<Vocab>, onSpeak: (String) -> Unit) {
    var search by remember { mutableStateOf("") }
    var selected by remember { mutableIntStateOf(-1) }
    var mode by remember(title) { mutableStateOf("Materi") }
    var round by remember { mutableIntStateOf(0) }
    var quizIndex by remember { mutableIntStateOf(0) }
    var answerIndex by remember { mutableIntStateOf(-1) }
    var checked by remember { mutableStateOf(false) }
    var correct by remember { mutableIntStateOf(0) }
    var finished by remember { mutableStateOf(false) }
    val quizCards = remember(cards, round) { cards.shuffled().take(minOf(10, cards.size)) }
    val current = quizCards.getOrNull(quizIndex)
    val options = remember(cards, round, quizIndex) {
        val right = quizCards.getOrNull(quizIndex)
        if (right == null) emptyList() else (cards.filter { it.jp != right.jp && it.meaning != right.meaning }.shuffled().take(3) + right).shuffled()
    }
    val filtered = cards.filter { it.jp.contains(search, true) || it.reading.contains(search, true) || it.meaning.contains(search, true) }
    fun resetQuiz() { round++; quizIndex = 0; answerIndex = -1; checked = false; correct = 0; finished = false }

    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(title, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 12.dp))
        Text("${cards.size} entri • $subtitle", style = MaterialTheme.typography.bodySmall)
        SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth()) {
            listOf("Materi", "Latihan kuis").forEachIndexed { i, label ->
                SegmentedButton(selected = mode == label, onClick = { mode = label; if (label == "Latihan kuis") resetQuiz() }, shape = SegmentedButtonDefaults.itemShape(i, 2)) { Text(label) }
            }
        }
        if (mode == "Materi") {
            OutlinedTextField(value = search, onValueChange = { search = it }, label = { Text("Cari kanji/kata/arti") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
            LazyColumn(contentPadding = PaddingValues(vertical = 6.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(filtered) { card ->
                    val expanded = selected == cards.indexOf(card)
                    Card(modifier = Modifier.fillMaxWidth().clickable { selected = if (expanded) -1 else cards.indexOf(card) }, shape = RoundedCornerShape(16.dp)) {
                        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(card.jp, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                                Spacer(Modifier.width(12.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(card.reading, fontWeight = FontWeight.SemiBold)
                                    Text(card.meaning, style = MaterialTheme.typography.bodyMedium)
                                }
                                Text(if (expanded) "−" else "+")
                            }
                            if (expanded) {
                                Divider()
                                Text("Contoh: ${card.example}")
                                TextButton(onClick = { onSpeak(card.jp) }) { Text("🔊 Dengarkan kata") }
                            }
                        }
                    }
                }
                if (filtered.isEmpty()) item { Text("Tidak ada hasil. Coba kata lain.") }
            }
        } else if (finished) {
            Card(Modifier.fillMaxWidth().weight(1f), shape = RoundedCornerShape(22.dp)) {
                Column(Modifier.fillMaxSize().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Kuis selesai!", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                    Text("$title", style = MaterialTheme.typography.titleLarge)
                    Text("Benar: $correct / ${quizCards.size}", style = MaterialTheme.typography.titleLarge)
                    Text("Salah: ${quizCards.size - correct}")
                    Text("Nilai: ${correct * 100 / quizCards.size}/100", style = MaterialTheme.typography.headlineSmall, color = MaterialTheme.colorScheme.primary)
                    Text(if (correct * 100 / quizCards.size >= 80) "Bagus! Kamu bisa lanjut atau ulang untuk pemantapan." else "Ulangi kuis agar kosakata/kanji lebih melekat.")
                    Button(onClick = { resetQuiz() }) { Text("Ulangi dengan soal acak") }
                    OutlinedButton(onClick = { mode = "Materi" }) { Text("Kembali ke materi") }
                }
            }
        } else if (current != null) {
            Text("Soal ${quizIndex + 1} dari ${quizCards.size} • Benar: $correct • Salah: ${quizIndex - correct}")
            LinearProgressIndicator(progress = { (quizIndex + if (checked) 1 else 0).toFloat() / quizCards.size }, modifier = Modifier.fillMaxWidth())
            Card(Modifier.fillMaxWidth().weight(1f), shape = RoundedCornerShape(22.dp)) {
                Column(Modifier.fillMaxSize().padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(if (title.startsWith("Kanji")) "Pilih arti kanji ini" else "Pilih arti kosakata ini", style = MaterialTheme.typography.titleMedium)
                    Text(current.jp, style = MaterialTheme.typography.displayMedium, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                    Text(current.reading, style = MaterialTheme.typography.titleMedium)
                    options.forEachIndexed { i, option ->
                        OutlinedButton(onClick = { if (!checked) answerIndex = i }, enabled = !checked, modifier = Modifier.fillMaxWidth()) {
                            Text(if (answerIndex == i) "●  ${option.meaning}" else option.meaning)
                        }
                    }
                    if (checked) {
                        val right = options.getOrNull(answerIndex)?.jp == current.jp
                        Text(if (right) "Benar! ${current.jp} = ${current.meaning}" else "Jawaban benar: ${current.meaning} (${current.reading})", color = if (right) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error, fontWeight = FontWeight.SemiBold)
                        Text("Contoh: ${current.example}")
                    }
                    Button(onClick = {
                        if (!checked && answerIndex >= 0) {
                            checked = true
                            if (options.getOrNull(answerIndex)?.jp == current.jp) correct++
                        } else if (checked) {
                            if (quizIndex == quizCards.lastIndex) finished = true
                            else { quizIndex++; answerIndex = -1; checked = false }
                        }
                    }, enabled = if (checked) true else answerIndex >= 0) {
                        Text(if (!checked) "Periksa jawaban" else if (quizIndex == quizCards.lastIndex) "Lihat hasil akhir" else "Soal berikutnya")
                    }
                    TextButton(onClick = { resetQuiz() }) { Text("Mulai ulang kuis") }
                }
            }
        }
    }
}

@Composable
private fun GrammarScreen(level: String) {
    val levelPatterns = grammarForLevel(level)
    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { Text("Tata bahasa $level", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold) }
        item { Text("${levelPatterns.size} pola pengantar level $level • contoh dan terjemahan", style = MaterialTheme.typography.bodySmall) }
        items(levelPatterns) { g ->
            Card(shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                    Text(g.pattern, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                    Text(g.meaning)
                    Text(g.example, style = MaterialTheme.typography.titleMedium)
                    Text(g.translation, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
    }
}

@Composable
private fun KaiwaScreen(onSpeak: (String) -> Unit) {
    val dialogs = listOf(
        Triple("Perkenalan", "A: はじめまして。アリです。\\nB: はじめまして。よろしくお願いします。", "A: Salam kenal, saya Ali.\\nB: Salam kenal. Senang berkenalan dengan Anda."),
        Triple("Di toko", "A: これはいくらですか。\\nB: 千円です。\\nA: じゃ、これをください。", "A: Ini berapa harganya?\\nB: Seribu yen.\\nA: Kalau begitu, saya beli ini."),
        Triple("Di tempat kerja", "A: もう一度お願いします。\\nB: はい、わかりました。", "A: Tolong sekali lagi.\\nB: Baik, saya mengerti."),
        Triple("Menanyakan lokasi", "A: トイレはどこですか。\\nB: あそこです。", "A: Toilet di mana?\\nB: Di sana."),
        Triple("Meminta bantuan", "A: すみません、手伝ってください。\\nB: はい、いいですよ。", "A: Permisi, tolong bantu saya.\\nB: Ya, tentu."),
        Triple("Jadwal kerja", "A: 何時から働きますか。\\nB: 朝八時からです。", "A: Mulai bekerja jam berapa?\\nB: Mulai pukul delapan pagi."),
        Triple("Tidak enak badan", "A: どうしましたか。\\nB: 頭が痛いです。", "A: Ada apa?\\nB: Kepala saya sakit."),
        Triple("Di restoran", "A: おすすめは何ですか。\\nB: この魚料理です。", "A: Apa rekomendasinya?\\nB: Hidangan ikan ini."),
        Triple("Minta pengulangan", "A: すみません、もう一度言ってください。\\nB: はい、ゆっくり話します。", "A: Maaf, tolong katakan sekali lagi.\\nB: Baik, saya akan bicara pelan-pelan."),
        Triple("Naik kereta", "A: この電車は東京へ行きますか。\\nB: はい、行きます。", "A: Apakah kereta ini pergi ke Tokyo?\\nB: Ya, pergi."),
        Triple("Hari libur", "A: 休みの日に何をしますか。\\nB: 友達と買い物します。", "A: Apa yang dilakukan saat libur?\\nB: Saya berbelanja dengan teman."),
        Triple("Ucapan terima kasih", "A: 手伝ってくれてありがとうございます。\\nB: どういたしまして。", "A: Terima kasih sudah membantu.\\nB: Sama-sama.")
    )
    var idx by remember { mutableIntStateOf(0) }
    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Kaiwa sehari-hari", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Text("Situasi ${idx + 1} dari ${dialogs.size}")
        Card(Modifier.fillMaxWidth().weight(1f), shape = RoundedCornerShape(22.dp)) {
            Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                Text(dialogs[idx].first, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Text(dialogs[idx].second, style = MaterialTheme.typography.titleMedium)
                Divider()
                Text(dialogs[idx].third)
                Spacer(Modifier.height(8.dp))
                Button(onClick = { onSpeak(dialogs[idx].second.replace("\\n", "。")) }) { Text("🔊 Dengarkan dialog") }
            }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            OutlinedButton(onClick = { idx = (idx - 1 + dialogs.size) % dialogs.size }) { Text("Sebelumnya") }
            Button(onClick = { idx = (idx + 1) % dialogs.size }) { Text("Dialog berikutnya") }
        }
    }
}

@Composable
private fun ListeningScreen(onSpeak: (String) -> Unit) {
    val qs = listOf(
        Triple("毎朝、七時に起きます。", "Saya bangun pukul tujuh setiap pagi.", listOf("Saya bangun pukul tujuh setiap pagi.", "Saya tidur pukul tujuh setiap malam.", "Saya belajar setiap hari.")),
        Triple("日曜日は働きません。", "Hari Minggu saya tidak bekerja.", listOf("Hari Minggu saya bekerja.", "Hari Minggu saya tidak bekerja.", "Saya bekerja setiap hari.")),
        Triple("駅で友達に会います。", "Saya bertemu teman di stasiun.", listOf("Saya bertemu teman di stasiun.", "Saya pergi ke sekolah.", "Saya membeli tiket di toko."))
    )
    var idx by remember { mutableIntStateOf(0) }
    var selected by remember { mutableIntStateOf(-1) }
    var checked by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Listening • latihan TTS", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Text("Ini latihan mendengar dari text-to-speech, bukan rekaman ujian resmi.")
        Card(Modifier.fillMaxWidth().weight(1f)) {
            Column(Modifier.fillMaxSize().padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("Soal ${idx + 1} dari ${qs.size}")
                Button(onClick = { onSpeak(qs[idx].first) }) { Text("▶ Putar kalimat Jepang") }
                Text("Pilih arti kalimat yang didengar:")
                qs[idx].third.forEachIndexed { i, option ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        RadioButton(selected = selected == i, onClick = { selected = i; checked = false })
                        Text(option)
                    }
                }
                Button(onClick = { checked = true }, enabled = selected >= 0) { Text("Periksa") }
                if (checked) Text(if (qs[idx].third[selected] == qs[idx].second) "Benar! ${qs[idx].second}" else "Belum tepat. Jawaban: ${qs[idx].second}")
            }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            OutlinedButton(onClick = { idx = (idx - 1 + qs.size) % qs.size; selected = -1; checked = false }) { Text("Sebelumnya") }
            Button(onClick = { idx = (idx + 1) % qs.size; selected = -1; checked = false }) { Text("Berikutnya") }
        }
    }
}

@Composable
private fun JftScreen(onComplete: () -> Unit) {
    var idx by remember { mutableIntStateOf(0) }
    var selected by remember { mutableIntStateOf(-1) }
    var checked by remember { mutableStateOf(false) }
    var correct by remember { mutableIntStateOf(0) }
    var finished by remember { mutableStateOf(false) }
    val q = jftQuestions[idx]
    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Latihan JFT-Basic A2", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Text("Soal orisinal untuk latihan • ${idx + 1}/${jftQuestions.size}")
        LinearProgressIndicator(progress = { (idx + 1).toFloat() / jftQuestions.size }, modifier = Modifier.fillMaxWidth())
        if (finished) {
            Card(Modifier.fillMaxWidth().weight(1f), shape = RoundedCornerShape(22.dp)) {
                Column(Modifier.fillMaxSize().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                    Text("Latihan selesai!", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                    Text("$correct / ${jftQuestions.size} benar", style = MaterialTheme.typography.titleLarge)
                    Text("Nilai: ${correct * 100 / jftQuestions.size}/100")
                    Spacer(Modifier.height(12.dp))
                    Button(onClick = { idx = 0; selected = -1; checked = false; correct = 0; finished = false }) { Text("Ulangi latihan") }
                }
            }
        } else {
            Card(Modifier.fillMaxWidth().weight(1f), shape = RoundedCornerShape(22.dp)) {
                Column(Modifier.fillMaxSize().padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(q.prompt, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                    q.options.forEachIndexed { i, option ->
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            RadioButton(selected = selected == i, onClick = { if (!checked) selected = i })
                            Text(option)
                        }
                    }
                    Button(onClick = {
                        checked = true
                        if (selected == q.answer) correct += 1
                    }, enabled = selected >= 0 && !checked) { Text("Periksa jawaban") }
                    if (checked) {
                        Text(if (selected == q.answer) "Benar!" else "Belum tepat.", fontWeight = FontWeight.Bold, color = if (selected == q.answer) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error)
                        Text(q.explanation)
                        Button(onClick = {
                            if (idx == jftQuestions.lastIndex) { finished = true; onComplete() }
                            else { idx += 1; selected = -1; checked = false }
                        }) { Text(if (idx == jftQuestions.lastIndex) "Lihat hasil" else "Soal berikutnya") }
                    }
                }
            }
        }
    }
}
