# NihongoMate v0.9.0 — source project

Android Japanese-learning app built with Kotlin and Jetpack Compose.

## Changes in v0.9.0
- Kana quiz remains a 10-question session with answer checking, next-question flow, score, correct/incorrect totals, final result, and retry.
- Vocabulary and kanji screens now include a separate 10-question quiz mode with randomized items, answer checking, examples, final score, and retry.
- Adds additional vocabulary, kanji, and grammar entries separated by N5–N1 level.
- Expands kaiwa to 12 everyday/workplace situations.
- Expands original JFT-Basic-style practice bank to 30 questions.
- Japanese speech uses Android TextToSpeech; availability and voice quality depend on the device.

## Content note
This is an expanded starter collection, not a complete JLPT N5–N1 curriculum or official JFT-Basic question bank. Counts shown in the app reflect the content bundled in this source. Continue reviewing entries for accuracy and expanding the collection in later releases. JLPT and JFT-Basic are different tests.

## Build
Use Java 17 and Gradle. Open the `NihongoMate` folder in Android Studio or run `gradle assembleDebug` from that folder. The debug APK is generated at `app/build/outputs/apk/debug/app-debug.apk`.


## Paket fondasi v0.9.0
- Jalur N5 ditambah kosakata sehari-hari tematik dan kanji dasar dengan contoh kalimat.
- Jalur N4 ditambah kosakata kerja/kehidupan, kanji, serta pola tata bahasa inti.
- Konten merupakan bahan belajar buatan aplikasi, bukan daftar resmi lengkap JLPT. Periksa pembacaan dan konteks saat belajar.


## v0.9.0
- Menambah kosakata bertema kehidupan sehari-hari, manufaktur, prosedur kerja, dan kosakata tingkat lanjut pada N5–N1.
- Menambah kanji dan pola tata bahasa untuk masing-masing level N5–N1.
- Konten adalah materi pengantar buatan aplikasi, bukan kurikulum resmi lengkap JLPT.


Versi 0.9.0 menambahkan paket kosakata, kanji, dan tata bahasa untuk semua level N5–N1. Materi bersifat latihan tambahan dan bukan daftar resmi lengkap JLPT.
