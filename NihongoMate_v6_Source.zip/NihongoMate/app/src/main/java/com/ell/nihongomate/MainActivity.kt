package com.ell.nihongomate

import android.os.Bundle
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import java.util.Locale

private data class Vocab(val jp: String, val reading: String, val meaning: String, val example: String)
private data class Kana(val char: String, val romaji: String, val group: String)
private data class Grammar(val pattern: String, val meaning: String, val example: String, val translation: String)
private data class Question(val prompt: String, val options: List<String>, val answer: Int, val explanation: String)

private val kana = listOf(
    Kana("あ","a","Hiragana"), Kana("い","i","Hiragana"), Kana("う","u","Hiragana"), Kana("え","e","Hiragana"), Kana("お","o","Hiragana"),
    Kana("か","ka","Hiragana"), Kana("き","ki","Hiragana"), Kana("く","ku","Hiragana"), Kana("け","ke","Hiragana"), Kana("こ","ko","Hiragana"),
    Kana("さ","sa","Hiragana"), Kana("し","shi","Hiragana"), Kana("す","su","Hiragana"), Kana("せ","se","Hiragana"), Kana("そ","so","Hiragana"),
    Kana("た","ta","Hiragana"), Kana("ち","chi","Hiragana"), Kana("つ","tsu","Hiragana"), Kana("て","te","Hiragana"), Kana("と","to","Hiragana"),
    Kana("な","na","Hiragana"), Kana("に","ni","Hiragana"), Kana("ぬ","nu","Hiragana"), Kana("ね","ne","Hiragana"), Kana("の","no","Hiragana"),
    Kana("は","ha","Hiragana"), Kana("ひ","hi","Hiragana"), Kana("ふ","fu","Hiragana"), Kana("へ","he","Hiragana"), Kana("ほ","ho","Hiragana"),
    Kana("ま","ma","Hiragana"), Kana("み","mi","Hiragana"), Kana("む","mu","Hiragana"), Kana("め","me","Hiragana"), Kana("も","mo","Hiragana"),
    Kana("や","ya","Hiragana"), Kana("ゆ","yu","Hiragana"), Kana("よ","yo","Hiragana"),
    Kana("ら","ra","Hiragana"), Kana("り","ri","Hiragana"), Kana("る","ru","Hiragana"), Kana("れ","re","Hiragana"), Kana("ろ","ro","Hiragana"),
    Kana("わ","wa","Hiragana"), Kana("を","o / wo","Hiragana"), Kana("ん","n","Hiragana"),
    Kana("ア","a","Katakana"), Kana("イ","i","Katakana"), Kana("ウ","u","Katakana"), Kana("エ","e","Katakana"), Kana("オ","o","Katakana"),
    Kana("カ","ka","Katakana"), Kana("キ","ki","Katakana"), Kana("ク","ku","Katakana"), Kana("ケ","ke","Katakana"), Kana("コ","ko","Katakana"),
    Kana("サ","sa","Katakana"), Kana("シ","shi","Katakana"), Kana("ス","su","Katakana"), Kana("セ","se","Katakana"), Kana("ソ","so","Katakana"),
    Kana("タ","ta","Katakana"), Kana("チ","chi","Katakana"), Kana("ツ","tsu","Katakana"), Kana("テ","te","Katakana"), Kana("ト","to","Katakana"),
    Kana("ナ","na","Katakana"), Kana("ニ","ni","Katakana"), Kana("ヌ","nu","Katakana"), Kana("ネ","ne","Katakana"), Kana("ノ","no","Katakana"),
    Kana("ハ","ha","Katakana"), Kana("ヒ","hi","Katakana"), Kana("フ","fu","Katakana"), Kana("ヘ","he","Katakana"), Kana("ホ","ho","Katakana"),
    Kana("マ","ma","Katakana"), Kana("ミ","mi","Katakana"), Kana("ム","mu","Katakana"), Kana("メ","me","Katakana"), Kana("モ","mo","Katakana"),
    Kana("ヤ","ya","Katakana"), Kana("ユ","yu","Katakana"), Kana("ヨ","yo","Katakana"),
    Kana("ラ","ra","Katakana"), Kana("リ","ri","Katakana"), Kana("ル","ru","Katakana"), Kana("レ","re","Katakana"), Kana("ロ","ro","Katakana"),
    Kana("ワ","wa","Katakana"), Kana("ヲ","o / wo","Katakana"), Kana("ン","n","Katakana")
)

private val vocab = listOf(
    Vocab("私","わたし","saya","私はインドネシア人です。"),
    Vocab("人","ひと","orang","あの人は先生です。"),
    Vocab("学生","がくせい","pelajar/mahasiswa","私は学生です。"),
    Vocab("先生","せんせい","guru","田中先生です。"),
    Vocab("会社員","かいしゃいん","pegawai perusahaan","父は会社員です。"),
    Vocab("日本","にほん","Jepang","日本へ行きます。"),
    Vocab("国","くに","negara","お国はどちらですか。"),
    Vocab("友達","ともだち","teman","友達と話します。"),
    Vocab("家族","かぞく","keluarga","家族は四人です。"),
    Vocab("家","いえ","rumah","家に帰ります。"),
    Vocab("学校","がっこう","sekolah","学校へ行きます。"),
    Vocab("会社","かいしゃ","perusahaan/kantor","会社は九時からです。"),
    Vocab("駅","えき","stasiun","駅で会います。"),
    Vocab("店","みせ","toko","あの店は安いです。"),
    Vocab("本","ほん","buku","本を読みます。"),
    Vocab("新聞","しんぶん","koran","新聞を読みます。"),
    Vocab("水","みず","air","水をください。"),
    Vocab("お茶","おちゃ","teh","お茶を飲みます。"),
    Vocab("ご飯","ごはん","nasi/makanan","ご飯を食べます。"),
    Vocab("パン","パン","roti","パンを買います。"),
    Vocab("食べます","たべます","makan","朝ご飯を食べます。"),
    Vocab("飲みます","のみます","minum","水を飲みます。"),
    Vocab("行きます","いきます","pergi","会社へ行きます。"),
    Vocab("来ます","きます","datang","友達が来ます。"),
    Vocab("帰ります","かえります","pulang","六時に帰ります。"),
    Vocab("見ます","みます","melihat/menonton","テレビを見ます。"),
    Vocab("聞きます","ききます","mendengar/bertanya","音楽を聞きます。"),
    Vocab("読みます","よみます","membaca","本を読みます。"),
    Vocab("書きます","かきます","menulis","名前を書きます。"),
    Vocab("買います","かいます","membeli","パンを買います。"),
    Vocab("働きます","はたらきます","bekerja","工場で働きます。"),
    Vocab("休みます","やすみます","beristirahat/libur","日曜日は休みます。"),
    Vocab("勉強します","べんきょうします","belajar","日本語を勉強します。"),
    Vocab("今日","きょう","hari ini","今日は暑いです。"),
    Vocab("明日","あした","besok","明日、働きます。"),
    Vocab("昨日","きのう","kemarin","昨日、勉強しました。"),
    Vocab("毎日","まいにち","setiap hari","毎日、日本語を勉強します。"),
    Vocab("朝","あさ","pagi","朝、七時に起きます。"),
    Vocab("夜","よる","malam","夜、日本語を勉強します。"),
    Vocab("時間","じかん","waktu/jam","時間があります。"),
    Vocab("大きい","おおきい","besar","大きい家です。"),
    Vocab("小さい","ちいさい","kecil","小さい犬です。"),
    Vocab("新しい","あたらしい","baru","新しい車です。"),
    Vocab("古い","ふるい","lama/tua","古い本です。"),
    Vocab("高い","たかい","mahal/tinggi","この時計は高いです。"),
    Vocab("安い","やすい","murah","この店は安いです。"),
    Vocab("暑い","あつい","panas (cuaca)","今日は暑いです。"),
    Vocab("おいしい","おいしい","enak","この料理はおいしいです。"),
    Vocab("便利","べんり","praktis","このアプリは便利です。"),
    Vocab("大丈夫","だいじょうぶ","tidak apa-apa","大丈夫です。")
)


private val kanji = listOf(
    Vocab("日","ひ・にち","hari, matahari","日本（にほん）"),
    Vocab("月","つき・げつ","bulan","月曜日（げつようび）"),
    Vocab("火","ひ・か","api","火曜日（かようび）"),
    Vocab("水","みず・すい","air","水曜日（すいようび）"),
    Vocab("木","き・もく","pohon/kayu","木曜日（もくようび）"),
    Vocab("金","かね・きん","uang/emas","金曜日（きんようび）"),
    Vocab("土","つち・ど","tanah","土曜日（どようび）"),
    Vocab("人","ひと・じん","orang","日本人（にほんじん）"),
    Vocab("口","くち・こう","mulut","入口（いりぐち）"),
    Vocab("目","め・もく","mata","目（め）"),
    Vocab("山","やま・さん","gunung","富士山（ふじさん）"),
    Vocab("川","かわ・せん","sungai","川（かわ）"),
    Vocab("田","た・でん","sawah","田中（たなか）"),
    Vocab("日","にち・じつ","hari","日曜日（にちようび）"),
    Vocab("本","ほん","buku/asal","日本（にほん）"),
    Vocab("大","おお・だい","besar","大学（だいがく）"),
    Vocab("小","ちい・しょう","kecil","小学校（しょうがっこう）"),
    Vocab("中","なか・ちゅう","dalam/tengah","中国（ちゅうごく）"),
    Vocab("上","うえ・じょう","atas","上（うえ）"),
    Vocab("下","した・か","bawah","下（した）"),
    Vocab("左","ひだり","kiri","左（ひだり）"),
    Vocab("右","みぎ","kanan","右（みぎ）"),
    Vocab("山","やま","gunung","山へ行きます。"),
    Vocab("学","がく","belajar","学生（がくせい）"),
    Vocab("生","せい・い","hidup/lahir","先生（せんせい）"),
    Vocab("先","さき・せん","sebelumnya/di depan","先生（せんせい）"),
    Vocab("年","とし・ねん","tahun","一年（いちねん）"),
    Vocab("時","とき・じ","waktu/jam","三時（さんじ）"),
    Vocab("半","はん","setengah","三時半（さんじはん）"),
    Vocab("行","い・こう","pergi","銀行（ぎんこう）")
)

private val grammar = listOf(
    Grammar("A は B です","A adalah B","私は学生です。","Saya pelajar."),
    Grammar("A は B じゃありません","A bukan B","私は先生じゃありません。","Saya bukan guru."),
    Grammar("A は B ですか","Apakah A adalah B?","田中さんは日本人ですか。","Apakah Tanaka orang Jepang?"),
    Grammar("N も","juga","私もインドネシア人です。","Saya juga orang Indonesia."),
    Grammar("N1 の N2","kepemilikan/penjelas","これは私の本です。","Ini buku saya."),
    Grammar("これ / それ / あれ","ini / itu dekat lawan bicara / itu di sana","これは何ですか。","Ini apa?"),
    Grammar("ここ / そこ / あそこ","di sini / di situ / di sana","トイレはあそこです。","Toilet ada di sana."),
    Grammar("N を Vます","objek tindakan","水を飲みます。","Saya minum air."),
    Grammar("N へ 行きます","pergi ke arah/tempat","会社へ行きます。","Saya pergi ke kantor."),
    Grammar("Tempat で Vます","melakukan kegiatan di tempat","工場で働きます。","Saya bekerja di pabrik."),
    Grammar("Waktu に Vます","melakukan pada waktu tertentu","七時に起きます。","Saya bangun pukul tujuh."),
    Grammar("A から B まで","dari A sampai B","九時から五時まで働きます。","Saya bekerja dari jam sembilan sampai lima."),
    Grammar("～ませんか","ajakan sopan","いっしょに行きませんか。","Mau pergi bersama?"),
    Grammar("～ましょう","mari kita","始めましょう。","Mari kita mulai."),
    Grammar("い-adj です","kata sifat i","この本はおもしろいです。","Buku ini menarik."),
    Grammar("な-adj です","kata sifat na","この町は静かです。","Kota ini tenang."),
    Grammar("～が好きです","suka sesuatu","日本語が好きです。","Saya suka bahasa Jepang."),
    Grammar("～があります / います","ada benda / makhluk hidup","机の上に本があります。","Ada buku di atas meja."),
    Grammar("～てください","tolong lakukan","名前を書いてください。","Tolong tulis nama."),
    Grammar("～てもいいですか","bolehkah?","ここに座ってもいいですか。","Bolehkah saya duduk di sini?")
)

private val jftQuestions = listOf(
    Question("店員：「袋は要りますか。」 Apa maksudnya?", listOf("Apakah perlu kantong?", "Mau bayar tunai?", "Berapa jumlahnya?"), 0, "袋（ふくろ） berarti kantong; 要りますか berarti perlu?"),
    Question("「少々お待ちください。」 artinya…", listOf("Silakan masuk.", "Mohon tunggu sebentar.", "Silakan pulang."), 1, "少々お待ちください adalah ungkapan sopan untuk meminta orang menunggu."),
    Question("「もう一度お願いします。」 artinya…", listOf("Tolong sekali lagi.", "Saya tidak mau.", "Saya sudah selesai."), 0, "もう一度 = sekali lagi; お願いします = mohon/tolong."),
    Question("「トイレはどこですか。」 menanyakan…", listOf("Harga toilet", "Lokasi toilet", "Nama toilet"), 1, "どこ menanyakan lokasi: di mana."),
    Question("「今日は休みです。」 artinya…", listOf("Hari ini libur.", "Hari ini bekerja.", "Besok libur."), 0, "今日 = hari ini; 休み = libur/istirahat."),
    Question("「何時に始まりますか。」 menanyakan…", listOf("Kapan/tanggal berapa?", "Mulai pukul berapa?", "Mulai di mana?"), 1, "何時（なんじ） = pukul berapa."),
    Question("「熱があります。」 artinya…", listOf("Saya demam/panas badan.", "Saya lapar.", "Saya terlambat."), 0, "熱（ねつ）があります berarti memiliki demam/panas badan."),
    Question("「ここに名前を書いてください。」 apa yang diminta?", listOf("Tulis nama di sini.", "Baca nama ini.", "Sebutkan alamat."), 0, "ここに = di sini; 名前を書いて = tulis nama."),
    Question("「電車が遅れています。」 artinya…", listOf("Kereta datang lebih awal.", "Kereta sedang terlambat.", "Kereta sudah penuh."), 1, "遅れる berarti terlambat; 遅れています menunjukkan keadaan sedang terlambat."),
    Question("「水を一つください。」 meminta…", listOf("Satu air/minuman air.", "Satu tiket.", "Satu tas."), 0, "一つ（ひとつ） = satu buah/satu item."),
    Question("「頭が痛いです。」 keluhan apa?", listOf("Sakit kepala.", "Sakit perut.", "Sakit gigi."), 0, "頭（あたま） = kepala; 痛い = sakit."),
    Question("「右に曲がってください。」 artinya…", listOf("Tolong belok kiri.", "Tolong belok kanan.", "Tolong jalan lurus."), 1, "右（みぎ） = kanan; 曲がる = berbelok."),
    Question("「この仕事は何時までですか。」 menanyakan…", listOf("Pekerjaan apa?", "Sampai jam berapa pekerjaan ini?", "Di mana tempat kerja?"), 1, "何時まで = sampai pukul berapa."),
    Question("「使い方を教えてください。」 artinya…", listOf("Tolong ajari cara menggunakan.", "Tolong jangan gunakan.", "Saya sudah tahu caranya."), 0, "使い方（つかいかた） = cara menggunakan."),
    Question("「大丈夫ですか。」 artinya…", listOf("Apakah tidak apa-apa?", "Berapa harganya?", "Apakah ini milik Anda?"), 0, "大丈夫ですか adalah pertanyaan untuk memastikan keadaan seseorang/benda."),
    Question("「先に帰ってもいいですか。」 artinya…", listOf("Bolehkah saya pulang lebih dulu?", "Bolehkah saya datang besok?", "Saya sudah pulang."), 0, "先に = lebih dulu; 帰ってもいいですか = bolehkah pulang?"),
    Question("「ゆっくり話してください。」 artinya…", listOf("Tolong bicara pelan-pelan.", "Tolong tulis dengan cepat.", "Tolong dengarkan."), 0, "ゆっくり = perlahan; 話してください = tolong bicara."),
    Question("「この機械の使い方が分かりません。」 maksudnya…", listOf("Saya tidak mengerti cara memakai mesin ini.", "Mesin ini sudah rusak.", "Saya membuat mesin ini."), 0, "使い方 = cara menggunakan; 分かりません = tidak mengerti."),
    Question("「明日は残業があります。」 artinya…", listOf("Besok ada lembur.", "Besok libur.", "Hari ini lembur."), 0, "明日 = besok; 残業（ざんぎょう） = lembur."),
    Question("「ここで写真を撮らないでください。」 artinya…", listOf("Tolong jangan mengambil foto di sini.", "Tolong ambil foto di sini.", "Foto ini milik saya."), 0, "～ないでください = tolong jangan melakukan."),
    Question("「体の具合が悪いので、休みます。」 artinya…", listOf("Karena badan tidak enak, saya akan istirahat.", "Karena sehat, saya bekerja.", "Saya ingin libur besok."), 0, "具合が悪い = kondisi badan tidak baik; ので = karena."),
    Question("「書類を確認してから、サインしてください。」 apa urutannya?", listOf("Periksa dokumen, lalu tanda tangan.", "Tanda tangan lalu buang dokumen.", "Kirim dokumen tanpa membaca."), 0, "～てから = setelah melakukan sesuatu."),
    Question("「集合時間は八時半です。」 artinya…", listOf("Waktu berkumpul pukul 08.30.", "Waktu pulang pukul 08.00.", "Rapat berlangsung selama delapan jam."), 0, "集合時間 = waktu berkumpul; 八時半 = pukul setengah sembilan."),
    Question("「この商品は売り切れです。」 artinya…", listOf("Barang ini habis terjual.", "Barang ini gratis.", "Barang ini baru datang."), 0, "売り切れ（うりきれ） = habis terjual."),
    Question("「困ったことがあったら、相談してください。」 maksudnya…", listOf("Kalau ada masalah, silakan berkonsultasi.", "Jangan bertanya kepada siapa pun.", "Masalahnya sudah selesai."), 0, "困ったこと = hal yang menyulitkan; 相談する = berkonsultasi."),
    Question("「電車が事故で止まっています。」 artinya…", listOf("Kereta berhenti karena kecelakaan.", "Kereta tiba lebih awal.", "Kecelakaan terjadi di dalam bus."), 0, "事故 = kecelakaan; 止まっています = sedang berhenti."),
    Question("「明日までに提出してください。」 artinya…", listOf("Tolong serahkan paling lambat besok.", "Tolong serahkan bulan depan.", "Jangan serahkan dokumen."), 0, "～までに = paling lambat sebelum/sampai batas waktu."),
    Question("「忘れ物がないか確認しましょう。」 artinya…", listOf("Mari periksa apakah ada barang tertinggal.", "Mari membeli barang baru.", "Mari menunggu kereta."), 0, "忘れ物 = barang tertinggal; 確認しましょう = mari periksa."),
    Question("「説明がよく聞こえませんでした。」 artinya…", listOf("Penjelasannya tidak terdengar dengan jelas.", "Saya sudah memahami semuanya.", "Penjelasannya sangat mudah."), 0, "聞こえませんでした = tidak terdengar.")
)

// Materi tambahan dipisahkan per level agar N4-N1 tidak menampilkan daftar N5 yang sama.
private val levelVocab: Map<String, List<Vocab>> = mapOf(
    "N5" to vocab,
    "N4" to listOf(
        Vocab("経験","けいけん","pengalaman","日本で働いた経験があります。"), Vocab("必要","ひつよう","perlu/diperlukan","パスポートが必要です。"),
        Vocab("準備","じゅんび","persiapan","旅行の準備をします。"), Vocab("説明","せつめい","penjelasan","使い方を説明します。"),
        Vocab("連絡","れんらく","menghubungi/kontak","あとで連絡します。"), Vocab("予定","よてい","rencana/jadwal","明日の予定があります。"),
        Vocab("約束","やくそく","janji","友達と約束しました。"), Vocab("遅れる","おくれる","terlambat","電車に遅れました。"),
        Vocab("間に合う","まにあう","tepat waktu/keburu","仕事に間に合いました。"), Vocab("続ける","つづける","melanjutkan","日本語の勉強を続けます。"),
        Vocab("決める","きめる","memutuskan","日にちを決めます。"), Vocab("運転","うんてん","mengemudi","父は車を運転します。"),
        Vocab("安心","あんしん","lega/tenang","無事で安心しました。"), Vocab("心配","しんぱい","khawatir","家族が心配です。"),
        Vocab("故障","こしょう","kerusakan","機械が故障しました。"), Vocab("直す","なおす","memperbaiki","機械を直します。"),
        Vocab("片付ける","かたづける","merapikan","部屋を片付けます。"), Vocab("特に","とくに","terutama/khususnya","特に問題はありません。"),
        Vocab("例えば","たとえば","misalnya","例えば、これは安いです。"), Vocab("最近","さいきん","akhir-akhir ini","最近忙しいです。")
    ),
    "N3" to listOf(
        Vocab("影響","えいきょう","pengaruh","天気は仕事に影響します。"), Vocab("原因","げんいん","penyebab","事故の原因を調べます。"),
        Vocab("結果","けっか","hasil/akibat","試験の結果が出ました。"), Vocab("状況","じょうきょう","situasi/kondisi","状況を説明してください。"),
        Vocab("目的","もくてき","tujuan","日本へ行く目的は仕事です。"), Vocab("方法","ほうほう","cara/metode","別の方法を考えます。"),
        Vocab("機会","きかい","kesempatan","いい機会だと思います。"), Vocab("関係","かんけい","hubungan","仕事と関係があります。"),
        Vocab("確認","かくにん","memastikan/konfirmasi","内容を確認してください。"), Vocab("判断","はんだん","penilaian/keputusan","自分で判断します。"),
        Vocab("比べる","くらべる","membandingkan","二つの方法を比べます。"), Vocab("増える","ふえる","bertambah","外国人の数が増えています。"),
        Vocab("減る","へる","berkurang","時間が減りました。"), Vocab("伝える","つたえる","menyampaikan","結果を先生に伝えます。"),
        Vocab("受け取る","うけとる","menerima","荷物を受け取りました。"), Vocab("申し込む","もうしこむ","mendaftar","試験に申し込みます。"),
        Vocab("利用","りよう","penggunaan/memanfaatkan","このサービスを利用します。"), Vocab("参加","さんか","partisipasi","会議に参加します。"),
        Vocab("意見","いけん","pendapat","意見を聞かせてください。"), Vocab("社会","しゃかい","masyarakat","社会について考えます。")
    ),
    "N2" to listOf(
        Vocab("維持","いじ","mempertahankan","健康を維持することが大切です。"), Vocab("導入","どうにゅう","penerapan/pengenalan","新しい制度を導入します。"),
        Vocab("傾向","けいこう","kecenderungan","最近その傾向があります。"), Vocab("課題","かだい","tantangan/tugas","課題を解決する必要があります。"),
        Vocab("対策","たいさく","langkah penanganan","事故の対策を考えます。"), Vocab("状況","じょうきょう","situasi","現在の状況を把握します。"),
        Vocab("実施","じっし","pelaksanaan","来月から実施します。"), Vocab("影響力","えいきょうりょく","pengaruh/kekuatan memengaruhi","彼は大きな影響力があります。"),
        Vocab("効率","こうりつ","efisiensi","効率を上げましょう。"), Vocab("責任","せきにん","tanggung jawab","自分の責任を果たします。"),
        Vocab("評価","ひょうか","evaluasi/penilaian","結果を評価します。"), Vocab("傾向","けいこう","tren/kecenderungan","消費の傾向が変わりました。"),
        Vocab("主張","しゅちょう","klaim/pendapat kuat","自分の主張を説明します。"), Vocab("根拠","こんきょ","dasar/bukti","根拠を示してください。"),
        Vocab("把握","はあく","memahami/menguasai situasi","全体を把握します。"), Vocab("適切","てきせつ","tepat/sesuai","適切な方法を選びます。"),
        Vocab("深刻","しんこく","serius/gawat","深刻な問題です。"), Vocab("改善","かいぜん","perbaikan","作業の流れを改善します。"),
        Vocab("実際","じっさい","kenyataannya/praktik","実際に試してみます。"), Vocab("一方","いっぽう","di sisi lain","一方、費用もかかります。")
    ),
    "N1" to listOf(
        Vocab("促進","そくしん","promosi/percepatan","地域交流を促進します。"), Vocab("懸念","けねん","kekhawatiran","安全面への懸念があります。"),
        Vocab("顕著","けんちょ","menonjol/nyata","顕著な変化が見られます。"), Vocab("妥当","だとう","wajar/pantas","妥当な判断だと思います。"),
        Vocab("余地","よち","ruang/peluang","改善の余地があります。"), Vocab("趣旨","しゅし","maksud/inti","説明の趣旨を理解します。"),
        Vocab("遂げる","とげる","mencapai/menuntaskan","大きな発展を遂げました。"), Vocab("伴う","ともなう","menyertai","変化にはリスクが伴います。"),
        Vocab("促す","うながす","mendorong","注意を促します。"), Vocab("損なう","そこなう","merusak/mengurangi","信頼を損ないます。"),
        Vocab("踏まえる","ふまえる","berdasarkan/mempertimbangkan","事実を踏まえて判断します。"), Vocab("一概に","いちがいに","secara umum tanpa pengecualian","一概には言えません。"),
        Vocab("おおむね","おおむね","secara garis besar","計画はおおむね順調です。"), Vocab("著しい","いちじるしい","sangat nyata/mencolok","著しい進歩がありました。"),
        Vocab("不可欠","ふかけつ","sangat penting/tidak dapat dihilangkan","協力が不可欠です。"), Vocab("根本","こんぽん","dasar/akar","根本的な原因を探します。"),
        Vocab("見込み","みこみ","prospek/perkiraan","回復の見込みがあります。"), Vocab("余儀なくされる","よぎなくされる","terpaksa harus","計画の変更を余儀なくされました。"),
        Vocab("矛盾","むじゅん","kontradiksi","説明に矛盾があります。"), Vocab("配慮","はいりょ","pertimbangan/perhatian","相手への配慮が必要です。")
    )
)

private val levelKanji: Map<String, List<Vocab>> = mapOf(
    "N5" to kanji,
    "N4" to listOf(
        Vocab("会","かい・あう","bertemu/pertemuan","会社（かいしゃ）"), Vocab("同","どう・おなじ","sama","同じ（おなじ）"), Vocab("事","こと・じ","hal/perkara","仕事（しごと）"),
        Vocab("自","じ・みずから","diri sendiri","自分（じぶん）"), Vocab("社","しゃ","perusahaan/masyarakat","会社（かいしゃ）"), Vocab("発","はつ","berangkat/keluar","出発（しゅっぱつ）"),
        Vocab("者","しゃ・もの","orang","医者（いしゃ）"), Vocab("地","ち","tanah/tempat","地下鉄（ちかてつ）"), Vocab("業","ぎょう","pekerjaan/bisnis","授業（じゅぎょう）"),
        Vocab("方","かた・ほう","cara/orang (sopan)","読み方（よみかた）"), Vocab("新","しん・あたらしい","baru","新聞（しんぶん）"), Vocab("場","ば・じょう","tempat","場所（ばしょ）")
    ),
    "N3" to listOf(
        Vocab("政","せい","politik/pemerintahan","政治（せいじ）"), Vocab("経","けい","melewati/ekonomi","経験（けいけん）"), Vocab("済","さい","selesai/ekonomi","経済（けいざい）"),
        Vocab("法","ほう","hukum/cara","方法（ほうほう）"), Vocab("制","せい","sistem/kontrol","制度（せいど）"), Vocab("機","き","mesin/kesempatan","機会（きかい）"),
        Vocab("関","かん","hubungan","関係（かんけい）"), Vocab("係","けい・かかり","petugas/hubungan","係員（かかりいん）"), Vocab("調","ちょう・しらべる","menyelidiki","調査（ちょうさ）"),
        Vocab("査","さ","pemeriksaan","調査（ちょうさ）"), Vocab("報","ほう","laporan","情報（じょうほう）"), Vocab("情","じょう","perasaan/informasi","情報（じょうほう）")
    ),
    "N2" to listOf(
        Vocab("論","ろん","teori/argumen","議論（ぎろん）"), Vocab("証","しょう","bukti","証明（しょうめい）"), Vocab("評","ひょう","penilaian","評価（ひょうか）"),
        Vocab("価","か","nilai/harga","価値（かち）"), Vocab("提","てい","mengajukan","提案（ていあん）"), Vocab("案","あん","usulan/rencana","提案（ていあん）"),
        Vocab("構","こう","struktur","構造（こうぞう）"), Vocab("造","ぞう","membuat/struktur","製造（せいぞう）"), Vocab("際","さい","kesempatan/saat","実際（じっさい）"),
        Vocab("限","げん・かぎる","batas","制限（せいげん）"), Vocab("規","き","aturan/standar","規則（きそく）"), Vocab("則","そく","aturan","規則（きそく）")
    ),
    "N1" to listOf(
        Vocab("顧","こ","memperhatikan","顧客（こきゃく）"), Vocab("慮","りょ","mempertimbangkan","配慮（はいりょ）"), Vocab("懸","けん","menggantung/kekhawatiran","懸念（けねん）"),
        Vocab("念","ねん","pikiran/perhatian","懸念（けねん）"), Vocab("促","そく","mendorong","促進（そくしん）"), Vocab("進","しん・すすむ","maju","促進（そくしん）"),
        Vocab("著","ちょ・いちじるしい","menonjol/menulis","著しい（いちじるしい）"), Vocab("顕","けん","tampak jelas","顕著（けんちょ）"), Vocab("妥","だ","pantas","妥当（だとう）"),
        Vocab("矛","む","tombak","矛盾（むじゅん）"), Vocab("盾","じゅん","perisai","矛盾（むじゅん）"), Vocab("踏","とう・ふむ","menginjak/berdasarkan","踏まえる（ふまえる）")
    )
)

private val levelGrammar: Map<String, List<Grammar>> = mapOf(
    "N5" to grammar,
    "N4" to listOf(
        Grammar("～たことがあります","pernah melakukan","日本へ行ったことがあります。","Saya pernah pergi ke Jepang."),
        Grammar("～たり～たりします","melakukan hal seperti A dan B","日曜日は本を読んだり、映画を見たりします。","Hari Minggu saya membaca buku, menonton film, dan sebagainya."),
        Grammar("～ながら","sambil","音楽を聞きながら勉強します。","Saya belajar sambil mendengarkan musik."),
        Grammar("～てから","setelah melakukan","仕事が終わってから帰ります。","Saya pulang setelah pekerjaan selesai."),
        Grammar("～なければなりません","harus","薬を飲まなければなりません。","Saya harus minum obat."),
        Grammar("～なくてもいいです","tidak harus","明日は来なくてもいいです。","Besok tidak perlu datang."),
        Grammar("～と思います","saya pikir","明日は雨だと思います。","Saya pikir besok hujan."),
        Grammar("～ので","karena (alasan) ","熱があるので、休みます。","Karena demam, saya istirahat."),
        Grammar("～かもしれません","mungkin","午後、雨が降るかもしれません。","Mungkin hujan sore nanti."),
        Grammar("～やすい / ～にくい","mudah/sulit dilakukan","このペンは書きやすいです。","Pulpen ini mudah digunakan untuk menulis.")
    ),
    "N3" to listOf(
        Grammar("～ようにする","berusaha membiasakan","毎日漢字を読むようにしています。","Saya berusaha membaca kanji setiap hari."),
        Grammar("～ことになる","diputuskan bahwa","来月転勤することになりました。","Diputuskan saya pindah tugas bulan depan."),
        Grammar("～ばかり","baru saja","今、着いたばかりです。","Saya baru saja tiba."),
        Grammar("～おかげで","berkat","先生のおかげで合格しました。","Berkat guru, saya lulus."),
        Grammar("～せいで","gara-gara (akibat negatif)","雨のせいで試合が中止になりました。","Pertandingan dibatalkan gara-gara hujan."),
        Grammar("～に対して","terhadap","お客様に対して丁寧に話します。","Berbicara sopan kepada pelanggan."),
        Grammar("～によると","menurut sumber","天気予報によると、明日は晴れです。","Menurut ramalan cuaca, besok cerah."),
        Grammar("～たびに","setiap kali","この歌を聞くたびに故郷を思い出します。","Setiap mendengar lagu ini, saya teringat kampung halaman."),
        Grammar("～わけではない","bukan berarti","嫌いなわけではありません。","Bukan berarti saya tidak suka."),
        Grammar("～ようになる","menjadi bisa/mulai","日本語が少し話せるようになりました。","Saya jadi bisa sedikit berbicara bahasa Jepang.")
    ),
    "N2" to listOf(
        Grammar("～わけにはいかない","tidak bisa begitu saja (karena kewajiban)","明日は大事な試験なので休むわけにはいきません。","Karena besok ujian penting, saya tidak bisa absen."),
        Grammar("～に違いない","pasti","彼はもう帰ったに違いありません。","Dia pasti sudah pulang."),
        Grammar("～一方で","di sisi lain","便利な一方で、危険もあります。","Di satu sisi praktis, tetapi ada bahaya juga."),
        Grammar("～に応じて","sesuai dengan","能力に応じて仕事を任せます。","Pekerjaan diberikan sesuai kemampuan."),
        Grammar("～に関して","mengenai","契約に関して質問があります。","Saya punya pertanyaan mengenai kontrak."),
        Grammar("～をめぐって","seputar/mengenai (perdebatan)","計画をめぐって意見が分かれました。","Pendapat terbelah seputar rencana itu."),
        Grammar("～にすぎない","tidak lebih dari","これは一例にすぎません。","Ini tidak lebih dari satu contoh."),
        Grammar("～ものの","meskipun","説明を読んだものの、よく分かりません。","Meski sudah membaca penjelasan, saya belum paham."),
        Grammar("～に伴って","seiring dengan","人口の増加に伴って問題も増えました。","Seiring bertambahnya penduduk, masalah juga bertambah."),
        Grammar("～次第","segera setelah","詳細が分かり次第、連絡します。","Saya akan menghubungi segera setelah detail diketahui.")
    ),
    "N1" to listOf(
        Grammar("～を余儀なくされる","terpaksa harus","悪天候で計画の変更を余儀なくされました。","Cuaca buruk membuat kami terpaksa mengubah rencana."),
        Grammar("～に即して","sesuai/berdasarkan","現状に即して判断します。","Kami menilai berdasarkan kondisi aktual."),
        Grammar("～を踏まえて","dengan mempertimbangkan","調査結果を踏まえて方針を決めます。","Menentukan kebijakan dengan mempertimbangkan hasil survei."),
        Grammar("～にかかわらず","tanpa memandang","経験の有無にかかわらず応募できます。","Bisa melamar terlepas dari ada tidaknya pengalaman."),
        Grammar("～とはいえ","meskipun dikatakan","春とはいえ、まだ寒いです。","Meski sudah disebut musim semi, masih dingin."),
        Grammar("～に越したことはない","tidak ada yang lebih baik daripada","早めに準備するに越したことはありません。","Tidak ada yang lebih baik daripada bersiap lebih awal."),
        Grammar("～を皮切りに","dimulai dari","東京を皮切りに全国で開催されます。","Dimulai dari Tokyo, acara diadakan di seluruh negeri."),
        Grammar("～ならでは","khas/unik untuk","これは日本ならではの習慣です。","Ini kebiasaan yang khas Jepang."),
        Grammar("～をものともせず","tanpa gentar terhadap","彼は批判をものともせず挑戦しました。","Dia terus menantang tanpa gentar terhadap kritik."),
        Grammar("～極まりない","sangat/amat (formal)","失礼極まりない態度です。","Sikap yang sangat tidak sopan.")
    )
)


// Paket tambahan v0.6: data tambahan ditaruh terpisah agar tiap level tidak memakai daftar N5 yang sama.
private val extraLevelVocab: Map<String, List<Vocab>> = mapOf(
    "N5" to listOf(
        Vocab("駅員","えきいん","petugas stasiun","駅員に聞きます。"), Vocab("電車","でんしゃ","kereta listrik","電車で会社へ行きます。"),
        Vocab("会社員","かいしゃいん","pegawai perusahaan","兄は会社員です。"), Vocab("病院","びょういん","rumah sakit","病院へ行きます。"),
        Vocab("銀行","ぎんこう","bank","銀行でお金を下ろします。"), Vocab("郵便局","ゆうびんきょく","kantor pos","郵便局はどこですか。"),
        Vocab("右","みぎ","kanan","右へ曲がってください。"), Vocab("左","ひだり","kiri","左にあります。"),
        Vocab("前","まえ","depan/sebelum","駅の前で会います。"), Vocab("後ろ","うしろ","belakang","家の後ろに公園があります。"),
        Vocab("近い","ちかい","dekat","駅は近いです。"), Vocab("遠い","とおい","jauh","学校は遠いです。"),
        Vocab("忙しい","いそがしい","sibuk","今日は忙しいです。"), Vocab("楽しい","たのしい","menyenangkan","日本語の勉強は楽しいです。"),
        Vocab("難しい","むずかしい","sulit","漢字は難しいです。"), Vocab("易しい","やさしい","mudah","この問題は易しいです。"),
        Vocab("天気","てんき","cuaca","今日の天気はいいです。"), Vocab("雨","あめ","hujan","雨が降っています。"),
        Vocab("雪","ゆき","salju","雪が降りました。"), Vocab("風","かぜ","angin","風が強いです。"),
        Vocab("写真","しゃしん","foto","写真を撮ります。"), Vocab("旅行","りょこう","perjalanan/wisata","日本へ旅行したいです。"),
        Vocab("料理","りょうり","masakan/memasak","日本料理が好きです。"), Vocab("映画","えいが","film","週末に映画を見ます。"),
        Vocab("音楽","おんがく","musik","音楽を聞きます。"), Vocab("部屋","へや","kamar","部屋を掃除します。"),
        Vocab("窓","まど","jendela","窓を開けます。"), Vocab("机","つくえ","meja","机の上に本があります。"),
        Vocab("椅子","いす","kursi","椅子に座ります。"), Vocab("毎週","まいしゅう","setiap minggu","毎週日本語を勉強します。")
    ),
    "N4" to listOf(
        Vocab("経験","けいけん","pengalaman","日本で働いた経験があります。"), Vocab("準備","じゅんび","persiapan","試験の準備をします。"),
        Vocab("説明","せつめい","penjelasan","もう一度説明してください。"), Vocab("連絡","れんらく","menghubungi/kabar","あとで連絡します。"),
        Vocab("予定","よてい","rencana/jadwal","明日の予定を確認します。"), Vocab("必要","ひつよう","perlu/diperlukan","パスポートが必要です。"),
        Vocab("安全","あんぜん","aman/keselamatan","安全に気をつけてください。"), Vocab("危険","きけん","bahaya","ここは危険です。"),
        Vocab("注意","ちゅうい","perhatian/berhati-hati","足元に注意してください。"), Vocab("理由","りゆう","alasan","理由を教えてください。"),
        Vocab("途中","とちゅう","di tengah perjalanan/proses","帰る途中で買い物をしました。"), Vocab("場合","ばあい","kasus/keadaan","分からない場合は聞いてください。"),
        Vocab("間に合う","まにあう","tepat waktu","電車に間に合いました。"), Vocab("遅れる","おくれる","terlambat","バスが遅れています。"),
        Vocab("届ける","とどける","mengantarkan/menyerahkan","書類を届けます。"), Vocab("片付ける","かたづける","merapikan","部屋を片付けます。"),
        Vocab("壊れる","こわれる","rusak (intransitif)","機械が壊れました。"), Vocab("直す","なおす","memperbaiki","自転車を直します。"),
        Vocab("申し込む","もうしこむ","mendaftar/mengajukan","試験に申し込みます。"), Vocab("間違い","まちがい","kesalahan","間違いを直します。")
    ),
    "N3" to listOf(
        Vocab("影響","えいきょう","pengaruh","天気は仕事に影響します。"), Vocab("結果","けっか","hasil","試験の結果を確認します。"),
        Vocab("原因","げんいん","penyebab","事故の原因を調べます。"), Vocab("解決","かいけつ","penyelesaian","問題を解決します。"),
        Vocab("比較","ひかく","perbandingan","二つの方法を比較します。"), Vocab("判断","はんだん","penilaian/keputusan","自分で判断してください。"),
        Vocab("提案","ていあん","usulan","新しい方法を提案します。"), Vocab("参加","さんか","partisipasi","会議に参加します。"),
        Vocab("変更","へんこう","perubahan","予定を変更しました。"), Vocab("確認","かくにん","memastikan/konfirmasi","内容を確認してください。"),
        Vocab("増加","ぞうか","peningkatan","利用者が増加しています。"), Vocab("減少","げんしょう","penurunan","事故が減少しました。"),
        Vocab("対応","たいおう","penanganan/respons","問題に対応します。"), Vocab("協力","きょうりょく","kerja sama","みんなで協力します。"),
        Vocab("関係","かんけい","hubungan","仕事と関係があります。"), Vocab("調査","ちょうさ","penyelidikan/survei","原因を調査します。"),
        Vocab("情報","じょうほう","informasi","正しい情報が必要です。"), Vocab("制度","せいど","sistem","新しい制度が始まりました。"),
        Vocab("機会","きかい","kesempatan","いい機会だと思います。"), Vocab("努力","どりょく","usaha","毎日努力しています。")
    ),
    "N2" to listOf(
        Vocab("傾向","けいこう","kecenderungan","最近この傾向が強くなっています。"), Vocab("状況","じょうきょう","situasi","状況を説明してください。"),
        Vocab("課題","かだい","tantangan/tugas","課題を整理します。"), Vocab("対策","たいさく","langkah penanganan","対策を考えます。"),
        Vocab("効率","こうりつ","efisiensi","効率を上げる必要があります。"), Vocab("責任","せきにん","tanggung jawab","責任を持って仕事をします。"),
        Vocab("評価","ひょうか","evaluasi/penilaian","結果を評価します。"), Vocab("根拠","こんきょ","dasar/bukti","根拠を示してください。"),
        Vocab("適切","てきせつ","tepat/sesuai","適切な方法を選びます。"), Vocab("深刻","しんこく","serius/gawat","深刻な問題です。"),
        Vocab("改善","かいぜん","perbaikan","作業手順を改善します。"), Vocab("実際","じっさい","kenyataannya/praktik","実際に試してみます。"),
        Vocab("一方","いっぽう","di sisi lain","一方で費用もかかります。"), Vocab("維持","いじ","mempertahankan","品質を維持します。"),
        Vocab("導入","どうにゅう","penerapan/pengenalan","新しい設備を導入します。"), Vocab("削減","さくげん","pengurangan","無駄な費用を削減します。"),
        Vocab("傾向","けいこう","kecenderungan","消費の傾向が変わりました。"), Vocab("実績","じっせき","rekam hasil/prestasi","これまでの実績を説明します。"),
        Vocab("条件","じょうけん","syarat/kondisi","条件を確認してください。"), Vocab("対象","たいしょう","sasaran/objek","対象となる人に連絡します。")
    ),
    "N1" to listOf(
        Vocab("促進","そくしん","percepatan/pemajuan","地域交流を促進します。"), Vocab("懸念","けねん","kekhawatiran","安全面への懸念があります。"),
        Vocab("顕著","けんちょ","menonjol/nyata","顕著な変化が見られます。"), Vocab("妥当","だとう","wajar/pantas","妥当な判断だと思います。"),
        Vocab("余地","よち","ruang/peluang","改善の余地があります。"), Vocab("趣旨","しゅし","maksud/inti","説明の趣旨を理解します。"),
        Vocab("遂げる","とげる","mencapai/menuntaskan","大きな発展を遂げました。"), Vocab("伴う","ともなう","menyertai","変化にはリスクが伴います。"),
        Vocab("促す","うながす","mendorong","注意を促します。"), Vocab("損なう","そこなう","merusak/mengurangi","信頼を損ないます。"),
        Vocab("踏まえる","ふまえる","berdasarkan/mempertimbangkan","事実を踏まえて判断します。"), Vocab("一概に","いちがいに","secara mutlak/tanpa pengecualian","一概には言えません。"),
        Vocab("おおむね","おおむね","secara garis besar","計画はおおむね順調です。"), Vocab("著しい","いちじるしい","sangat nyata/mencolok","著しい進歩がありました。"),
        Vocab("不可欠","ふかけつ","sangat penting/mutlak diperlukan","協力が不可欠です。"), Vocab("根本","こんぽん","dasar/akar","根本的な原因を探します。"),
        Vocab("見込み","みこみ","prospek/perkiraan","回復の見込みがあります。"), Vocab("余儀なくされる","よぎなくされる","terpaksa harus","計画の変更を余儀なくされました。"),
        Vocab("矛盾","むじゅん","kontradiksi","説明に矛盾があります。"), Vocab("配慮","はいりょ","pertimbangan/perhatian","相手への配慮が必要です。")
    )
)

private val extraLevelKanji: Map<String, List<Vocab>> = mapOf(
    "N5" to listOf(
        Vocab("円","えん","yen/lingkaran","千円（せんえん）"), Vocab("万","まん","sepuluh ribu","一万円（いちまんえん）"),
        Vocab("白","しろ・はく","putih","白い（しろい）"), Vocab("黒","くろ・こく","hitam","黒い（くろい）"),
        Vocab("赤","あか・せき","merah","赤い（あかい）"), Vocab("青","あお・せい","biru","青い（あおい）"),
        Vocab("天","てん","langit","天気（てんき）"), Vocab("気","き","energi/perasaan","元気（げんき）"),
        Vocab("雨","あめ・う","hujan","雨の日（あめのひ）"), Vocab("電","でん","listrik","電車（でんしゃ）"),
        Vocab("車","くるま・しゃ","mobil/kendaraan","電車（でんしゃ）"), Vocab("語","ご","bahasa/kata","日本語（にほんご）"),
        Vocab("名","な・めい","nama","名前（なまえ）"), Vocab("午","ご","siang","午後（ごご）"),
        Vocab("今","いま・こん","sekarang","今週（こんしゅう）")
    ),
    "N4" to listOf(
        Vocab("世","せ・よ","dunia/generasi","世界（せかい）"), Vocab("界","かい","dunia/batas","世界（せかい）"),
        Vocab("品","ひん・しな","barang/kualitas","商品（しょうひん）"), Vocab("物","もの・ぶつ","benda","荷物（にもつ）"),
        Vocab("特","とく","khusus","特別（とくべつ）"), Vocab("別","べつ","berbeda/terpisah","別々（べつべつ）"),
        Vocab("使","つかう・し","menggunakan","使用（しよう）"), Vocab("送","おくる・そう","mengirim","送金（そうきん）"),
        Vocab("貸","かす・たい","meminjamkan","貸し出し（かしだし）"), Vocab("借","かりる・しゃく","meminjam","借金（しゃっきん）"),
        Vocab("着","きる・ちゃく","memakai/tiba","到着（とうちゃく）"), Vocab("乗","のる・じょう","naik kendaraan","乗車（じょうしゃ）")
    ),
    "N3" to listOf(
        Vocab("政","せい","politik/pemerintahan","政治（せいじ）"), Vocab("経","けい","melewati/ekonomi","経験（けいけん）"),
        Vocab("済","さい","selesai/ekonomi","経済（けいざい）"), Vocab("法","ほう","hukum/cara","方法（ほうほう）"),
        Vocab("制","せい","sistem/kontrol","制度（せいど）"), Vocab("機","き","mesin/kesempatan","機会（きかい）"),
        Vocab("関","かん","hubungan","関係（かんけい）"), Vocab("係","けい・かかり","petugas/hubungan","係員（かかりいん）"),
        Vocab("調","ちょう・しらべる","menyelidiki","調査（ちょうさ）"), Vocab("査","さ","pemeriksaan","調査（ちょうさ）"),
        Vocab("報","ほう","laporan","情報（じょうほう）"), Vocab("情","じょう","perasaan/informasi","情報（じょうほう）")
    ),
    "N2" to listOf(
        Vocab("論","ろん","teori/argumen","議論（ぎろん）"), Vocab("証","しょう","bukti","証明（しょうめい）"),
        Vocab("評","ひょう","penilaian","評価（ひょうか）"), Vocab("価","か","nilai/harga","価値（かち）"),
        Vocab("提","てい","mengajukan","提案（ていあん）"), Vocab("案","あん","usulan/rencana","提案（ていあん）"),
        Vocab("構","こう","struktur","構造（こうぞう）"), Vocab("造","ぞう","membuat/struktur","製造（せいぞう）"),
        Vocab("際","さい","kesempatan/saat","実際（じっさい）"), Vocab("限","げん・かぎる","batas","制限（せいげん）"),
        Vocab("規","き","aturan/standar","規則（きそく）"), Vocab("則","そく","aturan","規則（きそく）")
    ),
    "N1" to listOf(
        Vocab("顧","こ","memperhatikan","顧客（こきゃく）"), Vocab("慮","りょ","mempertimbangkan","配慮（はいりょ）"),
        Vocab("懸","けん","kekhawatiran","懸念（けねん）"), Vocab("念","ねん","pikiran/perhatian","懸念（けねん）"),
        Vocab("促","そく","mendorong","促進（そくしん）"), Vocab("進","しん・すすむ","maju","促進（そくしん）"),
        Vocab("著","ちょ・いちじるしい","menonjol/menulis","著しい（いちじるしい）"), Vocab("顕","けん","tampak jelas","顕著（けんちょ）"),
        Vocab("妥","だ","pantas","妥当（だとう）"), Vocab("矛","む","tombak","矛盾（むじゅん）"),
        Vocab("盾","じゅん","perisai","矛盾（むじゅん）"), Vocab("踏","とう・ふむ","menginjak/berdasarkan","踏まえる（ふまえる）")
    )
)

private val extraLevelGrammar: Map<String, List<Grammar>> = mapOf(
    "N5" to listOf(
        Grammar("N は N じゃありません","bukan","これは本じゃありません。","Ini bukan buku."),
        Grammar("N は どこですか","menanyakan lokasi","銀行はどこですか。","Bank ada di mana?"),
        Grammar("N は いくらですか","menanyakan harga","この本はいくらですか。","Buku ini berapa harganya?"),
        Grammar("V ませんか","ajakan sopan","いっしょに昼ご飯を食べませんか。","Mau makan siang bersama?"),
        Grammar("V ました","bentuk lampau sopan","昨日、勉強しました。","Kemarin saya belajar."),
        Grammar("V ませんでした","lampau negatif sopan","昨日、働きませんでした。","Kemarin saya tidak bekerja."),
        Grammar("N が あります","ada benda","机の上に本があります。","Ada buku di atas meja."),
        Grammar("N が います","ada makhluk hidup","部屋に猫がいます。","Ada kucing di kamar.")
    ),
    "N4" to listOf(
        Grammar("～てみます","mencoba melakukan","この料理を食べてみます。","Saya akan mencoba makan masakan ini."),
        Grammar("～ておきます","melakukan sebagai persiapan","会議の前に資料を読んでおきます。","Saya membaca materi terlebih dahulu sebelum rapat."),
        Grammar("～そうです（様態）","kelihatannya","このケーキはおいしそうです。","Kue ini kelihatannya enak."),
        Grammar("～すぎます","terlalu","食べすぎました。","Saya makan terlalu banyak."),
        Grammar("～ほうがいいです","sebaiknya","早く寝たほうがいいです。","Sebaiknya tidur lebih awal."),
        Grammar("～なくなります","menjadi tidak lagi","日本語が少し分かるようになりました。","Saya jadi sedikit mengerti bahasa Jepang."),
        Grammar("～でしょう","mungkin/dugaan","明日は晴れるでしょう。","Besok mungkin cerah."),
        Grammar("～のに","padahal/meskipun","勉強したのに、忘れました。","Padahal sudah belajar, saya lupa.")
    ),
    "N3" to listOf(
        Grammar("～ことにする","memutuskan sendiri","毎日歩くことにしました。","Saya memutuskan berjalan kaki setiap hari."),
        Grammar("～ことになっている","sudah menjadi aturan/jadwal","ここでは靴を脱ぐことになっています。","Di sini sudah menjadi aturan untuk melepas sepatu."),
        Grammar("～ようとする","berusaha/akan melakukan","出かけようとした時、電話が鳴りました。","Saat hendak pergi, telepon berbunyi."),
        Grammar("～ば～ほど","semakin… semakin…","練習すればするほど上手になります。","Semakin berlatih, semakin mahir."),
        Grammar("～最中に","di tengah-tengah","食事の最中に電話がありました。","Ada telepon di tengah makan."),
        Grammar("～に比べて","dibandingkan dengan","去年に比べて忙しいです。","Lebih sibuk dibandingkan tahun lalu."),
        Grammar("～として","sebagai","通訳として働いています。","Saya bekerja sebagai penerjemah."),
        Grammar("～わりに","meskipun/untuk ukuran","この店は安いわりにおいしいです。","Untuk ukuran toko murah, rasanya enak.")
    ),
    "N2" to listOf(
        Grammar("～に基づいて","berdasarkan","データに基づいて判断します。","Menilai berdasarkan data."),
        Grammar("～を通じて","melalui/sepanjang","研修を通じて多くを学びました。","Saya belajar banyak melalui pelatihan."),
        Grammar("～にかけては","dalam hal","彼は料理にかけては誰にも負けません。","Dalam hal memasak, dia tidak kalah dari siapa pun."),
        Grammar("～に限らず","tidak terbatas pada","若者に限らず人気があります。","Populer bukan hanya di kalangan anak muda."),
        Grammar("～を問わず","tanpa memandang","年齢を問わず参加できます。","Bisa berpartisipasi tanpa memandang usia."),
        Grammar("～に反して","bertentangan dengan","予想に反して結果はよかったです。","Bertentangan dengan perkiraan, hasilnya bagus."),
        Grammar("～に沿って","sesuai dengan/mengikuti","計画に沿って進めます。","Melanjutkan sesuai rencana."),
        Grammar("～だけあって","memang pantas karena","経験があるだけあって上手です。","Memang mahir karena berpengalaman.")
    ),
    "N1" to listOf(
        Grammar("～を禁じ得ない","tidak dapat menahan (perasaan)","その話を聞いて驚きを禁じ得ません。","Mendengar cerita itu, saya tidak dapat menahan rasa terkejut."),
        Grammar("～にたえる","layak untuk","この作品は読むにたえる内容です。","Karya ini layak dibaca."),
        Grammar("～と相まって","berpadu dengan","努力と運が相まって成功しました。","Usaha berpadu dengan keberuntungan sehingga berhasil."),
        Grammar("～をおいてほかにない","tidak ada selain","この仕事は彼をおいてほかにいません。","Tidak ada orang lain selain dia untuk pekerjaan ini."),
        Grammar("～ならまだしも","kalau … masih bisa dimaklumi","一度ならまだしも、何度も遅刻するのは困ります。","Kalau sekali masih bisa dimaklumi, tetapi terlambat berkali-kali merepotkan."),
        Grammar("～に即して","sesuai/berdasarkan","現状に即して判断します。","Menilai berdasarkan kondisi aktual."),
        Grammar("～を皮切りに","dimulai dari","東京を皮切りに全国で開催されます。","Dimulai dari Tokyo, acara diadakan di seluruh negeri."),
        Grammar("～といえども","sekalipun","専門家といえども間違うことがあります。","Sekalipun ahli, kadang bisa salah.")
    )
)

private fun vocabForLevel(level: String): List<Vocab> = (levelVocab[level] ?: vocab) + extraLevelVocab[level].orEmpty()
private fun kanjiForLevel(level: String): List<Vocab> = (levelKanji[level] ?: kanji) + extraLevelKanji[level].orEmpty()
private fun grammarForLevel(level: String): List<Grammar> = (levelGrammar[level] ?: grammar) + extraLevelGrammar[level].orEmpty()


class MainActivity : ComponentActivity() {
    private var tts: TextToSpeech? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this) { status -> if (status == TextToSpeech.SUCCESS) tts?.language = Locale.JAPANESE }
        setContent { NihongoMateApp(onSpeak = { text -> tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "nihongo") }) }
    }
    override fun onDestroy() {
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun NihongoMateApp(onSpeak: (String) -> Unit) {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("nihongo_mate", 0) }
    var dark by remember { mutableStateOf(prefs.getBoolean("dark", true)) }
    var page by remember { mutableStateOf("Beranda") }
    var completed by remember { mutableIntStateOf(prefs.getInt("completed", 0)) }
    var selectedLevel by remember { mutableStateOf("N5") }
    val colors = if (dark) darkColorScheme(primary = androidx.compose.ui.graphics.Color(0xFF75A7FF), secondary = androidx.compose.ui.graphics.Color(0xFF8DD8FF)) else lightColorScheme(primary = androidx.compose.ui.graphics.Color(0xFF245FC7))
    MaterialTheme(colorScheme = colors) {
        Scaffold(
            topBar = {
                CenterAlignedTopAppBar(
                    title = { Text("NihongoMate", fontWeight = FontWeight.Bold) },
                    actions = { TextButton(onClick = { dark = !dark; prefs.edit().putBoolean("dark", dark).apply() }) { Text(if (dark) "☀" else "☾") } }
                )
            },
            bottomBar = {
                NavigationBar {
                    listOf("Beranda", "Kana", "Kosakata", "Kanji", "Kaiwa", "JFT").forEach { item ->
                        NavigationBarItem(selected = page == item, onClick = { page = item },
                            icon = { Text(when(item) { "Beranda" -> "⌂"; "Kana" -> "あ"; "Kosakata" -> "語"; "Kanji" -> "漢"; "Kaiwa" -> "会"; else -> "✓" }) },
                            label = { Text(item) }, alwaysShowLabel = true)
                    }
                }
            }
        ) { padding ->
            Box(Modifier.fillMaxSize().padding(padding)) {
                when (page) {
                    "Beranda" -> HomeScreen(completed = completed, onOpen = { page = it })
                    "Kana" -> KanaScreen(onSpeak)
                    "Kosakata" -> StudyListScreen("Kosakata $selectedLevel", "${vocabForLevel(selectedLevel).size} entri level $selectedLevel • tekan kartu untuk detail", vocabForLevel(selectedLevel), onSpeak)
                    "Kanji" -> StudyListScreen("Kanji $selectedLevel", "${kanjiForLevel(selectedLevel).size} entri pengantar level $selectedLevel", kanjiForLevel(selectedLevel), onSpeak)
                    "Kaiwa" -> KaiwaScreen(onSpeak)
                    "Tata Bahasa" -> GrammarScreen(selectedLevel)
                    "Listening" -> ListeningScreen(onSpeak)
                    "JFT" -> JftScreen(onComplete = { completed += 1; prefs.edit().putInt("completed", completed).apply() })
                    "JLPT" -> JlptScreen(onOpenLevel = { selectedLevel = it; page = "Level" })
                    "Level" -> LevelScreen(level = selectedLevel, onBack = { page = "JLPT" }, onOpen = { page = it })
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun HomeScreen(completed: Int, onOpen: (String) -> Unit) {
    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Card(shape = RoundedCornerShape(24.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Belajar Jepang, selangkah demi selangkah.", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                    Text("Fondasi → JLPT N5 → N4 → N3 → N2 → N1", style = MaterialTheme.typography.bodyMedium)
                    LinearProgressIndicator(progress = { (completed.coerceAtMost(15) / 15f) }, modifier = Modifier.fillMaxWidth())
                    Text("Latihan JFT selesai: $completed")
                }
            }
        }
        item { Text("Mulai belajar", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold) }
        item { HomeTile("あ  ア", "Hiragana & Katakana", "46 hiragana + 46 katakana dasar, belajar dan kuis", "Kana", onOpen) }
        item { HomeTile("N5 → N1", "Jalur JLPT", "Buka level N5, N4, N3, N2, dan N1", "JLPT", onOpen) }
        item { HomeTile("語", "Kosakata", "Kosakata yang dikelompokkan menurut level belajar", "Kosakata", onOpen) }
        item { HomeTile("漢", "Kanji dasar", "Kanji dan contoh kata sesuai level", "Kanji", onOpen) }
        item { HomeTile("文", "Tata bahasa", "Pola tata bahasa terpisah untuk setiap level", "Tata Bahasa", onOpen) }
        item { HomeTile("会", "Kaiwa sehari-hari", "Salam, perkenalan, toko, dan tempat kerja", "Kaiwa", onOpen) }
        item { HomeTile("耳", "Listening berbasis TTS", "Dengarkan kalimat Jepang lalu cek arti", "Listening", onOpen) }
        item { HomeTile("✓", "Simulasi latihan JFT", "15 soal orisinal dengan pembahasan", "JFT", onOpen) }
        item {
            Text("Catatan: materi ini adalah paket belajar awal buatan sendiri, bukan seluruh silabus JLPT/JFT dan bukan soal resmi. Konten bisa ditambah bertahap.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun HomeTile(icon: String, title: String, desc: String, target: String, onOpen: (String) -> Unit) {
    Card(modifier = Modifier.fillMaxWidth().clickable { onOpen(target) }, shape = RoundedCornerShape(18.dp)) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            Text(icon, style = MaterialTheme.typography.headlineMedium, color = MaterialTheme.colorScheme.primary)
            Column(Modifier.weight(1f)) {
                Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Text(desc, style = MaterialTheme.typography.bodySmall)
            }
            Text("›", style = MaterialTheme.typography.headlineMedium)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun KanaScreen(onSpeak: (String) -> Unit) {
    var group by remember { mutableStateOf("Hiragana") }
    var mode by remember { mutableStateOf("Belajar") }
    var index by remember { mutableIntStateOf(0) }
    var reveal by remember { mutableStateOf(false) }
    var selected by remember { mutableIntStateOf(-1) }
    var checked by remember { mutableStateOf(false) }
    var score by remember { mutableIntStateOf(0) }
    var asked by remember { mutableIntStateOf(0) }
    var quizFinished by remember { mutableStateOf(false) }
    val quizLength = 10
    val set = kana.filter { it.group == group }
    val current = set[index % set.size]
    val options = remember(group, index, mode) {
        val pool = set.filter { it.char != current.char }.shuffled().take(3) + current
        pool.shuffled()
    }
    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Fondasi • Kana", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        SingleChoiceSegmentedButtonRow(modifier = Modifier.fillMaxWidth()) {
            listOf("Hiragana", "Katakana").forEachIndexed { i, label ->
                SegmentedButton(selected = group == label, onClick = { group = label; index = 0; reveal = false; selected = -1; checked = false; score = 0; asked = 0; quizFinished = false }, shape = SegmentedButtonDefaults.itemShape(i, 2)) { Text(label) }
            }
        }
        SingleChoiceSegmentedButtonRow(modifier = Modifier.fillMaxWidth()) {
            listOf("Belajar", "Latihan").forEachIndexed { i, label ->
                SegmentedButton(selected = mode == label, onClick = { mode = label; index = 0; reveal = false; selected = -1; checked = false; score = 0; asked = 0; quizFinished = false }, shape = SegmentedButtonDefaults.itemShape(i, 2)) { Text(label) }
            }
        }
        if (mode == "Belajar") {
            Text("Kartu ${index + 1} dari ${set.size} karakter")
            LinearProgressIndicator(progress = { (index + 1).toFloat() / set.size }, modifier = Modifier.fillMaxWidth())
            Card(Modifier.fillMaxWidth().weight(1f), shape = RoundedCornerShape(24.dp)) {
                Column(Modifier.fillMaxSize().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                    Text(current.char, style = MaterialTheme.typography.displayLarge, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                    if (reveal) Text(current.romaji, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold) else Text("Sebutkan bunyinya sebelum membuka jawaban.")
                    Spacer(Modifier.height(12.dp))
                    Button(onClick = { onSpeak(current.char) }) { Text("🔊 Dengarkan") }
                    OutlinedButton(onClick = { reveal = !reveal }) { Text(if (reveal) "Sembunyikan" else "Lihat romaji") }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = { index = (index - 1 + set.size) % set.size; reveal = false }) { Text("Sebelumnya") }
                        Button(onClick = { index = (index + 1) % set.size; reveal = false }) { Text("Berikutnya") }
                    }
                }
            }
        } else if (quizFinished) {
            Card(Modifier.fillMaxWidth().weight(1f), shape = RoundedCornerShape(24.dp)) {
                Column(Modifier.fillMaxSize().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                    Text("Latihan selesai!", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                    Text("$group", style = MaterialTheme.typography.titleLarge)
                    Text("Benar: $score dari $quizLength", style = MaterialTheme.typography.titleLarge)
                    Text("Salah: ${quizLength - score}")
                    Text("Nilai: ${score * 100 / quizLength}/100", style = MaterialTheme.typography.headlineSmall, color = MaterialTheme.colorScheme.primary)
                    Text(if (score * 100 / quizLength >= 80) "Bagus! Pertahankan dan lanjutkan." else "Ulangi latihan untuk memperkuat ingatan.")
                    Spacer(Modifier.height(12.dp))
                    Button(onClick = { index = 0; selected = -1; checked = false; score = 0; asked = 0; quizFinished = false }) { Text("Ulangi latihan") }
                }
            }
        } else {
            Text("Soal ${asked + 1} dari $quizLength • Benar: $score • Salah: ${asked - score}")
            LinearProgressIndicator(progress = { asked.toFloat() / quizLength }, modifier = Modifier.fillMaxWidth())
            Card(Modifier.fillMaxWidth().weight(1f), shape = RoundedCornerShape(24.dp)) {
                Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("Huruf apa ini?", style = MaterialTheme.typography.titleMedium)
                    Text(current.char, style = MaterialTheme.typography.displayLarge, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                    Button(onClick = { onSpeak(current.char) }) { Text("🔊 Dengarkan") }
                    options.forEach { option ->
                        OutlinedButton(onClick = { if (!checked) selected = options.indexOf(option) }, modifier = Modifier.fillMaxWidth(), enabled = !checked) {
                            Text(if (selected == options.indexOf(option)) "●  ${option.romaji}" else option.romaji)
                        }
                    }
                    if (checked) Text(if (options[selected].char == current.char) "Benar! ${current.char} = ${current.romaji}" else "Jawaban: ${current.char} = ${current.romaji}", color = if (options[selected].char == current.char) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error)
                    Button(onClick = {
                        if (!checked && selected >= 0) { checked = true; asked += 1; if (options[selected].char == current.char) score += 1 }
                        else if (checked) {
                            if (asked >= quizLength) quizFinished = true
                            else { index = (index + 1) % set.size; selected = -1; checked = false }
                        }
                    }, enabled = if (checked) true else selected >= 0) { Text(if (checked && asked >= quizLength) "Lihat hasil akhir" else if (checked) "Soal berikutnya" else "Periksa jawaban") }
                    TextButton(onClick = { score = 0; asked = 0; index = 0; selected = -1; checked = false; quizFinished = false }) { Text("Mulai ulang kuis") }
                }
            }
        }
    }
}


@Composable
private fun JlptScreen(onOpenLevel: (String) -> Unit) {
    val levels = listOf(
        Triple("N5", "Pemula", "Kana, kosakata sehari-hari, pola kalimat dasar"),
        Triple("N4", "Dasar lanjutan", "Percakapan rutin, bentuk lampau, bentuk て dan ない"),
        Triple("N3", "Menengah", "Teks praktis, penghubung kalimat, ungkapan umum"),
        Triple("N2", "Menengah atas", "Teks lebih kompleks, opini, konteks kerja"),
        Triple("N1", "Mahir", "Teks abstrak, nuansa makna, bahasa formal"))
    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { Text("Jalur JLPT", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold) }
        item { Text("Semua level bisa dibuka. Materi di aplikasi ini adalah paket belajar awal yang akan dikembangkan bertahap, bukan silabus lengkap atau soal resmi JLPT.", style = MaterialTheme.typography.bodyMedium) }
        items(levels) { level ->
            Card(Modifier.fillMaxWidth().clickable { onOpenLevel(level.first) }, shape = RoundedCornerShape(18.dp)) {
                Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                    Text(level.first, style = MaterialTheme.typography.headlineMedium, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                    Column(Modifier.weight(1f)) { Text(level.second, fontWeight = FontWeight.Bold); Text(level.third, style = MaterialTheme.typography.bodySmall) }
                    Text("Buka ›")
                }
            }
        }
    }
}

@Composable
private fun LevelScreen(level: String, onBack: () -> Unit, onOpen: (String) -> Unit) {
    val details = when (level) {
        "N5" -> listOf("Fokus: perkenalan, angka, waktu, tempat, aktivitas harian", "Contoh pola: N は N です", "Contoh pola: tempat へ 行きます", "Target belajar: pahami kalimat pendek dan ungkapan umum")
        "N4" -> listOf("Fokus: kegiatan sehari-hari dan pengalaman", "Contoh pola: ～てください", "Contoh pola: ～たことがあります", "Target belajar: memahami percakapan sehari-hari sederhana")
        "N3" -> listOf("Fokus: membaca teks praktis dan percakapan lebih panjang", "Contoh pola: ～と思います", "Contoh pola: ～ようになります", "Target belajar: menangkap gagasan utama dari teks dan percakapan")
        "N2" -> listOf("Fokus: teks dan situasi kerja yang lebih kompleks", "Contoh pola: ～わけではありません", "Contoh pola: ～に違いありません", "Target belajar: memahami argumen dan informasi terperinci")
        else -> listOf("Fokus: teks abstrak dan nuansa bahasa", "Contoh pola: ～を余儀なくされる", "Contoh pola: ～に即して", "Target belajar: memahami tulisan dan tuturan tingkat lanjut")
    }
    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { TextButton(onClick = onBack) { Text("‹ Kembali ke semua level") } }
        item { Text("JLPT $level", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold) }
        item { Text("Peta belajar dan latihan pengantar", style = MaterialTheme.typography.bodyMedium) }
        items(details) { detail -> Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) { Text(detail, Modifier.padding(16.dp)) } }
        item { Text("Mulai latihan", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold) }
        item { HomeTile("語", "Kosakata", "Buka kartu kosakata dan contoh kalimat", "Kosakata", onOpen) }
        item { HomeTile("漢", "Kanji", "Buka kartu kanji dasar", "Kanji", onOpen) }
        item { HomeTile("文", "Tata bahasa", "Pelajari pola dan contoh", "Tata Bahasa", onOpen) }
        item { HomeTile("✓", "Latihan JFT-Basic", "Latihan orisinal sebagai latihan tambahan", "JFT", onOpen) }
        item { Text("Catatan: daftar di atas adalah peta pengantar, bukan klaim bahwa seluruh kosakata/kanji/grammar level $level sudah tersedia.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun StudyListScreen(title: String, subtitle: String, cards: List<Vocab>, onSpeak: (String) -> Unit) {
    var search by remember { mutableStateOf("") }
    var selected by remember { mutableIntStateOf(-1) }
    var mode by remember(title) { mutableStateOf("Materi") }
    var round by remember { mutableIntStateOf(0) }
    var quizIndex by remember { mutableIntStateOf(0) }
    var answerIndex by remember { mutableIntStateOf(-1) }
    var checked by remember { mutableStateOf(false) }
    var correct by remember { mutableIntStateOf(0) }
    var finished by remember { mutableStateOf(false) }
    val quizCards = remember(cards, round) { cards.shuffled().take(minOf(10, cards.size)) }
    val current = quizCards.getOrNull(quizIndex)
    val options = remember(cards, round, quizIndex) {
        val right = quizCards.getOrNull(quizIndex)
        if (right == null) emptyList() else (cards.filter { it.jp != right.jp && it.meaning != right.meaning }.shuffled().take(3) + right).shuffled()
    }
    val filtered = cards.filter { it.jp.contains(search, true) || it.reading.contains(search, true) || it.meaning.contains(search, true) }
    fun resetQuiz() { round++; quizIndex = 0; answerIndex = -1; checked = false; correct = 0; finished = false }

    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(title, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 12.dp))
        Text("${cards.size} entri • $subtitle", style = MaterialTheme.typography.bodySmall)
        SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth()) {
            listOf("Materi", "Latihan kuis").forEachIndexed { i, label ->
                SegmentedButton(selected = mode == label, onClick = { mode = label; if (label == "Latihan kuis") resetQuiz() }, shape = SegmentedButtonDefaults.itemShape(i, 2)) { Text(label) }
            }
        }
        if (mode == "Materi") {
            OutlinedTextField(value = search, onValueChange = { search = it }, label = { Text("Cari kanji/kata/arti") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
            LazyColumn(contentPadding = PaddingValues(vertical = 6.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(filtered) { card ->
                    val expanded = selected == cards.indexOf(card)
                    Card(modifier = Modifier.fillMaxWidth().clickable { selected = if (expanded) -1 else cards.indexOf(card) }, shape = RoundedCornerShape(16.dp)) {
                        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(card.jp, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                                Spacer(Modifier.width(12.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(card.reading, fontWeight = FontWeight.SemiBold)
                                    Text(card.meaning, style = MaterialTheme.typography.bodyMedium)
                                }
                                Text(if (expanded) "−" else "+")
                            }
                            if (expanded) {
                                Divider()
                                Text("Contoh: ${card.example}")
                                TextButton(onClick = { onSpeak(card.jp) }) { Text("🔊 Dengarkan kata") }
                            }
                        }
                    }
                }
                if (filtered.isEmpty()) item { Text("Tidak ada hasil. Coba kata lain.") }
            }
        } else if (finished) {
            Card(Modifier.fillMaxWidth().weight(1f), shape = RoundedCornerShape(22.dp)) {
                Column(Modifier.fillMaxSize().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Kuis selesai!", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                    Text("$title", style = MaterialTheme.typography.titleLarge)
                    Text("Benar: $correct / ${quizCards.size}", style = MaterialTheme.typography.titleLarge)
                    Text("Salah: ${quizCards.size - correct}")
                    Text("Nilai: ${correct * 100 / quizCards.size}/100", style = MaterialTheme.typography.headlineSmall, color = MaterialTheme.colorScheme.primary)
                    Text(if (correct * 100 / quizCards.size >= 80) "Bagus! Kamu bisa lanjut atau ulang untuk pemantapan." else "Ulangi kuis agar kosakata/kanji lebih melekat.")
                    Button(onClick = { resetQuiz() }) { Text("Ulangi dengan soal acak") }
                    OutlinedButton(onClick = { mode = "Materi" }) { Text("Kembali ke materi") }
                }
            }
        } else if (current != null) {
            Text("Soal ${quizIndex + 1} dari ${quizCards.size} • Benar: $correct • Salah: ${quizIndex - correct}")
            LinearProgressIndicator(progress = { (quizIndex + if (checked) 1 else 0).toFloat() / quizCards.size }, modifier = Modifier.fillMaxWidth())
            Card(Modifier.fillMaxWidth().weight(1f), shape = RoundedCornerShape(22.dp)) {
                Column(Modifier.fillMaxSize().padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(if (title.startsWith("Kanji")) "Pilih arti kanji ini" else "Pilih arti kosakata ini", style = MaterialTheme.typography.titleMedium)
                    Text(current.jp, style = MaterialTheme.typography.displayMedium, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                    Text(current.reading, style = MaterialTheme.typography.titleMedium)
                    options.forEachIndexed { i, option ->
                        OutlinedButton(onClick = { if (!checked) answerIndex = i }, enabled = !checked, modifier = Modifier.fillMaxWidth()) {
                            Text(if (answerIndex == i) "●  ${option.meaning}" else option.meaning)
                        }
                    }
                    if (checked) {
                        val right = options.getOrNull(answerIndex)?.jp == current.jp
                        Text(if (right) "Benar! ${current.jp} = ${current.meaning}" else "Jawaban benar: ${current.meaning} (${current.reading})", color = if (right) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error, fontWeight = FontWeight.SemiBold)
                        Text("Contoh: ${current.example}")
                    }
                    Button(onClick = {
                        if (!checked && answerIndex >= 0) {
                            checked = true
                            if (options.getOrNull(answerIndex)?.jp == current.jp) correct++
                        } else if (checked) {
                            if (quizIndex == quizCards.lastIndex) finished = true
                            else { quizIndex++; answerIndex = -1; checked = false }
                        }
                    }, enabled = if (checked) true else answerIndex >= 0) {
                        Text(if (!checked) "Periksa jawaban" else if (quizIndex == quizCards.lastIndex) "Lihat hasil akhir" else "Soal berikutnya")
                    }
                    TextButton(onClick = { resetQuiz() }) { Text("Mulai ulang kuis") }
                }
            }
        }
    }
}

@Composable
private fun GrammarScreen(level: String) {
    val levelPatterns = grammarForLevel(level)
    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { Text("Tata bahasa $level", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold) }
        item { Text("${levelPatterns.size} pola pengantar level $level • contoh dan terjemahan", style = MaterialTheme.typography.bodySmall) }
        items(levelPatterns) { g ->
            Card(shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                    Text(g.pattern, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                    Text(g.meaning)
                    Text(g.example, style = MaterialTheme.typography.titleMedium)
                    Text(g.translation, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
    }
}

@Composable
private fun KaiwaScreen(onSpeak: (String) -> Unit) {
    val dialogs = listOf(
        Triple("Perkenalan", "A: はじめまして。アリです。\\nB: はじめまして。よろしくお願いします。", "A: Salam kenal, saya Ali.\\nB: Salam kenal. Senang berkenalan dengan Anda."),
        Triple("Di toko", "A: これはいくらですか。\\nB: 千円です。\\nA: じゃ、これをください。", "A: Ini berapa harganya?\\nB: Seribu yen.\\nA: Kalau begitu, saya beli ini."),
        Triple("Di tempat kerja", "A: もう一度お願いします。\\nB: はい、わかりました。", "A: Tolong sekali lagi.\\nB: Baik, saya mengerti."),
        Triple("Menanyakan lokasi", "A: トイレはどこですか。\\nB: あそこです。", "A: Toilet di mana?\\nB: Di sana."),
        Triple("Meminta bantuan", "A: すみません、手伝ってください。\\nB: はい、いいですよ。", "A: Permisi, tolong bantu saya.\\nB: Ya, tentu."),
        Triple("Jadwal kerja", "A: 何時から働きますか。\\nB: 朝八時からです。", "A: Mulai bekerja jam berapa?\\nB: Mulai pukul delapan pagi."),
        Triple("Tidak enak badan", "A: どうしましたか。\\nB: 頭が痛いです。", "A: Ada apa?\\nB: Kepala saya sakit."),
        Triple("Di restoran", "A: おすすめは何ですか。\\nB: この魚料理です。", "A: Apa rekomendasinya?\\nB: Hidangan ikan ini."),
        Triple("Minta pengulangan", "A: すみません、もう一度言ってください。\\nB: はい、ゆっくり話します。", "A: Maaf, tolong katakan sekali lagi.\\nB: Baik, saya akan bicara pelan-pelan."),
        Triple("Naik kereta", "A: この電車は東京へ行きますか。\\nB: はい、行きます。", "A: Apakah kereta ini pergi ke Tokyo?\\nB: Ya, pergi."),
        Triple("Hari libur", "A: 休みの日に何をしますか。\\nB: 友達と買い物します。", "A: Apa yang dilakukan saat libur?\\nB: Saya berbelanja dengan teman."),
        Triple("Ucapan terima kasih", "A: 手伝ってくれてありがとうございます。\\nB: どういたしまして。", "A: Terima kasih sudah membantu.\\nB: Sama-sama.")
    )
    var idx by remember { mutableIntStateOf(0) }
    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Kaiwa sehari-hari", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Text("Situasi ${idx + 1} dari ${dialogs.size}")
        Card(Modifier.fillMaxWidth().weight(1f), shape = RoundedCornerShape(22.dp)) {
            Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                Text(dialogs[idx].first, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Text(dialogs[idx].second, style = MaterialTheme.typography.titleMedium)
                Divider()
                Text(dialogs[idx].third)
                Spacer(Modifier.height(8.dp))
                Button(onClick = { onSpeak(dialogs[idx].second.replace("\\n", "。")) }) { Text("🔊 Dengarkan dialog") }
            }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            OutlinedButton(onClick = { idx = (idx - 1 + dialogs.size) % dialogs.size }) { Text("Sebelumnya") }
            Button(onClick = { idx = (idx + 1) % dialogs.size }) { Text("Dialog berikutnya") }
        }
    }
}

@Composable
private fun ListeningScreen(onSpeak: (String) -> Unit) {
    val qs = listOf(
        Triple("毎朝、七時に起きます。", "Saya bangun pukul tujuh setiap pagi.", listOf("Saya bangun pukul tujuh setiap pagi.", "Saya tidur pukul tujuh setiap malam.", "Saya belajar setiap hari.")),
        Triple("日曜日は働きません。", "Hari Minggu saya tidak bekerja.", listOf("Hari Minggu saya bekerja.", "Hari Minggu saya tidak bekerja.", "Saya bekerja setiap hari.")),
        Triple("駅で友達に会います。", "Saya bertemu teman di stasiun.", listOf("Saya bertemu teman di stasiun.", "Saya pergi ke sekolah.", "Saya membeli tiket di toko."))
    )
    var idx by remember { mutableIntStateOf(0) }
    var selected by remember { mutableIntStateOf(-1) }
    var checked by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Listening • latihan TTS", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Text("Ini latihan mendengar dari text-to-speech, bukan rekaman ujian resmi.")
        Card(Modifier.fillMaxWidth().weight(1f)) {
            Column(Modifier.fillMaxSize().padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("Soal ${idx + 1} dari ${qs.size}")
                Button(onClick = { onSpeak(qs[idx].first) }) { Text("▶ Putar kalimat Jepang") }
                Text("Pilih arti kalimat yang didengar:")
                qs[idx].third.forEachIndexed { i, option ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        RadioButton(selected = selected == i, onClick = { selected = i; checked = false })
                        Text(option)
                    }
                }
                Button(onClick = { checked = true }, enabled = selected >= 0) { Text("Periksa") }
                if (checked) Text(if (qs[idx].third[selected] == qs[idx].second) "Benar! ${qs[idx].second}" else "Belum tepat. Jawaban: ${qs[idx].second}")
            }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            OutlinedButton(onClick = { idx = (idx - 1 + qs.size) % qs.size; selected = -1; checked = false }) { Text("Sebelumnya") }
            Button(onClick = { idx = (idx + 1) % qs.size; selected = -1; checked = false }) { Text("Berikutnya") }
        }
    }
}

@Composable
private fun JftScreen(onComplete: () -> Unit) {
    var idx by remember { mutableIntStateOf(0) }
    var selected by remember { mutableIntStateOf(-1) }
    var checked by remember { mutableStateOf(false) }
    var correct by remember { mutableIntStateOf(0) }
    var finished by remember { mutableStateOf(false) }
    val q = jftQuestions[idx]
    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Latihan JFT-Basic A2", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Text("Soal orisinal untuk latihan • ${idx + 1}/${jftQuestions.size}")
        LinearProgressIndicator(progress = { (idx + 1).toFloat() / jftQuestions.size }, modifier = Modifier.fillMaxWidth())
        if (finished) {
            Card(Modifier.fillMaxWidth().weight(1f), shape = RoundedCornerShape(22.dp)) {
                Column(Modifier.fillMaxSize().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                    Text("Latihan selesai!", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                    Text("$correct / ${jftQuestions.size} benar", style = MaterialTheme.typography.titleLarge)
                    Text("Nilai: ${correct * 100 / jftQuestions.size}/100")
                    Spacer(Modifier.height(12.dp))
                    Button(onClick = { idx = 0; selected = -1; checked = false; correct = 0; finished = false }) { Text("Ulangi latihan") }
                }
            }
        } else {
            Card(Modifier.fillMaxWidth().weight(1f), shape = RoundedCornerShape(22.dp)) {
                Column(Modifier.fillMaxSize().padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(q.prompt, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                    q.options.forEachIndexed { i, option ->
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            RadioButton(selected = selected == i, onClick = { if (!checked) selected = i })
                            Text(option)
                        }
                    }
                    Button(onClick = {
                        checked = true
                        if (selected == q.answer) correct += 1
                    }, enabled = selected >= 0 && !checked) { Text("Periksa jawaban") }
                    if (checked) {
                        Text(if (selected == q.answer) "Benar!" else "Belum tepat.", fontWeight = FontWeight.Bold, color = if (selected == q.answer) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error)
                        Text(q.explanation)
                        Button(onClick = {
                            if (idx == jftQuestions.lastIndex) { finished = true; onComplete() }
                            else { idx += 1; selected = -1; checked = false }
                        }) { Text(if (idx == jftQuestions.lastIndex) "Lihat hasil" else "Soal berikutnya") }
                    }
                }
            }
        }
    }
}
