# NihongoMate — Android starter project

A native Android starter app for Japanese study. Includes a dashboard and starter modules for JLPT N5–N1 and JFT-Basic, light/dark theme switching, sample kanji/vocabulary quizzes, text-to-speech audio, and microphone speech recognition.

## Build
1. Install Android Studio (current stable) and Android SDK.
2. Open this folder in Android Studio.
3. Allow Gradle sync to finish.
4. Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Android Studio will show the generated APK location.

This environment generated the source project, not a verified APK binary. The project has not been compiled or device-tested here.

## Current scope
This is a functional prototype scaffold with sample content, not a complete JLPT N5–N1 or JFT question bank. Expand and verify the content before relying on it for exam preparation. JFT-Basic and JLPT are separate exam modes.

## Technical choices
- Kotlin + Jetpack Compose
- Material 3 UI
- Android TextToSpeech for Japanese audio
- Android SpeechRecognizer for microphone practice
- Local sample content; no login/backend yet
- INTERNET and RECORD_AUDIO permissions included

## Next milestones
1. Add reviewed content packs for kanji/vocabulary by level.
2. Add real listening clips and comprehension items.
3. Build kaiwa role-play and speaking feedback.
4. Add JFT-style timed practice and scoring.
5. Persist progress with Room/DataStore.
6. Optional cloud sync/account system.

## Build from an Android phone using GitHub Actions
This project includes `.github/workflows/build-apk.yml` so you can build in GitHub's cloud without a laptop.
1. Sign in or create a GitHub account in your phone browser.
2. Create a new repository (private is fine).
3. Upload the contents of this ZIP into the repository, keeping folder structure intact.
4. Open the repository's **Actions** tab, choose **Build NihongoMate APK**, then tap **Run workflow**.
5. When the run completes successfully, open that run and download the **NihongoMate-debug-apk** artifact. Extract the downloaded ZIP to get `app-debug.apk`.
6. Open the APK on your phone and allow installation from this source if Android asks.

GitHub's interface may be cramped on mobile; use your browser's **Desktop site** option if needed. The cloud build must complete successfully before an APK is available.
