package com.ell.nihongomate

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import java.util.Locale

private data class StudyCard(val front: String, val reading: String, val meaning: String, val example: String)

private val kanjiCards = listOf(
    StudyCard("日", "にち・ひ", "hari / matahari", "日本（にほん）"),
    StudyCard("月", "げつ・つき", "bulan", "月曜日（げつようび）"),
    StudyCard("人", "じん・ひと", "orang", "日本人（にほんじん）"),
    StudyCard("学", "がく・まなぶ", "belajar", "学生（がくせい）"),
    StudyCard("山", "さん・やま", "gunung", "山（やま）")
)
private val vocabCards = listOf(
    StudyCard("学校", "がっこう", "sekolah", "学校へ行きます。"),
    StudyCard("先生", "せんせい", "guru", "田中先生です。"),
    StudyCard("友達", "ともだち", "teman", "友達と話します。"),
    StudyCard("食べます", "たべます", "makan", "パンを食べます。"),
    StudyCard("聞きます", "ききます", "mendengar / bertanya", "音楽を聞きます。")
)

class MainActivity : ComponentActivity() {
    private var tts: TextToSpeech? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) tts?.language = Locale.JAPANESE
        }
        setContent { NihongoMateApp(onSpeak = { text -> tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jp") }) }
    }
    override fun onDestroy() {
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }
}

@Composable
private fun NihongoMateApp(onSpeak: (String) -> Unit) {
    var darkMode by remember { mutableStateOf(true) }
    var selected by remember { mutableStateOf("Beranda") }
    val colors = if (darkMode) darkColorScheme() else lightColorScheme()
    MaterialTheme(colorScheme = colors) {
        Scaffold(
            topBar = {
                TopAppBarCompat(
                    title = "NihongoMate",
                    darkMode = darkMode,
                    onToggleTheme = { darkMode = !darkMode }
                )
            },
            bottomBar = {
                NavigationBar {
                    listOf("Beranda", "Fondasi", "Kanji", "Kosakata", "Kaiwa", "JFT").forEach { item ->
                        NavigationBarItem(
                            selected = selected == item,
                            onClick = { selected = item },
                            icon = { Text(when(item) {
                                "Beranda" -> "⌂"; "Fondasi" -> "あ"; "Kanji" -> "漢"; "Kosakata" -> "語"
                                "Kaiwa" -> "会"; else -> "✓"
                            }) },
                            label = { Text(item) },
                            alwaysShowLabel = true
                        )
                    }
                }
            }
        ) { padding ->
            Column(Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp)) {
                when (selected) {
                    "Beranda" -> HomeScreen(onOpen = { selected = it })
                    "Fondasi" -> FoundationScreen(onSpeak = onSpeak)
                    "Kanji" -> CardListScreen("Kanji JLPT N5–N1", "Contoh awal • konten tiap level akan ditambahkan bertahap", kanjiCards, onSpeak)
                    "Kosakata" -> CardListScreen("Kosakata JLPT N5–N1", "Contoh kosakata • pilih kartu untuk belajar", vocabCards, onSpeak)
                    "Listening" -> ListeningScreen(onSpeak)
                    "Kaiwa" -> KaiwaScreen(onSpeak)
                    "JFT" -> JftScreen()
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun TopAppBarCompat(title: String, darkMode: Boolean, onToggleTheme: () -> Unit) {
    CenterAlignedTopAppBar(
        title = { Text(title, fontWeight = FontWeight.Bold) },
        actions = {
            TextButton(onClick = onToggleTheme) { Text(if (darkMode) "☀ Light" else "☾ Dark") }
        }
    )
}

@Composable
private fun HomeScreen(onOpen: (String) -> Unit) {
    LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp), contentPadding = PaddingValues(vertical = 12.dp)) {
        item {
            Card(shape = RoundedCornerShape(24.dp), modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
                Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("NihongoMate", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                    Text("Belajar Jepang dari nol, selangkah demi selangkah.")
                    LinearProgressIndicator(progress = { 0.05f }, modifier = Modifier.fillMaxWidth())
                    Text("Jalur belajar • Fondasi → N5 → N4 → N3 → N2 → N1")
                }
            }
        }
        item { Text("Mulai dari dasar", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold) }
        item {
            Card(onClick = { onOpen("Fondasi") }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(20.dp)) {
                Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                    Text("あ", style = MaterialTheme.typography.displayMedium, color = MaterialTheme.colorScheme.primary)
                    Column(Modifier.weight(1f)) {
                        Text("Fondasi: Hiragana & Katakana", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        Text("Kenali huruf, dengarkan pelafalan, lalu tes ingatan.")
                    }
                    Text("›", style = MaterialTheme.typography.headlineMedium)
                }
            }
        }
        item { Text("Jalur level", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold) }
        items(listOf(
            Triple("N5", "Pemula • kosakata, kanji, tata bahasa, listening", "N5"),
            Triple("N4", "Dasar lanjutan • kalimat dan pemahaman lebih luas", "N4"),
            Triple("N3", "Menengah • bacaan dan percakapan lebih kompleks", "N3"),
            Triple("N2", "Menengah atas • pemahaman teks dan audio", "N2"),
            Triple("N1", "Mahir • kosakata dan bacaan tingkat lanjut", "N1")
        )) { item ->
            Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(18.dp)) {
                Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(item.third, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                    Column(Modifier.weight(1f)) {
                        Text(item.first, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                        Text(item.second, style = MaterialTheme.typography.bodyMedium)
                    }
                    AssistChip(onClick = {}, label = { Text(if (item.first == "N5") "Segera" else "Bertahap") })
                }
            }
        }
        item {
            Text("Catatan: ini versi awal. Materi dan bank soal akan ditambah per tahap; progres permanen dan tes penentu level belum aktif.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun FoundationScreen(onSpeak: (String) -> Unit) {
    val kana = listOf(
        Triple("あ", "a", "seperti a pada ‘apa’"), Triple("い", "i", "seperti i pada ‘ikan’"),
        Triple("う", "u", "seperti u pada ‘umur’"), Triple("え", "e", "seperti e pada ‘enak’"),
        Triple("お", "o", "seperti o pada ‘obat’"), Triple("か", "ka", "k + a"),
        Triple("き", "ki", "k + i"), Triple("く", "ku", "k + u"),
        Triple("け", "ke", "k + e"), Triple("こ", "ko", "k + o"),
        Triple("さ", "sa", "s + a"), Triple("し", "shi", "dibaca shi"),
        Triple("す", "su", "s + u"), Triple("せ", "se", "s + e"), Triple("そ", "so", "s + o")
    )
    var index by remember { mutableIntStateOf(0) }
    var reveal by remember { mutableStateOf(false) }
    var score by remember { mutableIntStateOf(0) }
    var attempts by remember { mutableIntStateOf(0) }
    val current = kana[index % kana.size]
    Column(Modifier.fillMaxSize().padding(top = 16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("Fondasi • Hiragana", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Text("Mulai dari vokal, lalu baris K dan S. Ini set latihan awal, belum seluruh tabel kana.")
        LinearProgressIndicator(progress = { (index + 1).toFloat() / kana.size }, modifier = Modifier.fillMaxWidth())
        Card(Modifier.fillMaxWidth().weight(1f), shape = RoundedCornerShape(24.dp)) {
            Column(Modifier.fillMaxSize().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                Text(current.first, style = MaterialTheme.typography.displayLarge, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                if (reveal) {
                    Text(current.second, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                    Text(current.third)
                } else Text("Ingat bunyi huruf ini?")
                Spacer(Modifier.height(20.dp))
                Button(onClick = { onSpeak(current.first) }) { Text("🔊 Dengarkan") }
                OutlinedButton(onClick = { reveal = !reveal }) { Text(if (reveal) "Sembunyikan jawaban" else "Lihat jawaban") }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { index = (index - 1 + kana.size) % kana.size; reveal = false }) { Text("Sebelumnya") }
                    Button(onClick = { index = (index + 1) % kana.size; reveal = false }) { Text("Berikutnya") }
                }
            }
        }
        Text("Kartu ${index + 1}/${kana.size} • Untuk menguji hafalan, coba jawab sebelum membuka jawaban.", style = MaterialTheme.typography.bodySmall)
    }
}

@Composable
private fun CardListScreen(title: String, subtitle: String, cards: List<StudyCard>, onSpeak: (String) -> Unit) {
    var index by remember { mutableIntStateOf(0) }
    var showAnswer by remember { mutableStateOf(false) }
    val card = cards[index % cards.size]
    Column(Modifier.fillMaxSize().padding(top = 16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text(title, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Text(subtitle, style = MaterialTheme.typography.bodyMedium)
        Card(Modifier.fillMaxWidth().weight(1f), shape = RoundedCornerShape(24.dp)) {
            Column(Modifier.fillMaxSize().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                Text(card.front, style = MaterialTheme.typography.displayLarge, fontWeight = FontWeight.Bold)
                if (showAnswer) {
                    Spacer(Modifier.height(14.dp))
                    Text(card.reading, style = MaterialTheme.typography.titleLarge)
                    Text(card.meaning, style = MaterialTheme.typography.headlineSmall)
                    Text(card.example, style = MaterialTheme.typography.bodyLarge)
                } else {
                    Text("Coba ingat bacaan dan artinya", style = MaterialTheme.typography.bodyMedium)
                }
                Spacer(Modifier.height(20.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { onSpeak(card.front); onSpeak(card.reading) }) { Text("🔊 Dengarkan") }
                    OutlinedButton(onClick = { showAnswer = !showAnswer }) { Text(if (showAnswer) "Sembunyikan" else "Lihat jawaban") }
                }
            }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            OutlinedButton(onClick = { index = (index - 1 + cards.size) % cards.size; showAnswer = false }) { Text("Sebelumnya") }
            Text("${index + 1} / ${cards.size}", modifier = Modifier.align(Alignment.CenterVertically))
            Button(onClick = { index = (index + 1) % cards.size; showAnswer = false }) { Text("Berikutnya") }
        }
    }
}

@Composable
private fun ListeningScreen(onSpeak: (String) -> Unit) {
    var answered by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().padding(top = 16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("Listening", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Text("Contoh latihan audio berbasis TTS. Paket audio rekaman dan soal listening asli perlu ditambahkan.")
        Card {
            Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("Dengarkan kalimat berikut:", fontWeight = FontWeight.SemiBold)
                Text("毎朝、七時に起きます。", style = MaterialTheme.typography.headlineSmall)
                Button(onClick = { onSpeak("毎朝、七時に起きます。") }) { Text("▶ Putar audio Jepang") }
                Text("Apa arti kalimat tersebut?")
                listOf("Saya bangun pukul tujuh setiap pagi.", "Saya tidur pukul tujuh setiap malam.", "Saya belajar setiap hari.").forEachIndexed { i, answer ->
                    OutlinedButton(onClick = { answered = true }, modifier = Modifier.fillMaxWidth()) { Text(answer) }
                    if (answered && i == 0) Text("Jawaban benar: Saya bangun pukul tujuh setiap pagi.")
                }
            }
        }
    }
}

@Composable
private fun KaiwaScreen(onSpeak: (String) -> Unit) {
    val context = LocalContext.current
    var recognized by remember { mutableStateOf("Hasil suara akan muncul di sini.") }
    var listening by remember { mutableStateOf(false) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) startSpeechRecognition(context, { recognized = it; listening = false }, { listening = false })
    }
    Column(Modifier.fillMaxSize().padding(top = 16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("Kaiwa — latihan bicara", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Text("Situasi: memperkenalkan diri")
        Card {
            Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("はじめまして。わたしは ___ です。", style = MaterialTheme.typography.titleLarge)
                Text("Hajimemashite. Watashi wa ___ desu.")
                Text("Coba ucapkan nama lu dalam bahasa Jepang.")
                Button(onClick = { onSpeak("はじめまして。わたしはエルです。") }) { Text("🔊 Dengarkan contoh") }
                Button(onClick = {
                    listening = true
                    val granted = ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
                    if (granted) startSpeechRecognition(context, { recognized = it; listening = false }, { listening = false })
                    else launcher.launch(Manifest.permission.RECORD_AUDIO)
                }, modifier = Modifier.fillMaxWidth()) { Text(if (listening) "Mendengarkan…" else "🎙 Mulai bicara") }
                Text(recognized)
                Text("Catatan: pengenalan suara bergantung pada dukungan bahasa Jepang di perangkat.")
            }
        }
    }
}

private fun startSpeechRecognition(
    context: android.content.Context,
    onResult: (String) -> Unit,
    onDone: () -> Unit
) {
    if (!SpeechRecognizer.isRecognitionAvailable(context)) {
        onResult("Speech recognition tidak tersedia di perangkat ini.")
        onDone()
        return
    }
    val recognizer = SpeechRecognizer.createSpeechRecognizer(context)
    recognizer.setRecognitionListener(object : android.speech.RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() { onDone() }
        override fun onError(error: Int) { onResult("Suara belum terbaca (kode $error). Coba lagi."); onDone(); recognizer.destroy() }
        override fun onResults(results: Bundle?) {
            onResult(results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull() ?: "Belum ada hasil.")
            onDone()
            recognizer.destroy()
        }
        override fun onPartialResults(partialResults: Bundle?) {}
        override fun onEvent(eventType: Int, params: Bundle?) {}
    })
    val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
        putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ja-JP")
        putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "ja-JP")
    }
    recognizer.startListening(intent)
}

@Composable
private fun JftScreen() {
    var selected by remember { mutableIntStateOf(-1) }
    var submitted by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().padding(top = 16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("JFT-Basic A2", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Text("Contoh soal pemahaman ungkapan. Ini soal demo, bukan soal resmi.")
        Card {
            Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("Di toko, pegawai bertanya: 「袋は要りますか。」 Apa maksudnya?", style = MaterialTheme.typography.titleMedium)
                listOf("Apakah perlu kantong?", "Mau bayar dengan kartu?", "Barangnya berapa?").forEachIndexed { i, answer ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        RadioButton(selected = selected == i, onClick = { selected = i; submitted = false })
                        Text(answer)
                    }
                }
                Button(onClick = { submitted = true }, enabled = selected >= 0) { Text("Periksa jawaban") }
                if (submitted) Text(if (selected == 0) "Benar! 袋（ふくろ） berarti kantong." else "Belum tepat. Jawaban: Apakah perlu kantong?")
            }
        }
        Text("Rencana mode ujian: timer, beberapa bagian, nilai, dan pembahasan setelah bank soal disusun.")
    }
}
