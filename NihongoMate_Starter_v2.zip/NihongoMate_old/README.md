# NihongoMate — Starter v2

Aplikasi Android belajar bahasa Jepang dengan gaya minimalis modern, dark mode beraksen biru, ikon aplikasi khusus, beranda jalur belajar, dan kartu fondasi hiragana dengan pelafalan TTS.

## Status yang jujur
Ini masih MVP awal, bukan aplikasi lengkap. Materi hiragana yang tersedia baru contoh awal; katakana, seluruh kanji/kosakata N5–N1, bank soal simulasi JFT yang besar, progres tersimpan permanen, dan alur kaiwa bercabang masih perlu dikembangkan dan diuji.

## Build di GitHub Actions
Workflow repository yang sudah ada dapat mengekstrak `NihongoMate_Android_Starter.zip` dari root repository lalu membangun APK debug. Upload ZIP ini ke repository dengan nama yang sama, lalu buka Actions dan periksa hasil build.

## Catatan materi
Konten latihan yang ditambahkan perlu dikembangkan dengan soal orisinal dan sumber yang boleh digunakan. Jangan menyebut latihan sebagai bocoran atau soal resmi tahun lalu tanpa sumber resmi.
